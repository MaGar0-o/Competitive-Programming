#!/bin/bash
g++ grader.cpp weights.cpp -Wall -Wextra -o weights
