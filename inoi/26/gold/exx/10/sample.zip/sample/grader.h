#ifndef __WEIGHTS_H__
#define __WEIGHTS_H__

#ifdef __cplusplus
extern "C" {
#endif

int identify_set(int, int, long long**);

int compare(int, int);

#ifdef __cplusplus
}
#endif

#endif // __WEIGHTS_H__
