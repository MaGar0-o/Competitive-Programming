from django.contrib import admin
from tutorials.models import Tutorial

# Register your models here.
admin.site.register(Tutorial)
