from django.contrib import admin
from contests.models import Contest

# Register your models here.
admin.site.register(Contest)
