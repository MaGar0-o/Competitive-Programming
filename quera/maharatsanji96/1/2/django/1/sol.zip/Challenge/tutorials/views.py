from django.shortcuts import render
from django.http import HttpResponse
from contests.models import Contest
from tutorials.models import Tutorial


# Create your views here.
def add_tutor(request):
	contest = Contest.objects.get(title=request.GET['contest'])
	tutorial = Tutorial.objects.filter(title=request.GET['tutorial'])
	if len(tutorial) == 0:
		tutorial = Tutorial(title=request.GET['tutorial'], contest=contest)
		tutorial.save()
	else:
		tutorial = tutorial[0]
	return HttpResponse(tutorial.id)


def get_tutor(request):
	contest = Contest.objects.get(title=request.GET['contest'])
	tutor_list = Tutorial.objects.filter(contest=contest)
	tutor_names_list = [t.title for t in tutor_list]
	tutor_names_list.sort()
	return HttpResponse(''.join(tutor_names_list))

