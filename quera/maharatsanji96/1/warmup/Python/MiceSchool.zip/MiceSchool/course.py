class Course(object):

	def __init__(self):
		pass


	def register(self, s):
		pass


	def getNumOfStudents(self):
		pass

	
	def getStudents(self):
		pass

	
	def getName(self):
		pass


	def setName(self, name):
		pass

