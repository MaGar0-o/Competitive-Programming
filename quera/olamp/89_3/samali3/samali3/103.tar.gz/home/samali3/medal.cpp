//name: Parsa Saadatpanah
#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
const int MAXN=(100*1000)+10;
bool sol[MAXN];
struct BAZE{
	int start,finish;
	bool mark;
	int fard,zoj;
	vector<int> adj;
} baze[MAXN];
bool operator <(BAZE a,BAZE b){
	if(a.start!=b.start)
		return a.start<b.start;
	return a.finish>b.finish;
}
int t,n,m;
int sta[MAXN];
int finish_sta;
void DFS(int a){
	if(a==0) return;
	if(baze[a].mark) return;
	baze[a].mark=true;
	for(int i=0;i<baze[a].adj.size();i++)
		DFS(baze[a].adj[i]);
	int thefard=0;
	int thezoj=0;
	int prev=baze[a].start;
	for(int i=0;i<baze[a].adj.size();i++){
		for(int k=prev;k<baze[baze[a].adj[i]].start;k++){
			if(sol[k]) thefard++;
			else thezoj++;
		}
		prev=baze[baze[a].adj[i]].finish+1;
	}
	for(int k=prev;k<=baze[a].finish;k++){
		if(sol[k]) thefard++;
		else thezoj++;
	}
	for(int i=0;i<baze[a].adj.size();i++){
		thefard+=baze[baze[a].adj[i]].fard;
		thezoj+=baze[baze[a].adj[i]].zoj;
	}
	int number=baze[a].finish-baze[a].start+1;
	/*
	baze[a].fard=max(thefard,number-thefard);
	baze[a].zoj=max(thezoj,number-thezoj);
	*/
	////////////
	/*
	baze[a].fard=max(baze[a].fard,number-thezoj);
	baze[a].fard=max(baze[a].fard,thezoj);
	baze[a].zoj=max(baze[a].zoj,number-thefard);
	baze[a].zoj=max(baze[a].zoj,thefard);
	*/
	
	baze[a].fard=max(thefard,thezoj);
	baze[a].zoj=baze[a].fard;
	
	/*
	thefard=max(thefard,thezoj);
	thezoj=max(thefard,thezoj);
	*/
	//baze[a].fard=thefard;
	//baze[a].zoj=thezoj;
}		
int main(){
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		scanf("%d",&n);
		int a;
		for(int i=1;i<=n;i++){
			scanf("%d",&a);
			sol[i]=a%2;
		}
		scanf("%d",&m);
		for(int i=1;i<=m;i++){
			scanf("%d%d",&baze[i].start,&baze[i].finish);
			baze[i].adj.resize(0);
			baze[i].mark=false;
			baze[i].fard=0;
			baze[i].zoj=0;
		}
		sort(baze+1,baze+m+1);
		finish_sta=1;	
		sta[0]=1;
		for(int i=2;i<=m;i++){
			while((baze[i].start>baze[sta[finish_sta-1]].finish)&&(finish_sta>0)) finish_sta--;
			if(finish_sta>0) baze[sta[finish_sta-1]].adj.push_back(i);
			sta[finish_sta]=i;
			finish_sta++;
		}
		int prev=1;
		int total=0;
		for(int i=1;i<=m;i++){
			if(!baze[i].mark){
				for(int k=prev;k<baze[i].start;k++)
					if(sol[k]) total++;
				prev=baze[i].finish+1;
				DFS(i);
				total+=baze[i].fard;
			}
		}
		//////////
		/*
		for(int i=1;i<=m;i++){
			cout<<baze[i].start<<" "<<baze[i].finish<<" "<<baze[i].fard<<" "<<baze[i].zoj<<endl;
			for(int j=0;j<baze[i].adj.size();j++)
				cout<<baze[i].adj[j]<<" ";
			cout<<endl;
		}
		*/
		for(int k=prev;k<=n;k++)
			if(sol[k]) total++;
		printf("%d%s",total,"\n");
	}
	return 0;
}
