//name: Parsa Saadatpanah
#include<iostream>
#include<cstdio>
using namespace std;
const int MAXN=(1000*1000)+20;
int k[MAXN];
int n;
int big,good;
long long total;
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&k[i]);
		if(k[i]>big) {good=i; big=k[i];}
	}
	big=0;
	for(int i=1;i<=good;i++){
		if(k[i]>big) big=k[i];
		total+=big-k[i];
	}
	big=0;
	for(int i=n;i>=good;i--){
		if(k[i]>big) big=k[i];
		total+=big-k[i];
	}
	cout<<total<<endl;
	return 0;
}
