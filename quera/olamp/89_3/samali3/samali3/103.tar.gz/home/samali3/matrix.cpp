//name: Parsa Saadatpanah
#include<iostream>
#include<cstdio>
#include<cmath>
#include<vector>
#include<set>
using namespace std;
const int MAXN=1000+10;
int a[MAXN][MAXN];
int b[MAXN][MAXN];
vector<char> change[2];
int n,t;
void make_simple( int a[],int q){
	int used=0;
	bool minus=true;
	bool radical=true;
	int e[MAXN];
	if(a[1]==0) minus=false;
	for(int i=1;i<=n;i++){
		e[i]=sqrt(a[i]);
		if(e[i]*e[i]!=a[i]) {radical=false; break;}
	}
	while(minus||radical){
		if(radical){
			for(int i=1;i<=n;i++)
				a[i]=e[i];
			change[q].push_back(1);
			used++;
		}
		else{
			for(int i=1;i<=n;i++)
				a[i]--;
			change[q].push_back(2);
		}
		if(a[1]==0) minus=false;
		radical=true;
		for(int i=1;i<=n;i++){
			e[i]=sqrt(a[i]);
			if(e[i]*e[i]!=a[i]) {radical=false; break;}
		}
		if(used>30) radical=false;
	}
}
int move(int a,int q){
	int can=0;
	for(int i=0;i<change[q].size();i++){
		if(change[q][i]==1){
			int e=sqrt(a);
			if(e*e!=a) return can;
			else a=e;
		}
		else{
			if(a==0) return can;
			else a--;
		}
		can++;
	}
	return can;
}
void change2(int &a,int tedad,int q){
	for(int i=0;i<tedad;i++){
		if(change[q][i]==1)
			a=sqrt(a);
		else a--;
	}
}

int main(){
	scanf("%d",&t);
	for(int z=1;z<=t;z++){
		int a_min=1000000001;
		int a_pos[2];
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
				scanf("%d",&a[i][j]);
				if(a[i][j]<a_min) {a_min=a[i][j]; a_pos[0]=i; a_pos[1]=j;}
			}
		int b_min=1000000001;
		int b_pos[2];
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
				scanf("%d",&b[i][j]);
				if(b[i][j]<b_min) {b_min=b[i][j]; b_pos[0]=i; b_pos[1]=j;}
			}
		int a_check[MAXN];
		int b_check[MAXN];
		//cout<<endl<<a_pos[0]<<" "<<a_pos[1]<<endl<<b_pos[0]<<" "<<b_pos[1]<<endl<<endl;
		int point=0;
		for(int i=a_pos[1];i<=n;i++){
			point++;
			a_check[point]=a[a_pos[0]][i];
		}
		for(int i=1;i<a_pos[1];i++){
			point++;
			a_check[point]=a[a_pos[0]][i];
		}
		point=0;
		for(int i=b_pos[1];i<=n;i++){
			point++;
			b_check[point]=b[b_pos[0]][i];
		}
		for(int i=1;i<b_pos[1];i++){
			point++;
			b_check[point]=b[b_pos[0]][i];
		}
		////
		/*
		for(int i=1;i<=n;i++)
			cout<<a_check[i]<<" ";
		cout<<endl;
		for(int i=1;i<=n;i++)
			cout<<b_check[i]<<" ";
		cout<<endl;
		*/
		////

		make_simple(a_check,0);
		make_simple(b_check,1);
		bool finished=false;
		for(int i=1;i<=n;i++)
			if(a_check[i]!=b_check[i]) {cout<<"No"<<endl; finished=true; break;}
		if(finished) continue;
		int last_a=change[0].size();
		int last_b=change[1].size();
		//cout<<last_a<<" "<<last_b<<endl<<endl;
		//cout<<int(change[0][0])<<" "<<int(change[1][0])<<endl;	
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
				last_a=min(last_a,move(a[i][j],0));
				last_b=min(last_b,move(b[i][j],1));
				//cout<<last_b<<endl;
			}
		//cout<<last_a<<" "<<last_b<<endl<<endl;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
				change2(a[i][j],last_a,0);
				change2(b[i][j],last_b,1);
			}
		///////////////////////////
		/*
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++)
				cout<<a[i][j]<<" ";
			cout<<endl;
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++)
				cout<<b[i][j]<<" ";
			cout<<endl;
		}
		*/
		////////////////////////////
		multiset<long long> totala;
		multiset<long long> totalb;
		totala.clear();
		totalb.clear();
		long long tempa=0,tempb=0;
		for(int i=1;i<=n;i++){
			tempa=0;
			tempb=0;
			for(int j=1;j<=n;j++){
				tempa+=a[i][j];
				tempb+=b[i][j];
			}
			totala.insert(tempa);
			totalb.insert(tempb);
		}
		while(!totala.empty()){
			if((*(totala.begin()))!=(*(totalb.begin()))) {cout<<"No"<<endl; finished=true; break;}
			totala.erase(totala.begin());
			totalb.erase(totalb.begin());
		}
		if(finished) continue;
		cout<<"Yes"<<endl;

	}
	return 0;
}

