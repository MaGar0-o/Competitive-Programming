//name: SinaZandKarimi

#include <algorithm>
#include <iostream>
#include <cstdio>
#include <queue>

#define LL long long

using namespace std;

const int Maxn = 1000 * 1000 + 10;

int n;
int height[Maxn];
bool mark[Maxn];

struct Build
{
	int h;
	int index;

	void read()
	{
		int tmp = scanf("%d", &h);
	}
}build[Maxn];

bool operator < (Build a, Build b)
{
	if(a.h != b.h)
		return a.h < b.h;

	return a.index < b.index;
}

priority_queue <Build> heap;

LL ans = 0;

LL L(int h)
{
	if(h < 0)
		return 0;

	return h;
}

int seted[Maxn];

void set(int s, int e, int h)//[ , ]
{
	for(int i = s;i <= e;i++)
	{
		if(mark[i])
			continue;

		ans += L(h - height[i]);
		seted[i] = h;

		mark[i] = true;
	}
}

int abs1(int a)
{
	return a > 0 ? a : -a;
}

int main()
{
	int tmp = scanf("%d", &n);

	for(int i = 0;i < n;i++)
	{
		build[i].read();
		height[i] = build[i].h;
		build[i].index = i;

		heap.push(build[i]);
	}

	Build start = heap.top();
	heap.pop();

	for(int i = 1;i < n;i++)
	{
		Build next = heap.top();
		heap.pop();

		if(abs1(start.index - next.index) == 1)
			continue;

		int s = min(start.index, next.index);
		int e = max(start.index, next.index);

		set(s, e, next.h);
	}

	/*for(int i = 0;i < n;i++)
		cerr << seted[i] << " ";
	cerr << endl;*/
	
	cout << ans << endl;
}
