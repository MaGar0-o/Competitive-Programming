//name: SinaZandKarimi

#include <algorithm>
#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

const int Max = 100 * 1000 + 10;

struct baze
{
	int start, end;//[start, end]

	int size()
	{
		return end - start + 1;
	}
}general[Max];

bool operator < (baze a, baze b)
{
	return a.size() > b.size();
}

int n, t, m;
bool sarbaz[Max];

int sz1_N(baze g)//O(N) 70 Points
{
	int ct = 0;
	
	for(int i = g.start;i <= g.end;i++)
		if(sarbaz[i])
			ct++;

	return ct;
}

bool better_come(baze g)
{
	int one = sz1_N(g);
	return (g.size() - one) > one;
}

int main()
{
	int tmp = scanf("%d", &t);

	for(int i = 0;i < t;i++)
	{
		tmp = scanf("%d", &n);
		for(int j = 0;j < n;j++)
		{
			int medal;
			tmp = scanf("%d", &medal);

			sarbaz[j] = (medal & 1);

			//cerr << sarbaz[j] << " ";
		}
		//cerr << endl;

		tmp = scanf("%d", &m);

		for(int j = 0;j < m;j++)
		{
			tmp = scanf("%d%d", &general[j].start, &general[j].end);
			general[j].start--;
			general[j].end--;

			if(sz1_N(general[j]) == general[j].size())
			{
				for(int i = general[j].start;i <= general[j].end;i++)
					sarbaz[i] = 0;
			}
		}

		sort(general, general + m);

		for(int j = 0;j < m;j++)
			if(better_come(general[j]))
			{
				//cerr << "better come : " << j + 1 << endl;
				for(int i = general[j].start;i <= general[j].end;i++)
					sarbaz[i] = !sarbaz[i];
			}

		int ct = 0;
		for(int j = 0;j < n;j++)
		{
			if(sarbaz[j])
				ct++;
			//cerr << sarbaz[j] << " ";
		}

		//cerr << endl;

		cout << ct << endl;
	}

	return 0;
}
