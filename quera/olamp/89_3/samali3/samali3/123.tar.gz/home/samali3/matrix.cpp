//name: SinaZandKarimi

#include <algorithm>
#include <iostream>
#include <cstdio>
#include <vector>
#include <queue>

#define LL long long

using namespace std;

const int Maxn = 1000 + 10;

int n;
int start[Maxn][Maxn];
int end[Maxn][Maxn];

void shift(int *a)
{
	int tmp = a[0];

	for(int i = 0;i < n;i++)
		a[i] = a[(i + 1) % n];

	a[n - 1] = tmp;
}

void Sort(int *a)
{
	int mn = (1 << 30);

	for(int j = 0;j < n;j++)
		mn = min(mn, a[j]);

	while(a[0] != mn)
		shift(a);
}

int t;

bool finder;

const int Maxpow = 31622;

//move: * : tavan, + : jam


vector <int> moves;

int do_moves(int k)
{
	for(int i = 0;i < (int)moves.size();i++)
		if(moves[i] == -1)
			k *= k;
		else
			k += moves[i];

	return k;
}

bool same()
{
	for(int i = 0;i < n - 1;i++)
		for(int j = 0;j < n;j++)
		{
			int taze = do_moves(start[i][j]);
			if(taze != end[i][j])
				return false;
		}

	return true;
}

void make_last_row(int ct, char last_move)
{
	if(finder)
		return;

	if(start[n - 1][0] > end[n - 1][0])
		return;

	if(ct == n)
	{
		bool yeki = true;
		for(int i = 0;i < n;i++)
			if(start[n - 1][i] != end[n - 1][i])
			{
				yeki = false;
				break;
			}

		if(yeki)
			if(same())
				finder = true;
		return;
	}

	if(last_move == '+')
	{
		if(start[n - 1][n - 1] > Maxpow)
			return;

		int cpy[Maxn];

		for(int i = 0;i < n;i++)
		{
			cpy[i] = start[n - 1][i];
			start[n - 1][i] *= start[n - 1][i];
		}

		moves.push_back(-1);
		make_last_row(ct + 1, '*');
		moves.pop_back();
		
		for(int i = 0;i < n;i++)
			start[n - 1][i] = cpy[i];
	}
	else
	{
		//tavan***************************************

		if(start[n - 1][n - 1] < Maxpow)
		{
			int cpy[Maxn];

			for(int i = 0;i < n;i++)
			{
				cpy[i] = start[n - 1][i];
				start[n - 1][i] *= start[n - 1][i];
			}

			moves.push_back(-1);
			make_last_row(ct + 1, '*');
			moves.pop_back();

			for(int i = 0;i < n;i++)
				start[n - 1][i] = cpy[i];
		}

		//tavan***************************************

		//jam*****************************************
		for(int add = end[n - 1][0] - start[n - 1][0];add >= 1;add--)
		{
			for(int i = 0;i < n;i++)
				start[n - 1][i] += add;
			
			moves.push_back(add);
			make_last_row(ct + 1, '+');
			moves.pop_back();
			
			for(int i = 0;i < n;i++)
				start[n - 1][i] -= add;
		}
		//jam*****************************************
	}
}

int main()
{
	int tmp = scanf("%d", &t);
	for(int tt = 0;tt < t;tt++)
	{
		finder = false;
		tmp = scanf("%d", &n);

		for(int i = 0;i < n;i++)
			for(int j = 0;j < n;j++)
				tmp = scanf("%d", &start[i][j]);

		for(int i = 0;i < n;i++)
			for(int j = 0;j < n;j++)
				tmp = scanf("%d", &end[i][j]);
		
		for(int i = 0;i < n;i++)
		{
			Sort(start[i]);
			Sort(end[i]);

		}

		for(int i = 0;i < n;i++)
			for(int j = 0;j < n - 1;j++)
				if(start[j][0] > start[j + 1][0])
					for(int i = 0;i < n;i++)
					{
						int help;
						help = start[j][i];
						start[j][i] = start[j + 1][i];
						start[j + 1][i] = help;
					}
		
		for(int i = 0;i < n;i++)
			for(int j = 0;j < n - 1;j++)
				if(end[j][0] > end[j + 1][0])
					for(int i = 0;i < n;i++)
					{
						int help;
						help = end[j][i];
						end[j][i] = end[j + 1][i];
						end[j + 1][i] = help;
					}
	
		for(int i = 0;i < n;i++)
			for(int j = 0;j < n - 1;j++)
			{
				if(start[i][j] >= start[i][j + 1] && end[i][j] < end[i][j + 1])
				{
					cout << "No" << endl;
					goto end_of_tt;
				}
				
				if(end[i][j] >= end[i][j + 1] && start[i][j] < start[i][j + 1])
				{
					cout << "No" << endl;
					goto end_of_tt;
				}
			}

		make_last_row(0, 0);


		if(!finder)
			cout << "No" << endl;
		else
			cout << "Yes" << endl;

end_of_tt:;
	}
}
