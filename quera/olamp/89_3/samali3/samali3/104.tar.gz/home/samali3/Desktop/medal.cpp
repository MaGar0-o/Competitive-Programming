//name: Ali Aminian

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>

#define F first
#define S second
#define MP make_pair
using namespace std;

const int MAX_N = 100000+5;
const int MAX_M = 100000+5;

typedef pair<int,int> joft;

// Input
int t;
int n;
int m;
int s[MAX_N];
joft p[MAX_M];

int nEven[MAX_N];
int nOdd[MAX_M];

int next[MAX_M];
int last[MAX_M];
joft help[MAX_M];

//memoize for find
int markEven[MAX_M];
int markOdd[MAX_M];
int dEven[MAX_M];
int dOdd[MAX_M];

void readInput() {
	scanf("%d",&n);
	for(int i = 0;i<n;i++)
		scanf("%d",&s[i]);
	scanf("%d",&m);
	p[0]=MP(0,-n+1);
	for(int i = 1;i<=m;i++) {
		int a,b;
		scanf("%d%d",&a,&b);
		a--;b--;
		p[i]=MP(a,-b);
	}
}

void init() {
	//memset
	memset(markOdd,0,sizeof(markOdd));
	memset(markEven,0,sizeof(markEven));
	memset(dOdd,0,sizeof(dOdd));
	memset(dEven,0,sizeof(dEven));
	//Correct p[i].S
	for(int i = 0;i<=m;i++)
		p[i].S*=-1;
	//help
	for(int i = 0;i<=m;i++)
		help[i]=MP(p[i].S,i);
	sort(help,help+m+1);
	//nOdd
	if(s[0]%2==1)
		nOdd[0]=1;
	for(int i = 1;i<n;i++) {
		nOdd[i]=nOdd[i-1];
		if(s[i]%2==1)
			nOdd[i]++;
	}
	//nEven
	if(s[0]%2==0)
		nEven[0]=1;
	for(int i = 0;i<n;i++) {
		nEven[i]=nEven[i-1];
		if(s[i]%2==0)
			nEven[i]++;
	}
	// next
	next[m]=m+1;
	for(int i = m-1;i>=0;i--) {
		int d = upper_bound(p,p+m+1,joft(p[i].S,MAX_M) )-p;
		next[i]=d;
	}
	//last
	last[0]=-1;
	for(int i = 1;i<=m;i++) {
		int d = lower_bound(help,help+m+1,MP(p[i].F,-1))-help-1;
		if(d<0)
			last[i]=-1;
		else
			last[i]=help[d].S;
	}
}

int memoizeEven(int k);
int memoizeOdd(int k) {
	int tmp = nOdd[p[k].S]-nOdd[p[k].F-1];
	if(k==m)
		return tmp;
	if(p[k+1].F>p[k].S) {
		return tmp;
	}
	if(markOdd[k]==1)
		return dOdd[k];
	markOdd[k]=1;
	int j = k+1;
	while(j<=m && p[j].F<=p[k].S) {

		if(j==k+1) {
			dOdd[k]+=nOdd[p[j].F-1]-nOdd[p[j-1].F-1];
		}
		else {

			dOdd[k]+=nOdd[p[j].F-1]-nOdd[p[last[j]].S];
		}
		if(memoizeEven(j)>memoizeOdd(j)) {
			dOdd[k]+=memoizeEven(j);
		}
		else {
			dOdd[k]+=memoizeOdd(j);
		}
		if(next[j]==m+1) {
			dOdd[k]+=nOdd[p[k].S]-nOdd[p[j].S];
		}
		else if(p[next[j]].F>p[k].S) {
			dOdd[k]+=nOdd[p[k].S]-nOdd[p[j].S];

		}
		j=next[j];

	}
	return dOdd[k];

}
int memoizeEven(int k) {
	int tmp = nEven[p[k].S]-nEven[p[k].F-1];
	if(k==m)
		return tmp;
	if(p[k+1].F>p[k].S)
		return tmp;
	if(markEven[k]==1)
		return dEven[k];
	markEven[k]=1;
	int j = k+1;
	while(j<=m && p[j].F<=p[k].S) {
		if(j==k+1)
			dEven[k]+=nEven[p[j].F-1]-nEven[p[j-1].F-1];
		else
			dEven[k]+=nEven[p[j].F-1]-nEven[p[last[j]].S];
		if(memoizeEven(j)<memoizeOdd(j) ) {
			dEven[k]+=memoizeOdd(j);
		}
		else {
			dEven[k]+=memoizeEven(j);
		}
		if(next[j]==m+1) {
			dEven[k]+=nEven[p[k].S]-nEven[p[j].S];
		}
		else if(p[next[j]].F>p[k].S) {
			dEven[k]+=nEven[p[k].S]-nEven[p[j].S];
		}
		j=next[j];
		
	}
	return dEven[k];

}
int main() {
	scanf("%d",&t);
	for(int i = 0;i<t;i++) {
		readInput();
		sort(p,p+m+1);
		init();
		int ans = memoizeOdd(0);
		printf("%d\n",ans);
	}
	return 0;
}
