//name: Ali Aminian

#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;
int t;
int main() {
	srand(time(0));
	scanf("%d",&t);
	for(int i = 0;i<t;i++) {
		int n;
		cin >> n;
		for(int i = 0;i<n;i++)
			for(int j = 0;j<n;j++) {
				int a;
				scanf("%d",&a);
			}
		for(int i = 0;i<n;i++)
			for(int j = 0;j<n;j++) {
				int a;
				scanf("%d",&a);
			}
	}
	for(int i = 0;i<t;i++) {
		int k = rand()%2;
		if(k)
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
	return 0;
}
