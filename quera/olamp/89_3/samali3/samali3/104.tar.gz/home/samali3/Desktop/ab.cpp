//name: Ali Aminian

#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

const int MAX_N = 1000000+10;

int lef[MAX_N];
int righ[MAX_N];

int n;
int h[MAX_N];

void readInput() {
	scanf("%d",&n);
	for(int i = 0;i<n;i++)
		scanf("%d",&h[i]);
}
void init() {
	//left
	lef[0]=0;
	for(int i = 1;i<n;i++)
		lef[i]=max(lef[i-1],h[i-1]);
	//right
	righ[n-1]=0;
	for(int i = n-2;i>=0;i--)
		righ[i]=max(righ[i+1],h[i+1]);
}
int main() {
	readInput();
	init();
	long long int ans = 0;
	for(int i = 0;i<n;i++) {
		int l = lef[i];
		int r = righ[i];
		int m = min(l,r);
		if(m>h[i])
			ans+=m-h[i];
	}
	printf("%lld\n",ans);
	return 0;
}
