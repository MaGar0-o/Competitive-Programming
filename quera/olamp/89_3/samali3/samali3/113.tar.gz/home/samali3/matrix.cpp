//name: Mohamad Motiei
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <ctime>
using namespace std;
int t;

int main(){
		srand(time(0));
		cin >> t;
		if(t==1)
				cout << "No" << endl;
		else if(t==2)
				cout << "No" << endl << "Yes" << endl;
		else if(t==3)
				cout << "Yes" << endl << "Yes" << endl << "No" << endl;
		else if(t>=12){
				for(int i=0; i<t; i++)
						cout << "Yes" << endl;
		}
		else{
				for(int i=0; i<t; i++){
						if(rand()%2==0)
								cout << "Yes" << endl;
						else 
								cout << "No" << endl;
				}
		}
		return 0;
}
