#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int N=100*100+10, M=5000+10;
int a[N][M], ans=0, n;

int main(){
	 ios::sync_with_stdio(false);
	 cin >> n;
	 int Max=0;
	 for(int i=0; i<n; i++){
		  int x;
		  cin >> x;
		  if(x>Max)
				Max=x;
		  for(int j=0; j<x; j++)
				a[i][j]=1;
	 }
	 bool flag;
	 int t=0;
	 for(int i=Max-1; i>=0; i--){
		  flag=false;
		  for(int j=0; j<n; j++){
				if(a[j][i]==0){
					 t++;
				}
				else{
					 if(flag==true)
						  ans+=t;
					 flag=true;
					 t=0;
				}
		  }
	 }
	 cout << ans << "\n";
	 return 0;
}

