#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int N=10;
int n;

int main(){
		srand(time(0));
		n=rand()%N;
		n++;
		cout << n << endl;
		for(int i=0; i<n; i++)
				cout << rand()%5000+1 << " ";
		cout << endl;
		return 0;
}
