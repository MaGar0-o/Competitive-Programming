//name: Mohamad Motiei
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <set>
using namespace std;
const int N=1000*1000+10;
int a[N];
struct node{
	int first, second;
	bool operator< (const node& A)const{
		if(first==A.first)
			return second<A.second;
		return first>A.first;
	}
};
set< node > s;
int n, aind, bind, ah, bh, ans=0;

void check(int p, int q, int h){
	node temp;
	for(int i=p; i<q; i++){
		ans+=h-a[i];
		temp.first=a[i];
		temp.second=i;
		s.erase(temp);
	}
}

int main(){
	scanf("%d",&n);
	node temp;
	for(int i=0; i<n; i++){
		scanf("%d",&a[i]);
		temp.first=a[i];
		temp.second=i;
		s.insert(temp);
	}
	if(n==1 || n==2){
		printf("0\n");
		return 0;
	}
	temp=*s.begin(); s.erase(s.begin());
	ah=temp.first; aind=temp.second;
	temp=*s.begin(); s.erase(s.begin());
	bh=temp.first; bind=temp.second;
	if(aind>bind){
		swap(aind,bind);
		swap(ah,bh);
	}
	check(aind+1,bind,min(ah,bh));
	while(s.size()!=0){
		temp=*s.begin(); s.erase(s.begin());
		if(temp.second<aind){
			check(temp.second+1,aind,min(temp.first,ah));
			aind=temp.second;
			ah=temp.first;
		}
		else{
			check(bind+1,temp.second,min(temp.first,bh));
			bind=temp.second;
			bh=temp.first;
		}
	}
	printf("%d\n",ans);
	return 0;
}
