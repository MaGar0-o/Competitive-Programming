#include <iostream>
using namespace std;
const int N=100+10, M=100+10;
int n, m;
int mark[N], h[N], ans, g[M][2];

int check(int x){
	int ret=0;
	for(int i=0; i<n; i++)
		h[i]=mark[i];
	for(int i=0; i<m; i++){
		if(x%2==1){
			for(int j=g[i][0]-1; j<g[i][1]; j++){
				h[j]=1-h[j];
			}
		}
		x/=2;
	}
	for(int i=0; i<n; i++){
		if(h[i]%2==1)
			ret++;
	}
	return ret;
}

int main(){
	int x;
	cin >> x;
	cin >> n;
	for(int i=0; i<n; i++){
		cin >> x;
		mark[i]=x%2;
	}
	cin >> m;
	for(int i=0; i<m; i++)
		cin >> g[i][0] >> g[i][1];
	int Max=(1<<m);
	for(int i=0; i<Max; i++){
		int temp=check(i);
		if(temp==29){
			cout << i << endl;
			for(int j=0; j<n; j++)
				cerr << h[j] << " ";
			cerr << endl;
		}
		if(ans<temp)
			ans=temp;
	}
	cout << ans << endl;
	return 0;
}
