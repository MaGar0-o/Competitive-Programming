//name: Mohamad Motiei
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;
const int N=1000*100+10;
struct node{
	int num , oth, sh;
	bool kind;
	bool operator< (const node& A)const{
		if(num==A.num && kind!=A.kind)
			return kind>A.kind;
		else if(num==A.num)
			return oth>A.oth;
		return num<A.num;
	}
};
typedef pair<int,int> P;
vector<int> stack;
vector< node > a;
bool med[N];
pair<int,int> tot[N];
int n, t, ans, m;

void solve(){
	scanf("%d",&n);
	for(int i=0; i<n; i++){
		int x;
		scanf("%d",&x);
		med[i]=x%2;
	}
	scanf("%d",&m);
	for(int i=0; i<m; i++)
		tot[i].first=tot[i].second=0;
	node temp;
	for(int i=0; i<m; i++){
		int x, y;
		scanf("%d%d",&x,&y);
		x--;
		temp.sh=i;
		temp.num=x;
		temp.oth=y;
		temp.kind=0;
		a.push_back(temp);
		temp.num=y;
		temp.oth=x;
		temp.kind=1;
		a.push_back(temp);
	}
	sort(a.begin(),a.end());
	int odd=0, eve=0, ind, last;
	for(int i=0; i<a[0].num; i++){
		if(med[i]==1)
			ans++;
	}
	last=a[0].num;
	stack.push_back(a[0].sh);
	for(int i=1; i<a.size(); i++){
		int now=a[i].num;
		for(int j=last; j<now; j++){
			if(med[j]==1)
				odd++;
			else
				eve++;
		}
		ind=stack[stack.size()-1];
		tot[ind].first+=odd;
		tot[ind].second+=eve;
		if(a[i].kind==1)
			stack.pop_back();
		else
			stack.push_back(a[i].sh);
		last=now;
		odd=0;
		eve=0;
	}
	for(int i=a[a.size()-1].num; i<n; i++){
		if(med[i]==1)
			ans++;
	}
	for(int i=0; i<m; i++){
		//cerr << tot[i].first << " " << tot[i].second << endl;
		ans+=max(tot[i].first,tot[i].second);
	}
	printf("%d\n",ans);
}

int main(){
	scanf("%d",&t);
	for(int i=0; i<t; i++){
		a.clear();
		stack.clear();
		ans=0;
		solve();
	}
	return 0;
}
