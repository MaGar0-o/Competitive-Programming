#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <fstream>
using namespace std;
const int N=100, M=13;
int n, m, ans=0;
bool mark[N+10], best[N+10];
pair<int,int> a[M+10];
ofstream fout("ans.txt");
int ind;

int main(){
	srand(time(0));
	n=rand()%N;
	m=rand()%M;
	if(n==0)
		n++;
	if(m==0)
		m++;
	cout << 1 << endl;
	cout << n << endl;
	for(int i=0; i<n; i++){
		int temp=rand()%1000;
		cout << temp << " ";
		mark[n-i]=temp%2;
	}
	cout << endl;
	cout << m << endl;
	for(int i=0; i<m; i++){
		int en=rand()%n;
		en++;
		int st=rand()%en;
		st++;
		cout << st << " " << en << " ";
		a[i]=make_pair(st,en);
	}
	cout << endl;
	return 0;
}
