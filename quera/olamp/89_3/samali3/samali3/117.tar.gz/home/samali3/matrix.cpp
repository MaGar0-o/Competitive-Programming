//name: Saeed Aqamiri

#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

#define  FR(c,d,i)  for(int i=c;i<=d;i++);

const int N=1005;
int n,A[N*N],T;

struct matrix{
    int   jadval [N][N];
};

struct golabi{
    int adad,satr;
};

bool  operator <(const golabi &g1,const golabi  &g2){
    return  g1.adad<g2.adad;
}

int B[N];
matrix m1,m2;
golabi M1[N*N],M2[N*N];

bool moraba(int a){
  float b=a;
  float c=sqrt(b);
  int d=c;
  return(d*d==a);
}

int emkan (matrix m){
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            A[(i-1)*n+j]=m.jadval[i][j];
    sort(A,A+n*n+1);
    int a=A[1],b=A[2],k=-1;
    for(int i=0;i<=a;i++)
        if(moraba(a-i)&&moraba(b-i)){
            k=i;
            break;
        }
    bool gavab=true;;
    for(int i=1;i<=n*n;i++)
        if(!moraba(A[i]-k))
            gavab=false;
    if (gavab)  return k;
    else        return -1;
}

void radikal (matrix &m) {
    while(emkan(m)!=-1){
        int k=emkan(m);
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                m.jadval[i][j]=sqrt(float(m.jadval[i][j]-k));
    }
}

bool jay(int s1,int s2){
    int k;
    for(int i=1;i<=n;i++)
        if(m1.jadval[s1][1]==m2.jadval[s2][i]){
            k=i-1;
            break;
        }
    for(int i=1;i<=n;i++){
        int h=(i+k)%n;
        if (h==0)  h=n;
        if( m1.jadval[s1][i]!=m2.jadval[s2][h] ){
             return false;
        }
    }
    return true;
}
bool pesar(){
    for(int i=1;i<=n;i++)    B[i]=0;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++){
            M1[(i-1)*n+j].adad=m1.jadval[i][j];
            M1[(i-1)*n+j].satr=i;
            M2[(i-1)*n+j].adad=m2.jadval[i][j];
            M2[(i-1)*n+j].satr=i;
        }
         sort(M1,M1+n*n+1);
         sort(M2,M2+n*n+1);
    int k=M1[1].adad-M2[1].adad;
    for(int i=2;i<=n*n;i++)
        if(M1[i].adad-M2[i].adad!=k) return false;
    for(int i=1;i<=n*n;i++){
        int s1=M1[i].satr,s2=M2[i].satr;
        if(B[s1]!=s2&&B[s1]!=0) return false;
        else         B[s1]=s2;
    }

    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            m2.jadval[i][j]+=k;
    for(int i=1;i<=n;i++)
        if(!jay(i,B[i]))  return false;
    return true;
}
int main(){
    matrix m;
    cin>>T;
    for(int tt=1;tt<=T;tt++){
        cin>>n;
        for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            cin>>m1.jadval[i][j];
        for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            cin>>m2.jadval[i][j];
        radikal(m1);
        radikal(m2);
        if(pesar())   cout<<"Yes"<<endl;
        else          cout<<"No"<<endl;
        }
     return 0;
}
