//name: Saeed Aqamiri

#include <iostream>

using namespace std;

int main(){
    long long a,bq,n,jam=0,ja=1;
    cin>>n;
    cin>>a;
    bq=a;
    for(int i=2;i<=n;i++){
        cin>>a;
        if(a<bq)
            jam=jam+bq-a;
        if(a>=bq){
            bq=a;
            ja=i;
        }
    //cout<< jam <<endl;
    }
    if(ja!=n)
    jam=jam-(bq-a)*(n-ja);
    cout<< jam;//<<" "<<ja;
    return 0;
}
