for((i=1;i<=1000*1000;i++))
do
echo 1000000
echo 1000
done
