#include <iostream>
#include <vector>
using namespace std;
int main(){
cout<<"1000000"<<endl;
for(int i=1;i<=1000000;i++){
 	if(i==1000){cout<<"0"<<" ";continue;}
	cout<<"1000 ";
}
cout<<endl;
return 0;
}
