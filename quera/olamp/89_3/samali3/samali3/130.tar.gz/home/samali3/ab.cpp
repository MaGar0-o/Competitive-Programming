//name: Mostafa Karimi
#include <iostream>
#include <vector>
#include <set>
#include <cstdio>
using namespace std;
/***************************************************************/
int n;
vector <int> a[1000+10];
set <int> s;
set <int> ::iterator it,itr;    
const int maxn=1000*1000+10;
int match[maxn];
/**************************************************************/
void vorode(){
	scanf("%d",&n);
	int t;
	for(int i=0;i<n;i++){
		scanf("%d",&t);
//		cerr<<"t="<<t<<endl;
		match[i]=t;
		if(a[t].size()==2) a[t].pop_back();
		a[t].push_back(i);
	}
}
/**************************************************************/
void relax(int u){
//	cerr<<"u="<<u<<endl;
	int p,q;
	it=s.lower_bound(u);
	if(it==s.begin() || it==s.end()){ s.insert(u);}
	else{          
		itr=it;itr--;p=*itr;q=*it;
//		cerr<<"p="<<p<<"q="<<q<<endl;
		if(match[p]<match[u] && match[u]<match[q]) s.insert(u);
	}
}
void hall(){
	for(int i=1000;i>=0;i--){
		if(a[i].size()==0) continue;
		if(a[i].size()==1){
			relax(a[i][0]);
		}
		else{relax(a[i][0]);relax(a[i][1]);}
	}
}
/*************************************************************/
void khoroj(){
	int ans=0;
	int u,v;
	for(int i=0;i<n;i++){
		it=s.lower_bound(i);
		u=match[i];
		if(it==s.begin()) continue;
		itr=it;itr--;
		if(*it==i) it++;
		if(it==s.end()) continue;
		v=min(match[*it],match[*itr]);
		if(v<=u) continue;
		ans+=v-u;
	}
	printf("%d\n",ans);
}
/*************************************************************/
int main(){
	vorode();
	hall();
	khoroj();
	return 0;
}
