//name: Mostafa Karimi 

#include <iostream>
#include <vector>
#include <set>
#include <cstring>
#include <algorithm>
#include <cstdio>
using namespace std;
/*************************************************************/
set <pair<int,int> > s;
set <pair<int,int> > ::iterator it,itr,itra;
const int inf=1000*1000*1000;
const int maxn=100*1000+10;
vector <int> a[maxn];
int t,n,m;
int D[maxn];
bool mark[maxn];
bool Mark[maxn];
int ped[maxn];
bool C[maxn];
struct P{
	int x,y;
	P(int x,int y):x(x),y(y){}
};

struct node{
	int x,y,w;
	node(int x,int y):x(x),y(y){w=y-x;}
};
bool operator <(const node &a,const node &b){
	if(a.w==b.w) return a.x<b.x;
	return a.w<b.w;
}
vector <node> I;
/***************************************************************/
void vorode(){
	scanf("%d",&n);
	D[0]=0;
	int u,v;
	for(int i=1;i<=n;i++){
		scanf("%d",&u);
		if(u%2){ D[i]=D[i-1]+1;C[i]=1;}
		else D[i]=D[i-1];
	}
	scanf("%d",&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&u,&v);
		I.push_back(node(u,v));	
	}
	sort(I.begin(),I.end());
}
/*************************************************************/
void find_ped(){
//	cerr<<"mm="<<m<<endl;
	for(int i=0;i<m;i++){
//		cerr<<I[i].x<<" "<<I[i].y<<endl;
		it=s.lower_bound(make_pair(I[i].x,0));
//		cerr<<it->second<<endl;
		itr=s.upper_bound(make_pair(I[i].y,inf));
//		cerr<<itr->second<<endl;
		for(;it!=itr;){
			a[i].push_back(it->second);
//			cerr<<"ped"<<it->second<<"="<<i<<endl;
			itra=it;it++;
			s.erase(itra);
		}
		s.insert(make_pair(I[i].x,i));
	}
}
int find(int &u,int &v,int x,int y){
//	cerr<<"x=  "<<x<<endl;
	if(x>y) return x;
	if(x==y){
		if(!Mark[y] && C[x]) v++;
		else if(!Mark[y]) u++;
		Mark[y]=true;
//		cerr<<"u="<<u<<" "<<"v="<<v<<endl;
		return y+1;
	}
//	cerr<<"Mark["<<x<<"]="<<Mark[x]<<endl;
//	cerr<<"U="<<u<<"V="<<v<<endl;
	if(!Mark[x] && C[x]) v++;
	else if(!Mark[x]) u++;
	Mark[x]=true;
//	cerr<<"U="<<u<<" "<<"V="<<v<<endl;
	return ped[x]=find(u,v,ped[x],y);
}
P dfs(int u){
	mark[u]=true;
	if(a[u].size()==0){
		int k=0,kk=0;
//		cerr<<I[u].x<<" "<<I[u].y<<endl;
		find(k,kk,I[u].x,I[u].y);
//		cerr<<u<<"  ////////// "<<min(k,kk)<<" "<<max(k,kk)<<endl;
		return P(min(k,kk),max(k,kk));
	}
	P h(0,0);int v=0,mm=0,mi=0,k;
	int uu=0;
	for(int i=0;i<a[u].size();i++){
		v=a[u][i];
		h=dfs(v);
		mi+=h.x;mm+=h.y;
	}
	uu=0;v=0;
	find(uu,v,I[u].x,I[u].y);mm+=max(uu,v);mi+=min(uu,v);
	k=     I[u].y-I[u].x    +   1;
//	cerr<<u<<" "<<min(mi,k-mm)<<" "<<max(mm,k-mi)<<endl;
	return P(      min(mi,k-mm)      ,    max(mm,k-mi)      );
}
/*************************************************************/
void khoroj(){
	find_ped();
	for(int i=0;i<=n;i++){
		ped[i]=i+1;
	}
	P h(0,0);
	int ans=0;
	for(int i=m-1;i>=0;i--){
		if(!mark[i]){
			h=dfs(i);
			ans+=h.y;
		}
	}
	printf("%d\n",ans);
}
/**********************************************************/
int main(){
	scanf("%d",&t);
//	cerr<<"t="<<t<<endl;
	for(int i=1;i<=t;i++){
		for(int j=0;j<maxn-1;j++) a[i].resize(0);
		s.clear();
		I.clear();
		memset(mark,0,sizeof mark);
		memset(D,0,sizeof D);
		memset(Mark,0,sizeof Mark);
		memset(C,0,sizeof C);
		vorode();
		khoroj();
	}
	return 0;
}
