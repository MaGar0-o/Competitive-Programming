//name: Mostafa Karimi
#include <iostream>
#include <vector>
#include <cstdio>
#include <algorithm>
using namespace std;
const int maxn=1000;
pair <int,int> a[maxn][maxn];
struct node{
	int x,y,w;
	node(int x,int y,int w):x(x),y(y),w(w){}
};
bool operator <(const node &a,const node &b){
	return a.w<b.w;
}
vector <node> one;
vector <node> two;
int n;
void vorode(){
	scanf("%d",&n);
	int t;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			scanf("%d",&t);
			one.push_back(node(i,j,t));
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			scanf("%d",&t);
			two.push_back(node(i,j,t));
		}
	}
}
bool solve(int num){
	if(one[num].w%2==two[num].w%2) return true;
	return false;
}
bool ans=true;
void hall(){
	sort(one.begin(),one.end());
	sort(two.begin(),two.end());
	bool tt=solve(0);
	for(int i=0;i<n*n;i++){
		if(solve(i)!=tt)ans=false;
		a[one[i].x][one[i].y]=make_pair(two[i].x,two[i].y);
	}
	if(!ans){ printf("No\n");return;}
	int k;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			k=j+1;
			if(j==n) k=1;
			if(a[i][k].first==a[i][j].first){
				if(a[i][k].second==a[i][j].second+1) ans=true;
				else if(a[i][k].second==1 && a[i][j].second==n) ans=true;
				else ans=false;
			}
			else ans=false;
		}
	}
	if(ans) printf("Yes\n");
	else printf("No\n");
}
int main(){
	int t;
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		one.clear();
		two.clear();
		vorode();
		hall();
	}
	return 0;
}
