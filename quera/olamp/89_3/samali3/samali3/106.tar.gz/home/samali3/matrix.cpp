//name: Mohamadjavad Naderi
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <vector>
using namespace std;
const int MAXn=1000+5;
int t , n ;
struct tmp{
	int x , y;
	int num;
	tmp(int x , int y , int num):x(x),y(y),num(num){}
};
vector <tmp> tab1 , tab2;
int mat1[MAXn][MAXn];
int mat2[MAXn][MAXn];
int pr1[MAXn][MAXn] , pr2[MAXn][MAXn];
int r[MAXn];
////////////////////////////////////////////////////////////////////////////////
bool operator < (const tmp &p , const tmp & q){
	return (p.num < q.num);
} 
////////////////////////////////////////////////////////////////////////////////
void read(){
	tab1.clear();
	tab2.clear();
	scanf("%d" , &n);
	for(int i=0 ; i<n ; i++)
		for(int j=0 ; j<n ; j++){
			scanf("%d",&mat1[i][j]);
			tab1.push_back(tmp(i,j,mat1[i][j]));
		}
	for(int i=0 ; i<n ; i++)
		for(int j=0 ; j<n ; j++){
			scanf("%d",&mat2[i][j]);
			tab2.push_back(tmp(i,j,mat2[i][j]));
		}
}
////////////////////////////////////////////////////////////////////////////////
bool ok(int p ,int q){
	int k=tab2[pr1[p][0]].y;
	bool b1=mat1[p][0]>mat2[q][k];
	for(int i=0 ; i<n ; i++)
		if(pr1[p][i]!=pr2[q][(i+k)%n] || (b1&&mat1[p][i]<mat2[q][(i+k)%n]) || (!b1 &&(mat1[p][i]>mat2[q][(i+k)%n])) )
			return false;
	
	return true;
}
////////////////////////////////////////////////////////////////////////////////
void solve(){
	sort(tab1.begin(),tab1.end());
	sort(tab2.begin(),tab2.end());
	fill(r,r+n,-1);

	for(int i=0 ; i<n*n ; i++)
		pr1[tab1[i].x][tab1[i].y] = pr2[tab2[i].x][tab2[i].y] = i;
	
	for(int i=0 ; i<tab1.size() ; i++){
		if(r[tab1[i].x]==-1){r[tab1[i].x]=tab2[i].x; continue;}
		if(r[tab1[i].x]!=tab2[i].x){
			cout << "No" << endl;
			return ;
		}
	}

	for(int i=0 ; i<n ; i++)
		if(!ok(i,r[i])){
			cout << "No" << endl;
			return ;
		}
	cout << "Yes" << endl;

}
////////////////////////////////////////////////////////////////////////////////
int main(){
	scanf("%d",&t);
	for(int i=0 ; i<t ; i++){
		read();
		solve();
	}
	return 0;
}
