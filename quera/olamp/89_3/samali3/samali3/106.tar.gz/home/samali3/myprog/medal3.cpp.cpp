//name: Mohamadjavad Naderi
#include <cstdio>
#include <algorithm>
#define zero(i,j) (z[(j)]-z[(i)-1])
#define one(i,j) (((j)-(i)+1)-(z[(j)]-z[(i)-1]))
using namespace std;
const int MAXn=100*1000+10;
const int MAXm=100*1000+10;
int t , n , m ;
bool first[MAXn];
struct interval{
	int x,y,l;
};
interval b[MAXm];
bool solved[MAXm];
int numso[MAXm] , numsz[MAXn];
int z[MAXn];
////////////////////////////////////////////////////////////////////////////////
bool operator <(const interval &p , const interval &q ){
	return (p.x==q.x?p.l>q.l:p.x<q.x);
}
////////////////////////////////////////////////////////////////////////////////
void read(){
	scanf("%d",&n);
	int x , y;
	for(int i=0 ; i<n ; i++){
		scanf("%d",&x);
		first[i]=x%2;
	}
	scanf("%d",&m);
	for(int i=0 ; i<m ; i++){
		scanf("%d%d", &x , &y );  x--;  y--;
		b[i].x=x , b[i].y=y , b[i].l=b[i].y-b[i].x+1; 
	}
/*
	for(int i=0 ; i<n ; i++)
		printf("%d ",first[i]);
	printf("\n");
*/
	
}
////////////////////////////////////////////////////////////////////////////////
void initialize(){
	z[0]=1-first[0];
	for(int i=0 ; i<n ; i++)
		z[i]=z[i-1]+1-first[i];
}
////////////////////////////////////////////////////////////////////////////////
void num(int k){ // bishtarin tedade yek-ha va sefrha dar bazeye k om
	if(solved[k]) return ;
	solved[k]=true ;
	if(k==m-1 || b[k+1].x>b[k].y){
		numso[k] = numsz[k] = max(one(b[k].x,b[k].y),b[k].l-one(b[k].x,b[k].y));
		printf("%d  %d %d  %d %d\n",k,b[k].x , b[k].y , numso[k] , numsz[k]);
		return ;
	}

	int anso=0;
	int ansz=0;

	if(b[k+1].x>b[k].x){
		anso+=one( b[k].x , b[k+1].x-1); 
		ansz+=zero( b[k].x , b[k+1].x-1 );
	}
	int j;
	for(j=k+1 ; j<m && b[j].x<=b[k].y ; j++){
		if(j>k+1 && b[j].x<=b[j-1].y) continue;
		//if gap
		if(b[j].x-b[j-1].y>1){
			anso+=one( b[j-1].y+1 , b[j].x-1);
			ansz+=zero( b[j-1].y+1 , b[j].x-1 );
		}
		num(j);
		anso+=numso[j];
		ansz+=numsz[j];
	}
	j--;
	if(b[j].y<b[k].y){
		anso+=one( b[j].y+1 , b[k].y);
		ansz+=zero( b[j].y+1 , b[k].y );
	}
	numso[k]=max(anso , ansz) , numsz[k]=max(ansz,anso);
			printf("%d  %d %d  %d %d\n",k,b[k].x , b[k].y , numso[k] , numsz[k]);
}
////////////////////////////////////////////////////////////////////////////////
void solve(){
	sort(b,b+m);
	/*
	for(int i=0 ; i<m ; i++)
		printf("%d %d %d\n",b[i].x,b[i].y,b[i].l);
		*/
	fill(&solved[0] , &solved[m] , false);
	int ans=0;
	for(int i=0 ; i<m ; i++){
		if(solved[i]) continue;
		num(i);
		printf("%d %d\n",numso[i],numsz[i]);
		ans+=numso[i];
	}
	printf("%d\n",ans);
}
////////////////////////////////////////////////////////////////////////////////
int main(){
	scanf("%d",&t);
	for(int i=0 ; i<t ; i++){
		read();
		initialize();
		solve();
	}
	return 0;
}
