//name: Mohamadjavad Naderi
#include <iostream>
#include <cstdio>
using namespace std;
const int MAXn=1000*1000+10;
int n;
int hei[MAXn];
int maxi[MAXn];
////////////////////////////////////////////////////////////////////////////////
void read(){
	scanf("%d",&n) ;
	for(int i=0 ; i<n ; i++)
		scanf("%d",&hei[i]);
}
////////////////////////////////////////////////////////////////////////////////
void solve(){

	int bish=0;
	for(int i=n-1 ; i>=0 ; i--){
		if(hei[i]>bish)  bish=hei[i];
		maxi[i]=bish;
	}

//	for(int i=0 ; i<n ; i++) cerr << maxi[i] << " "; cerr << endl;

	int v=0;
	int j;

	for(int i=1 ; i<n ; i++){

		if(hei[i]>=hei[i-1]) continue;

		if(maxi[i]>=hei[i-1])
			for(j=i ; hei[j]<hei[i-1] ; j++)
				v+=hei[i-1]-hei[j];
		else
			for(j=i ; hei[j]<maxi[i] ; j++)
				v+=maxi[i]-hei[j];
		i=j;

	}

	cout << v << endl;
}
////////////////////////////////////////////////////////////////////////////////
int main(){
	read();
	solve();
	return 0;
}
