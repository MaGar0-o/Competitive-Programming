//name: Mohamadjavad Naderi
#include <cstdio>
#include <vector>
using namespace std;
const int MAXt=20+2;
const int MAXn=100*1000+10;
const int MAXm=100*1000+10;
int t , n , m ;
bool first[MAXn];
bool solved[MAXm];
int bx[MAXm] , by[MAXm]; , bl[MAXm];
////////////////////////////////////////////////////////////////////////////////
void read(){
	scanf("%d",&n);
	int x , y;
	for(int i=0 ; i<n ; i++){
		scanf("%d",&x);
		first[i]=x%2;
	}
	scanf("%d",&m);
	for(int i=0 ; i<m ; i++){
		scanf("%d%d",&bx[i],&by[i]);  bx[i]--;   by[i]--;
		bl[i]=by[i]-bx[i]+1;
	}
	for(int i=0 ; i<baze.size() ; i++)
		printf("%d %d %d\n",baze[i].x , baze[i].y,baze[i].l);
	/*
	for(int i=0 ; i<n ; i++)
		printf("%d ",first[i]);
	printf("\n");
	*/
}
////////////////////////////////////////////////////////////////////////////////
void solve(){
	fill(&solved[0] , &solved[m] , false);
	for(int i=0 ; i<m ; i++){
		if(solved[i]) continue;
		
	}
}
////////////////////////////////////////////////////////////////////////////////
int main(){
	interval tmp;
	for(int i=0 ; i<MAXm ; i++) baze.push_back(tmp);
	
	scanf("%d",&t);
	for(int i=0 ; i<t ; i++){
		read();
		solve();
	}
	return 0;
}
