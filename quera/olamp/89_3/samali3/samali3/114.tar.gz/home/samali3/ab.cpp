//name: Laya Ghodrati
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
const int maxn=1000*1000+10;
int n;
long long a[maxn];
int next[maxn];
int prev[maxn];
int b[maxn];
long long sum=0;
vector<int> A;
int main(){
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	//	a[i]=rand()%1000;
	next[n-1]=n;
	for(int i=n-2;i>=0;i--){
		b[i]=0;
		if(a[i]<a[i+1]){
			if(next[i+1]==n || a[i+2]<a[i+1])
				next[i]=i+1;
			else
				next[i]=next[i+1];
		//	b[i]=a[i+1]-a[i];
	//		cerr<<i<<" "<<next[i]<<endl;
		}
		else{
			int y=next[i+1];
		//	cin>>tep;
			while(y!=n && a[y]<a[i])
				y=next[y];
			if(y==n-1 || y==n)
				next[i]=y;
			else if(a[y+1]<a[y])
				next[i]=y;
			else
				next[i]=next[y];
	//		cerr<<i<<" "<<next[i]<<endl;
		}
	}
	int u=0;
	A.push_back(0);
	int r=0;
	while(r<n){
		while(next[r]==n && r!=n-1)
			r=r+1;
		A.push_back(next[r]);
		r=next[r];
	//	cerr<<r<<endl;
	}
//	if(A[A.size()-1]==n)
//		A.resize(A.size()-1);
	for(int i=0;i<A.size()-1;i++){
		int y=min(a[A[i]],a[A[i+1]]);
		for(int j=A[i]+1;j<A[i+1];j++){
			if(y>=a[j])
				sum+=y-a[j];
		}
	}
	cout<<sum<<endl;
	return 0;
}

