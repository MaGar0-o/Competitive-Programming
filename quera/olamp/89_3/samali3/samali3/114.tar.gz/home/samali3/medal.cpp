//name: Laya Ghodrati
#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
const int maxn=1000+10;
int T;
int n,m;
int a[maxn];
int b[2][maxn];
vector<int> B[maxn],A[maxn];
int ent[maxn],ex[maxn];
int ft[maxn];
int ans;
int p;
bool mark[maxn],mark2[maxn];
int tool[maxn];
int best[maxn];
bool yal[maxn][maxn];
void check(int u){
	int bia=0,na=0;
	int size=tool[u];
	int ted=0;
	for(int j=0;j<B[u].size();j++){
		int y=B[u][j];
		na+=best[y];
		bia+=tool[y]-best[y];
		size-=tool[y];
	}
	for(int i=b[0][u];i<=b[1][u];i++)
		if(!mark[i] && a[i]==1)
			ted++;
	na+=ted;
	bia+=size-ted;
	best[u]=max(bia,na);
}

void finish(){
	queue<int> L;
	memset(mark,0,sizeof(mark));
	memset(best,0,sizeof(best));
	for(int i=0;i<m;i++){
	//	cerr<<i<<" "<<ent[i]<<endl;
		if(ent[i]==0){
			L.push(i);
	//		cerr<<i<<" ";
			for(int j=b[0][i];j<=b[1][i];j++){
				mark[j]=true;
				if(a[j]==1)
					best[i]++;
			}
			mark2[i]=true;
			best[i]=max(best[i],tool[i]-best[i]);
		}
	}
	while(!L.empty()){
		int head=L.front();
	//	cerr<<head<<" ";
		L.pop();
		ft[p]=head;
		check(head);
		p++;
		mark2[head]=true;
		for(int i=0;i<A[head].size();i++){
			ent[A[head][i]]--;
			if(ent[A[head][i]]==0 && !mark2[A[head][i]]){
				mark2[A[head][i]]=true;
				L.push(A[head][i]);
			}
		}
		for(int i=b[0][head];i<=b[1][head];i++)
			mark[i]=true;
	}
//	cerr<<endl;
}
int main(){
	ios::sync_with_stdio(false);
	cin>>T;
	for(int z=0;z<T;z++){
		cin>>n;
		memset(yal,0,sizeof(yal));
		ans=0;
		for(int i=0;i<maxn;i++){
			A[i].clear();
			B[i].clear();
		}
		memset(best,0,sizeof(best));
		for(int i=0;i<n;i++){
			cin>>a[i];
			a[i]=a[i]%2;
		}
		cin>>m;
		for(int i=0;i<m;i++)
			B[m].push_back(i);
		for(int i=0;i<m;i++){
			cin>>b[0][i]>>b[1][i];
			b[0][i]--; b[1][i]--;
			tool[i]=b[1][i]-b[0][i]+1;
	//		B[m].push_back[i];
			A[i].push_back(m);
			ex[i]++;
			ent[m]++;
		}
		b[0][m]=0;
		b[1][m]=n-1;
/*	for(int i=0;i<=m;i++)

	cerr<<b[0][i]<<" "<<b[1][i]<<endl;
		cerr<<endl;*/
		for(int i=0;i<m;i++)
			for(int j=0;j<m;j++){
			//	cerr<<i<<" "<<j<<" "<<b[0][i]<<" "<<b[0][j]<<b[1][i]<<" "<<b[1][j]<<endl;
				if(i!=j && b[0][i]<=b[0][j] && b[1][i]>=b[1][j] && !yal[i][j]){
					B[i].push_back(j);
					yal[i][j]=true;
					yal[j][i]=true;
			//		cerr<<i<<" "<<j<<endl;
					A[j].push_back(i);
					ent[i]++;
					ex[j]++;
				}
			}
		m++;
		finish();
		for(int i=0;i<m;i++)
			if(ex[i]==0)
				ans+=best[i];
		
		cout<<ans<<endl;
	}
	return 0;
}
