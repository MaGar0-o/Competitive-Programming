//name: Majid Farhadi
#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;
//	O(n*n + m*n) // 70%

const int maxN = 1100;
const int maxM = 1100;

struct general{
	int st;
	int en;
};
bool operator <(const general &a, const general &b){
	if (a.st < b.st)
		return 1;
	if (a.st > b.st)
		return 0;
	return (a.en > b.en);
}

int m,n;

//	about generals:
int cap[maxM];
int def[maxM];
general gen[maxM];

bool s[maxN];
int one[maxN][maxN];
int ans;

bool DFSmark[maxM];	//	marking generals!!!

void INPUT();
void fill_one();
void fill_cap_def();

void DFS(int v, int fat){	//	vertex & fathe
	DFSmark[v] = 1;

	cap[fat] -= cap[v];
	def[fat] -= def[v];

	for (int i = v+1; (gen[i].en <= gen[v].en)&&(i <= n); i++)
		if (DFSmark[i] == 0)
			DFS(i, v);

	ans += max(cap[v]-def[v], def[v]);
}

void re_set(){
	ans = 0;
	for (int i = 1; i <= m; i++)
		DFSmark[i] = 0;
}

int main(){
	int T;
	scanf("%d", &T);
	for (int counter = 0; counter < T; counter++){

	INPUT();
	
	re_set();

	sort(&gen[1], &gen[m+1]);
	fill_one();
	/*
	for (int i = 1; i <= n; i++)
		for (int j = i; j <= n; j++)
			cerr << i << j << " " << one[i][j] << endl;
	 */
	fill_cap_def();	

	ans += one[1][n];
	for (int i = 1; i <= n; i++)
		if (!DFSmark[i]){
			ans -= one[gen[i].st][gen[i].en];
			DFS(i, 0);
		}

	cout << ans << endl;
	
	}

	return 0;
}

void INPUT(){
	scanf("%d", &n);
	int x;
	for (int i = 1; i <= n; i++){
		scanf("%d", &x);
		s[i] = bool(x%2);
	}

	scanf("%d", &m);
	for (int i = 1; i <= m; i++){
		scanf("%d", &gen[i].st);
		scanf("%d", &gen[i].en);
	}
}

void fill_one(){
	for (int i = 1; i <= n; i++)
		if (s[i] == 1)
			one[i][i] = 1;
		else
			one[i][i] = 0;
	for (int len = 2; len <= n; len++)
		for (int i = 1; i <= n-len+1; i++)
			one[i][i+len-1] = one[i][i]+one[i+1][i+len-1];
}

void fill_cap_def(){
	for (int i = 1; i <= m; i++){
		cap[i] = gen[i].en - gen[i].st +1;
		def[i] = one[gen[i].st][gen[i].en];
	}
}
