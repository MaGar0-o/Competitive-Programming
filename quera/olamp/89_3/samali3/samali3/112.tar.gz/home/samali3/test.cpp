//name: Majid Farhadi

#include <iostream>
#include <cstdio>
#include <algorithm>

#define print(x) cerr << ((#x)) << ": " << ((x)) << endl
using namespace std;

int a[2][5] = {{5,4,3,2,1},{0,8,9,7,6}};

int main(){
	int x = min_element(a[1], a[1]+5) - a[1];
	print(x);

	return 0;
}
