//name: Majid Farhadi

#include <iostream>
#include <cstdio>
#include <algorithm>

#define print(x) cerr << ((#x)) << ": " << ((x)) << endl
using namespace std;

const int Gmax = 1010;

int n;

int index[Gmax];

int a[Gmax][Gmax];
int b[Gmax][Gmax];
int A[Gmax][Gmax];
int B[Gmax][Gmax];

void INPUT();
void PRE_SET();

int main(){
	//	DONT FORGET T!!!

	INPUT();
	PRE_SET();


	////////////////////
}

void INPUT(){
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			scanf("%d", &b[i][j]);
}

bool comp_a(int x, int y){
	return a[x][0] < a[y][0];
}

bool comp_b(int x, int y){
	return b[x][0] < b[y][0];
}

int mymin_a(int j){
	int r = 0;
	for (int i = 1; i < n; i++)
		if (a[j][i] < a[r][j])
			r = i;
	return r;
}

int mymin_b(int j){
	int r = 0;
	for (int i = 1; i < n; i++)
		if (b[j][i] < b[r][j])
			r = i;
	return r;
}

void PRE_SET(){
	int me;	//minimum element's index!
	for (int i = 0; i < n; i++){
		index[i] = i;
		me = mymin_a(i);
		for (int j = 0; j < n; j++)
			A[i][j] = a[i][(me+i)%n];
	}
	sort(index, index+n, comp_a);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = A[index[i]][j];

	print(a[0][0]);

	for (int i = 0; i < n; i++){
		me = min_element(&b[i][0], &b[i][n]) - &b[i][0];
		for (int j = 0; j < n; j++)
			B[i][j] = b[i][(me+i)%n];
	}
	sort(index, index+n, comp_b);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			b[i][j] = B[index[i]][j];
	print(b[0][0]);
}
