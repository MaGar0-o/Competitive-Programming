//name: Majid Farhadi
#include <iostream>
#include <cstdio>

using namespace std;

const int maxN = 1000*1000 +100;

int n;
int city[maxN];
int st, en;
int left_pros[maxN];
int right_pros[maxN];
int sum;

void INPUT();
void set_st_en(){
	st = 1;
	en = n;
	while(city[st] <= city[st+1])
		st++;
	while(city[en-1] >= city[en])
		en--;
}

void LEFT(){
	int cur = st+1;
	int top = st;
	while(cur < en){
		if (city[cur] > city[top]){
			top = cur;
			cur++;
			continue;
		}
		left_pros[cur] = city[top]-city[cur];
		cur++;
	}
}
void RIGHT(){
	int cur = en-1;
	int top = en;
	while(cur > st){
		if (city[cur] > city[top]){
			top = cur;
			cur--;
			continue;
		}
		right_pros[cur] = city[top]-city[cur];
		cur--;
	}
}

int main(){
	INPUT();
	set_st_en();
	if (st >= en){
		cout << 0 << endl;
		return 0;
	}

	LEFT();
	RIGHT();

	for (int i = 1; i <= n; i++)
		sum += min(left_pros[i], right_pros[i]);

	cout << sum << endl;

	return 0;
}

void INPUT(){
	scanf("%d", &n);
	for (int i = 1; i <= n; i++){
		scanf("%d", &city[i]);
		city[i]++;	//	if it was 0!!!
	}
}
