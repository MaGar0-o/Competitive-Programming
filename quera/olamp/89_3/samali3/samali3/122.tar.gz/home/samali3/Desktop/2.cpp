//name: Amir Kafshdar Goharshadi

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


struct baze{
  int index;
  int start;
  int end;
  void print()
  {
    cerr<<start<<"::"<<end<<endl;
  }
  void read()
  {
    cin>>start>>end;
  }
  bool has(baze x)
  {
    return ((x.start>=start)&&(x.end<=end));
  }
  int parent;//index of parent
  vector<int> children;//indices of children
};

vector <baze> all;

void insert(baze &neww,baze &place)
{
  for(int i=0;i<place.children.size();i++)
    {
      baze &check=all[place.children[i]];
      if(check.has(neww))
	{
	  insert(neww,check);
	  return ;
	}
    }
  all.push_back(neww);
  place.children.push_back(all.size()-1);
  all[all.size()-1].index=all.size()-1;
  all[all.size()-1].parent=place.index;
  cerr<<"Inserted to:"<<endl;
  place.print();
}

int main()
{
  //code here
  int n;
  cin>>n;
  baze root;
  root.start=1;
  root.end=n;
  //the code is 1-based
  //vector<baze> all;
  all.push_back(root);
  bool fard[n+1];
  fard[0]=false;
  for(int i=1;i<=n;i++)
    {
      int x;
      cin>>x;
      if(x%2==1)
	fard[i]=true;
    }
  //reading generals; :D //what was the semicolon for?
  int m;
  for(int i=0;i<m;i++)
    {
      baze neww;
      neww.read();
      insert(neww,all[0]);
    }
  //end of code
  return 0;
}
