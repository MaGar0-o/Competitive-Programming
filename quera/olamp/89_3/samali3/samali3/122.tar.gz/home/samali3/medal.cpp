//name: Amir Kafshdar Goharshadi

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int INF=(-1u)/2;

vector<short> values;

struct baze{
  int start;
  int end;
  int odd;
  int even;

  void print()
  {
    cerr<<start<<":::"<<end<<endl;
  }

  void read()
  {
    cin>>start>>end;
  }

  void init()
  {
    odd=0-INF;
    even=0-INF;
    start=end=0;
  }
  
  bool contains(baze t)
  {
    return ((t.start>=start)&&(t.end<=end));
  }

  vector<baze> children;
  
};

void insert(baze &neww,baze &place)
{
  //cerr<<"Checking with:"<<endl;
  // place.print();
  for(int i=0;i<place.children.size();i++)
    {
      if(place.children[i].contains(neww))
	{
	  insert(neww,place.children[i]);
	  return ;
	}
    }
  place.children.push_back(neww);
  //  cerr<<"Added to:"<<endl;
  //place.print();
}



void maximize(baze &x)
{
  //done before
  if(x.odd!=0-INF||x.even!=0-INF)
    return;
  //all cases
 
  for(int i=0;i<x.children.size();i++)
    maximize(x.children[i]);

  int maximumodd,maximumeven;
  maximumodd=maximumeven=0;

  //not doing x
  {
  int n=values.size(); //number of soldiers
  bool processed[n];
  for(int i=0;i<n;i++)
    processed[i]=false;
  for(int i=0;i<x.children.size();i++)
    {
      maximumodd+=x.children[i].odd;
      maximumeven+=x.children[i].even;
      for(int j=x.children[i].start;j<=x.children[i].end;j++)
	processed[j]=true;
    }
  for(int i=x.start;i<=x.end;i++)
    {
      if(processed[i]==false)
	{
	  if(values[i]%2==0)
	    maximumeven++;
	  else
	    maximumodd++;
	}
    }
  }
  //doing x
  {
  int maxodd,maxeven;
  maxodd=maxeven=0;
  int n=values.size();
  bool processed[n];
  for(int i=0;i<n;i++)
    processed[i]=false;
  for(int i=0;i<x.children.size();i++)
    {
      maxodd+=x.children[i].even;
      maxeven+=x.children[i].odd;
      for(int j=x.children[i].start;j<=x.children[i].end;j++)
	processed[j]=true;
      
    }
  for(int i=x.start;i<=x.end;i++)
    {
      if(processed[i]==false)
	{
	  if(i%2==0)
	    maxodd++;
	  else
	    maxeven++;
	}
    }
  maximumodd=max(maximumodd,maxodd);
  maximumeven=max(maximumeven,maxeven);
  }
  x.even=maximumeven;
  x.odd=maximumodd;
  //cerr<<"For:";
  //x.print();
  //cerr<<"Odd:"<<x.odd<<" even:"<<x.even<<endl;
}



int main1()
{
  values.resize(0);
  values.push_back(0);
  //code here
  int n; //number of soldiers
  cin>>n;
  baze kol;
  kol.init();
  kol.start=1;
  kol.end=n;
  // kol.print();
  for(int i=0;i<n;i++)
    {
      int x;
      cin>>x;
      values.push_back(x%2);
    }
  int m;
  cin>>m;
  for(int i=0;i<m;i++)
    {
      baze neww;
      neww.init();
      neww.read();
      insert(neww,kol);
    }
  //end of code
  maximize(kol);
  cout<<kol.odd<<endl;
  return 0;
}

int main()
{
  int t;
  cin>>t;
  for(int i=0;i<t;i++)
    main1();
  return 0;
}
