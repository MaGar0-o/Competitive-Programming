//name: Amir Kafshdar Goharshadi

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector<short> values;

struct baze{
  int start;
  int end;
  int odd;
  int even;

  void read()
  {
    cin>>start>>end;
  }

  void init()
  {
    odd=0-INF;
    even=0-INF;
    start=end=0;
  }
  
  bool contains(baze t)
  {
    return ((t.start>=start)&&(t.end<=end));
  }

  vector<baze> children;
  
};


int main()
{
  values.resize(0);
  values.push_back(0);
  //code here
  int n; //number of soldiers
  cin>>n;
  baze kol;
  kol.start=1;
  kol.end=n;
  kol.init();
  for(int i=0;i<n;i++)
    {
      int x;
      cin>>x;
      values.push_back(x%2);
    }
  int m;
  cin>>m;
  
  //end of code
  return 0;
}
