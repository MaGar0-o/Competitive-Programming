//name: Amir Kafshdar Goharshadi

#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
  //code here
  int last,tekrar;
  last=(-1u)/2;
  last=0-last;
  tekrar=1;
  int n;
  long long sum=0;
  cin>>n;
  short h[n];
  for(int i=0;i<n;i++)
    cin>>h[i];
  for(int i=0;i<n;i++)
    {
      if(i==0)
	{
	  tekrar=1;
	  last=(-1u)/2;
	  last=0-last;
	}
      else if(h[i]==h[i-1])
	{
	  //no difference in last
	  tekrar++;
	}
      else
	{
	  last=h[i-1];
	  tekrar=1;
	}
      int add;
      if(i!=n-1)
	{
	  add=min(last-h[i],h[i+1]-h[i]);
	}
      else
	add=0;
      add=max(add,0);
      h[i]+=add;
      sum+=(tekrar*add);
      //cerr<<"added:"<<tekrar*add<<endl;
    }
  cout<<sum<<endl;
  //end of code
  return 0;
}
