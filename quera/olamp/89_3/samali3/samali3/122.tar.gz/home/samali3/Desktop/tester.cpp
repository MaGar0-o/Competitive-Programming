//name: Amir Kafshdar Goharshadi

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <algorithm>
using namespace std;

int main()
{
  //code here
  srand(time(0));
  int t=abs(rand())%20+1;
  cout<<t<<endl;
  for(int i=0;i<t;i++)
    {
      int si=abs(rand())%1000+1;
      cout<<si<<endl;
      for(int row=0;row<si;row++)
	{
	  for(int j=0;j<si;j++)
	    {
	      int x=abs(rand())%1000;
	      cout<<x<<" ";
	    }
	    cout<<endl;
	}
    }
  //end of code
  return 0;
}
