//name: Amir Kafshdar Goharshadi

#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <cmath>
#include <utility>
using namespace std;

typedef set<int>::iterator iter;


int radical(int x)
{
  // cerr<<"Radix:"<<x<<endl;
  if(x==1||x==0)
    {
      return ((-1u)/2);
    }
  int sqr=sqrt(x);
  if(x==sqr*sqr)
    {
      return radical(sqr)+1;
    }
  else
    return 0;
}

struct matrice{
  int size;
  vector< vector <int> > nodes;

  void cprn()
  {
    for(int i=0;i<size;i++)
      {
	for(int j=0;j<size;j++)
	  cerr<<nodes[i][j]<<" ";
	cerr<<endl;
      }
  }

  pair<int,int> minimax()
  {
    pair<int,int> ans=make_pair((-1u)/2,0-(-1u)/2);
    for(int i=0;i<nodes.size();i++)
      {
	for(int j=0;j<nodes[i].size();j++)
	  {
	    ans.first=min(nodes[i][j],ans.first);
	    ans.second=max(nodes[i][j],ans.second);
	  }
      }
    return ans;
  }

  void read()
  {
    //cerr<<"RRR"<<endl;
    for(int i=0;i<size;i++)
      {
	vector<int> toadd;
	for(int j=0;j<size;j++)
	  {
	    int x;
	    cin>>x;
	    toadd.push_back(x);
	  }
	nodes.push_back(toadd);
      }
    //cerr<<"EREND"<<endl;
  }

  void minimalize()
  {
    //cerr<<"Minim"<<endl;
    int mini=(-1u)/2;
    for(int i=0;i<size;i++)
      {
	for(int j=0;j<size;j++)
	  mini=min(radical(nodes[i][j]),mini);
      }
    for(int i=0;i<size;i++)
      {
	for(int j=0;j<size;j++)
	  {
	    for(int go=0;go<mini;go++)
	      {
		nodes[i][j]=sqrt(nodes[i][j]);
	      }
	  }
      }
    //cerr<<"Minimend"<<endl;
  }
  
};

bool operator < (set<int> a,set<int> b)
{
  iter i=a.begin();
  iter j=b.begin();
  for(;i!=a.end()&&j!=b.end();++i,j++)
    {
      if((*i)!=(*j))
	return (*i)<(*j);
    }
    return false;
}

bool check(matrice a,matrice b)
{
  //  cerr<<"Checking:"<<endl;
  //a.cprn();
  //cerr<<"&&&&&&&&&&&"<<endl;
  //b.cprn();
  int acurrent,bcurrent;
  //a is always less
  pair<int,int> aex=a.minimax();
  pair<int,int> bex=b.minimax();
  acurrent=aex.second-aex.first;
  bcurrent=bex.second-bex.first;
  if(acurrent>bcurrent)
    return check(b,a);
  vector<int> as[a.size];
  vector<int> bs[b.size];
  for(int i=0;i<a.size;i++)
    {
      int asimin=(-1u)/2;
      int bsimin=asimin;
      for(int j=0;j<a.size;j++)
	{
	  as[i].push_back(a.nodes[i][j]-aex.first);
	  bs[i].push_back(b.nodes[i][j]-bex.first);
	  asimin=min(asimin,as[i][as[i].size()-1]);
	  bsimin=min(bsimin,bs[i][bs[i].size()-1]);
	  for(int tt=0;tt<as[i].size();tt++)
	    {
	      as[i][tt]-=asimin;
	      bs[i][tt]-=bsimin;
	    }
	}
    }
 loop:
  //cerr<<"Now a ^=2"<<endl;
  if(acurrent>bcurrent)
    return false;
  sort(as,as+a.size);
  sort(bs,bs+b.size);
  bool ok=true;
  for(int i=0;i<a.size;i++)
    {
      if(bs[i]!=as[i])
	{
	ok=false;
	break;
	}
      
    }
  if(ok)
    return true;
  else
    {
      for(int i=0;i<a.size;i++)
	{
	  vector<int> neww;
	  for(int it=0;it<as[i].size();++it)
	    {
	      neww.push_back(pow(as[i][it],2));
	    }
	  as[i]=neww;
	}
      aex.first*=aex.first;
      aex.second*=aex.second;
      acurrent=aex.second-aex.first;
      goto loop;
    }
}

int main1()
{
  //code here
  int s;
  cin>>s;
  matrice a,b;
  a.size=s;
  b.size=s;
  a.read();
  b.read();
  a.minimalize();
  b.minimalize();
  check(a,b)?cout<<"Yes":cout<<"No";
  cout<<endl;
  //end of code
  return 0;
}

int main()
{
  int t;
  cin>>t;
  for(int i=0;i<t;i++)
    main1();
  return 0;
}
