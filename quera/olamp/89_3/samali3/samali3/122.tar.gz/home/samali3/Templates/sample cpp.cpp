//name: Amir Kafshdar Goharshadi

#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
  //code here

  //end of code
  return 0;
}
