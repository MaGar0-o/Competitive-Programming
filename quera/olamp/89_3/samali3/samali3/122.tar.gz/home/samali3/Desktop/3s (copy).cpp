//name: Amir Kafshdar Goharshadi

#include <iostream>
#include <vector>
#include <set>
#include <cmath>
#include <utility>
#include <algorithm>
using namespace std;

const int INF=(-1u)/2;

bool vsort(const vector<int> &a,const vector<int> &b)
{
  for(int i=0;i<a.size();i++)
    {
      if(a[i]!=b[i])
	return (a[i]<b[i]);
    }
  return false;
}

int radical(int x)
{
  if(x==1||x==0)
    return INF;
  int sqr=sqrt(x);
  if(x==sqr*sqr)
    return radical(sqr)+1;
  else
    return 0;
}

struct matrice{

  int size;
  
  vector< vector<int> > nodes;

  void cprn()
  {
    for(int i=0;i<size;i++)
      {
	for(int j=0;j<size;j++)
	  cerr<<nodes[i][j]<<" ";
	cerr<<endl;
      }
  }

  pair<int,int> minimax()
  {
    pair<int,int> ans=make_pair(INF,0-INF);
    for(int i=0;i<nodes.size();i++)
      {
	for(int j=0;j<nodes[i].size();j++)
	  {
	    ans.first=min(nodes[i][j],ans.first);
	    ans.second=max(nodes[i][j],ans.second);
	  }
      }
    return ans;
  }

  void read()
  {
    for(int i=0;i<size;i++)
      {
	vector<int> toadd;
	for(int j=0;j<size;j++)
	  {
	    int x;
	    cin>>x;
	    toadd.push_back(x);
	  }
	nodes.push_back(toadd);
      }
  }

  void minimalize()
  {
    int mini=INF;
    for(int i=0;i<size;i++)
      {
	for(int j=0;j<size;j++)
	  mini=min(radical(nodes[i][j]),mini);
      }
    for(int i=0;i<size;i++)
      {
	for(int j=0;j<size;j++)
	  {
	    if(mini==INF)
	      break;
	    for(int go=0;go<mini;go++)
	      nodes[i][j]=sqrt(nodes[i][j]);
	  }
      }
  }
  
};



bool check(matrice &a,matrice &b)
{
  int acurrent,bcurrent;
  pair<int,int> aex=a.minimax();
  pair<int,int> bex=b.minimax();
  acurrent=aex.second-aex.first;
  bcurrent=bex.second-bex.first;
  if(acurrent>bcurrent)
    return check(b,a);
  vector<int> as[a.size];
  vector<int> bs[b.size];
  for(int i=0;i<a.size;i++)
    {
      int asimin=INF;
      int bsimin=INF;
      int asindex,bsindex;
      asindex=bsindex=INF;
      for(int j=0;j<a.size;j++)
	{
	  as[i].push_back(a.nodes[i][j]-aex.first);
	  bs[i].push_back(b.nodes[i][j]-bex.first);
	  if(as[i][as[i].size()-1]<asimin)
	    {
	      asimin=as[i][as[i].size()-1];
	      asindex=as[i].size()-1;
	    }
	  if(bs[i][bs[i].size()-1]<bsimin)
	    {
	      bsimin=bs[i][bs[i].size()-1];
	      bsindex=bs[i].size()-1;
	    }
	}
      vector<int> tempa,tempb;
      tempa=as[i];
      tempb=bs[i];
      for(int hj=0;hj<tempa.size();hj++)
	{
	  tempa[hj]=as[i][(hj+asindex)%(tempa.size())];
	  tempb[hj]=bs[i][(hj+bsindex)%(tempa.size())];
	}
      as[i]=tempa;
      bs[i]=tempb;
    }

  //edame
 loop:
  if(acurrent>bcurrent)
    return false;
  sort(as,as+a.size,vsort);
  sort(bs,bs+b.size,vsort);
  bool ok=true;
  for(int i=0;i<a.size;i++)
    {
      if(bs[i]!=as[i])
	{
	  ok=false;
	  break;
	}
    }
  if(ok)
    return true;
  else
    {
      for(int i=0;i<a.size;i++)
	{
	  vector<int> neww;
	  for(int it=0;it<as[i].size();++it)
	    {
	      neww.push_back(pow(as[i][it],2));
	    }
	  as[i]=neww;
	}
      aex.first*=aex.first;
      aex.second*=aex.second;
      acurrent=aex.second-aex.first;
      goto loop;
    }
  
}




void solve()
{
  int s;
  cin>>s;
  matrice a,b;
  a.size=b.size=s;
  a.read();
  b.read();
  a.minimalize();
  b.minimalize();
  check(a,b)?cout<<"Yes":cout<<"No";
  cout<<endl;
}

int main()
{
  //code here
  int t;
  cin>>t;
  for(int i=0;i<t;i++)
    solve();
  //end of code
  return 0;
}
