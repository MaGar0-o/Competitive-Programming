//name: Sepehr Taeb
#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

int n;
int arr[1000*1000+100];
int max_right[1000*1000+100];
int max_left[1000*1000+100];
int now_max;
long long answer;

void solve() {
    now_max=0;
    for(int i=1; i<=n; i++) {
        max_right[i]=now_max;
        now_max=max(now_max, arr[i]);
    }
    now_max=0;
    for(int i=n; i>=1; i--) {
        max_left[i]=now_max;
        now_max=max(now_max, arr[i]);
    }
    for(int i=1; i<=n; i++) {
        int x=min(max_right[i], max_left[i]);
        if(arr[i]<x)
            answer+=x-arr[i];
    }
}

int main() {
    scanf("%d", &n);
    for(int i=1; i<=n; i++)
        scanf("%d", &arr[i]);
    solve();
    cout<<answer<<"\n";
    return 0;
}
