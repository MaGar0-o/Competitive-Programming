//name: Sepehr Taeb
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<vector>
#include<set>
using namespace std;

struct p {
    int first, second;
};

bool operator <(const p &a1, const p &a2) {
    if(a1.first!=a2.first)
        return a1.first<a2.first;
    return a1.second>a2.second;
}

int t;
int n;
int arr[1000*100+100];
bool mark[1000*100+100];
int m;
vector<int> s;
set<p> baze;
int answer;

void solve1() {
    int tedad1=0;
    int num=0;
    for(int i=0; i<s.size(); i++) {
        int a, b;
        if(i==0)
            a=s[i];
        else
            a=s[i]+1;
        i++;
        if(i==s.size()-1)
            b=s[i];
        else
            b=s[i]-1;
        num+=b-a+1;
        for(int j=a; j<=b; j++) {
            if(arr[j]==1)
                tedad1++;
            mark[j]=true;
        }
    }
    answer+=max(tedad1, num-tedad1);
}

void solve() {
    for(set<p>::iterator i=baze.begin(); i!=baze.end(); i++) {
        int a=(*i).first;
        int b=(*i).second;
        set<p>::iterator j=i;
        s.clear();
        s.push_back(a);
        i++;
        while(i!=baze.end()) {
            int c=(*i).first;
            int d=(*i).second;
            if(d>b)
                break;
            if(d<=b) {
                if(s.size()==1) {
                    s.push_back(c);
                    s.push_back(d);
                    i++;
                    continue;
                }
                else {
                    int h=s[s.size()-1];
                    if(d<=h) {
                        i++;
                        continue;
                    }
                    else {
                        s.push_back(c);
                        s.push_back(d);
                        i++;
                        continue;
                    }
                }
            }
            i++;
        }
        s.push_back(b);
        solve1();
        i=j;
    }
}

int main() {
    scanf("%d", &t);
    while(t>0) {
        t--;
        memset(mark, false, sizeof(mark));
        answer=0;
        baze.clear();
        scanf("%d", &n);
        for(int i=1; i<=n; i++) {
            scanf("%d", &arr[i]);
            arr[i]=arr[i]%2;
        }
        scanf("%d", &m);
        for(int i=1; i<=m; i++) {
            int a, b;
            scanf("%d%d", &a, &b);
            p l;
            l.first=a;
            l.second=b;
            baze.insert(l);
        }
        solve();
        for(int i=1; i<=n; i++)
            if(!mark[i] && arr[i]==1)
                answer++;
        printf("%d\n", answer);
    }
    return 0;
}
