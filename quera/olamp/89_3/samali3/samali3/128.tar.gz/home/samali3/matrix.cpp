//name: Sepehr Taeb
#include<algorithm>
#include<iostream>
#include<cstdio>
#include<set>
using namespace std;

struct p{
    int a;
    int i, j;
};

bool operator <(const p &a1, const p &a2) {
    return a1.a<a2.a;
}

int t;
int n;
set<p> arr1, arr2;
int par[1000+100][1000+100][2];
int mat1[1000+100][1000+100];
int mat2[1000+100][1000+100];

bool solve() {
    set<p>::iterator i=arr1.begin();
    set<p>::iterator j=arr2.begin();
    while(i!=arr1.end()) {
        par[(*i).i][(*i).j][0]=(*j).i;
        par[(*i).i][(*i).j][1]=(*j).j;
        i++;
        j++;
    }
    for(int i=1; i<=n; i++) {
        int x=par[i][1][0];
        int y=par[i][1][1]%n;
        bool z;
        if((mat1[i][1]%2)!=(mat2[par[i][1][0]][par[i][1][1]]%2))
            z=false;
        else
            z=true;
        for(int j=2; j<=n; j++) {
                if(par[i][j][0]!=x)
                    return false;
                if((par[i][j][1]%n)!=((y+1)%n))
                    return false;
                y=(y+1)%n;
                if(z) {
                    if((mat1[i][j]%2)!=(mat2[par[i][j][0]][par[i][j][1]]%2))
                        return false;
                }
                else {
                    if((mat1[i][j]%2)==(mat2[par[i][j][0]][par[i][j][1]]%2))
                        return false;
                }
        }
    }
    return true;
}

int main() {
    scanf("%d", &t);
    while(t>0) {
        t--;
        arr1.clear();
        arr2.clear();
        scanf("%d", &n);
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++) {
                scanf("%d", &mat1[i][j]);
                p x;
                x.a=mat1[i][j];
                x.i=i;
                x.j=j;
                arr1.insert(x);
            }
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++) {
                scanf("%d", &mat2[i][j]);
                p x;
                x.a=mat2[i][j];
                x.i=i;
                x.j=j;
                arr2.insert(x);
            }
        if(solve())
            printf("Yes\n");
        else
            printf("No\n");
    }
    return 0;
}
