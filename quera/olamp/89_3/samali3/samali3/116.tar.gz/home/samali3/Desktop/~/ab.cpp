//name: Fatemeh Aslanbeigi
#include<iostream>
#include<cstdio>
using namespace std;
const int maxn=1000*1000+100;
int a[maxn], n;
void solve(){
	long long sum=0;
	for(int i=0; i<n-1;){
		int fir=i;
		int mid=-1;
		while(a[i+1] <= a[i] && i < n){
			i++;
		}
		mid=i;
		while(a[i+1] >= a[i] && i < n){
			i++;
		}
		int las=i;
		int p1=mid-1, p2=mid+1;
		int h1=a[mid];
		while(1){
			if(a[p1] < a[p2]){
				sum+=(a[p1]-h1)*(p2-p1-1);
				h1=a[p1];
				p1--;
			}
			else{
				sum+=(a[p2]-h1)*(p2-p1-1);
				h1=a[p2];
				p2++;
			}
			if(p2 > n-1 || p1 < fir || p2 > las)
				break;
		}
	}
	cout<<sum<<endl;
}
int main(){
	scanf("%d", &n);
	for(int i=0; i<n; i++){
		scanf("%d", &a[i]);
	}
	solve();
	return 0;
}
