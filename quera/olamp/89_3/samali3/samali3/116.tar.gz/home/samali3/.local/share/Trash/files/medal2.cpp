//name: Fatemeh Aslanbeigi
#include<iostream>
#include<algorithm>
using namespace std;
const int maxm=100*1000+100, maxn=1000*100+100;
struct zhen{
	int a, b;
}zh[maxm];
int t, n, m;
int ted[maxn];
int sum=0;
int s[maxn];
bool cm(const zhen &z1, const zhen &z2){
	if(z1.a!=z2.a && z1.b!=z2.b){
		return z1.a < z2.a;
	}
	else{
		if (z1.a== z2.a)
			return z1.b > z2.b;
		else
			return z1.a < z2.a;
	}
}	
void solve(){
	cerr<<"/**********************************************************************"<<endl;
	sort(zh, zh+m, cm);
	for(int i=0; i<m; i++){
		int check=0;
		int andis=i;
		while(i < m-1 && (zh[i].a==zh[i+1].a || zh[i].b==zh[i+1].b)){
			if(zh[i].a==zh[i+1].a)
				check=1;
			else
				check=2;
			i++;
	    }
		int num=0;
		for(int j=0; j<m; j++){
			cerr<<zh[j].a<<" "<<zh[j].b<<endl;
		}
		if(check==0){
			int tedd=ted[zh[i].b]-ted[zh[i].a]+1;
			if(tedd < zh[i].b-zh[i].a+1-tedd){
				num++;
				sum+=zh[i].b-zh[i].a+1-tedd;
			}					
			else
				sum+=tedd;
		}
		if(check==1){
			for(int j=andis ; j <= i; j++){
				if (j==i){
					if(num%2==0){
            			int tedd=ted[zh[i].b]-ted[zh[i].a]+1;
						if(tedd < zh[i].b-zh[i].a+1-tedd){
							num++;
							sum+=zh[i].b-zh[i].a+1-tedd;
						}					
						else
							sum+=tedd;
			   		}
					else{
						int tedd=zh[j].b-zh[j].a-ted[zh[j].b]+ted[zh[j].a];
						if(tedd < zh[j].b-zh[j].a+1-tedd){
							num++;
							sum+=zh[j].b-zh[j].a+1-tedd;
						}	
						else{
							sum+=tedd;
						}
					}			
				}
				else{
					if(num%2==0){
						int tedd=ted[zh[j].b]-ted[zh[j+1].b];
						if(tedd < zh[j].b-zh[j+1].b-tedd){
							num++;
							sum+=zh[j].b-zh[j+1].b-tedd;
						}	
						else{
							sum+=tedd;
						}
					}
					else{
						int tedd=zh[j].b-zh[j+1].b-ted[zh[j].b]+ted[zh[j+1].b];
						if(tedd < zh[j].b-zh[j+1].b-tedd){
							num++;
							sum+=zh[j].b-zh[j+1].b-tedd;
						}	
						else{
							sum+=tedd;
						}
					}
				}
				cerr<<sum<<" "<<num<<endl;
			}	
		}
		if(check==2){
			for(int j=andis ; j <= i; j++){
				if (j==i){
					if(num%2==0){
					int tedd=ted[zh[i].b]-ted[zh[i].a]+1;
					if(tedd < zh[i].b-zh[i].a+1-tedd){
						num++;
						sum+=zh[i].b-zh[i].a+1-tedd;
					}					
					else
						sum+=tedd;
					}
					else{
						int tedd=zh[j].b-zh[j].a-ted[zh[j].b]+ted[zh[j].a];
						if(tedd < zh[j].b-zh[j].a+1-tedd){
							num++;
							sum+=zh[j].b-zh[j].a+1-tedd;
						}	
						else{
							sum+=tedd;
						}
					}
				}
				else{
					if(num%2==0){
						int tedd=ted[zh[j+1].a]-ted[zh[j].a];
						if(tedd < zh[j+1].a-zh[j].a-tedd){
							num++;
							sum+=zh[j+1].a-zh[j].a-tedd;
						}	
						else{
							sum+=tedd;
						}
					}
					else{
						int tedd=zh[j+1].a-zh[j].a-ted[zh[j+1].a]+ted[zh[j].a];
						if(tedd < zh[j+1].a-zh[j].a-tedd){
							num++;
							sum+=zh[j+1].a-zh[j].a-tedd;
						}	
						else{
							sum+=tedd;
						}
					}
				}
			}
		}
	}
	cout<<sum<<endl;
}
int main(){
	cin>>t;
	for(int i=0; i<t; i++){
		cin>>n;
		for(int j=0; j<n; j++){
			cin>>s[j];
			s[j]%=2;
	//		cerr<<":::::   "<<s[j]<<endl;
			if(j==0){
				ted[j]=0;
				if(s[j]==1)
					ted[j]++;
			}
			else{
				ted[j]=ted[j-1];
				if(s[j]==1){
					ted[j]++;
			//		cerr<<"ted  "<<j<<" "<<ted[j]<<endl;
				}
			}
		}	
		cin>>m;
		for(int j=0; j<m; j++){
			cin>>zh[j].a>>zh[j].b;
			zh[j].a--;
			zh[j].b--;
		}
		solve();
	}
	return 0;
}
