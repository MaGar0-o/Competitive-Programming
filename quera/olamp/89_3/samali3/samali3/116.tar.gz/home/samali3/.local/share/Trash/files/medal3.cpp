//name: Fatemeh Aslanbeigi
#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=100*10+100;
int t, n, m;
struct zhen{
	int a, b;
}zh[maxn];
int s[maxn];
int ans1[maxn], ans2[maxn];
bool mark[maxn][maxn];
bool cm(const zhen &z1, const zhen &z2){
	if(z1.a==z2.a){
		return z1.b  > z2.b;
	}
	return z1.a < z2.a;
}
int dfs(int x, int y){
	int st=0;
	//cerr<<x<<" "<<y<<endl;
	int sum=0;
	for(int i=0; i<m;){
		if(!mark[zh[i].a][zh[i].b] && zh[i].a >= x && zh[i].a <= y){
			ans1[st]=zh[i].a;
			ans2[st++]=zh[i].b;
			int fel=i;
			while(i < m && zh[i].a <= zh[fel].b && zh[i].a >= zh[fel].a){
				i++;
			}
		//	cerr<<i<<endl;
		}
		else
			i++;
	}
	int chan=0;
	int num=0;
	if(st==0){
		for(int j=x; j<=y; j++){
			if(s[j]==1)
				num++;
			chan++;
		}
		if(num < chan-num)
			num=chan-num;
		sum+=num;
	}
	else{
	for(int i=0; i<st; i++){
		if(i==0){
			for(int j=x; j < ans1[i]; j++){
				if (s[j]==1){
					num++;
				}
				chan++;
			}
		}
		else{
			for(int j=ans2[i-1]+1; j<ans1[i]; j++){
				if(s[j]==1)
					num++;
					chan++;
			}
		}
		if(i==st-1){
			for(int j=ans2[i]+1; j<=y; j++){
				if(s[j]==1)
					num++;
				chan++;
			}
		}
	}
	if (num < chan-num){
		sum+=chan-num;
		for(int i=x; i <= y; i++){
			if(s[i]==1){
				s[i]=0;
			}
			else
				s[i]=1;
		}
	}
	else
		sum+=num;
	for(int i=0; i<st; i++){
		if(!mark[ans1[i]][ans2[i]] && ans1[i] >= x && ans1[i] <=y){
			mark[ans1[i]][ans2[i]]=1;
			sum+=dfs(ans1[i], ans2[i]);
		}	
	}
	}
	return sum;
}
void solve(){
	int su=0;
	sort(zh, zh+m, cm);
	for(int i=0; i<m; i++){
		if(!mark[zh[i].a][zh[i].b]){
			mark[zh[i].a][zh[i].b]=1;
			su+=dfs(zh[i].a, zh[i].b);
		}
	}
	cout<<su<<endl;
}
int main(){
	scanf("%d", &t);
	for(int i=0; i<t; i++){
		scanf("%d", &n);
		for(int j=0; j<n; j++){
			scanf("%d", &s[j]);
			s[j]%=2;
		}
		scanf("%d", &m);
		for(int j=0; j<m; j++){
			scanf("%d %d", &zh[j].a, &zh[j].b);
			zh[j].a--; zh[j].b--;
		}
		solve();
	}
	return 0;
}
