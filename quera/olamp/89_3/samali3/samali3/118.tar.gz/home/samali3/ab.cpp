#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<vector>
using namespace std;

const int MAX=1000000+50;
int n, A[MAX], R[MAX], L[MAX], ans;
bool mark[MAX];

int main(){
	scanf("%d", &n);
	for (int i=0; i<n; i++){
		scanf("%d", &A[i]);
	}
	R[n-1]=0;
	for (int i=n-2; i>=0; i--){
		R[i]=max(R[i+1], A[i+1]);
	}
	L[0]=0;
	for (int i=1; i<n; i++){
		L[i]=max(L[i-1], A[i-1]);
	}
	for (int i=0; i<n; i++){
		if (A[i]<L[i] && A[i]<R[i]){
			ans+=min(R[i], L[i])-A[i];
		}
	}
	printf("%d\n", ans);
	return 0;
}
