//name: Hamed Saleh

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <vector>
#define maxS (100*1000)
#define maxN (1000+100)

using namespace std;

struct acell
{
	int i, j;
};

struct bcell
{
	int i, j;
};

struct row
{
	int i, min;
};

int n, a[maxN][maxN], b[maxN][maxN];

bool operator < (acell x, acell y)
{
	return a[x.i][x.j]<a[y.i][y.j];
}

bool operator < (bcell x, bcell y)
{
	return b[x.i][x.j]<b[y.i][y.j];
}

bool operator < (row a, row b)
{
	return a.min<b.min;
}

bool zojiat()
{
	int ae=0, be=0;

	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			if (a[i][j]%2)
				ae++;

	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			if (b[i][j]%2)
				be++;

	return (ae==be || ae==n*n-be); 
}

acell ac[maxN*maxN];
bcell bc[maxN*maxN];
int aa [maxN][maxN], bb [maxN][maxN];

void make_aa_bb()
{
	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			ac[i*n+j].i=i,
			ac[i*n+j].j=j;

	sort (ac, ac+n*n);

	for (int i=0; i<n*n; i++)
		aa[ac[i].i][ac[i].j]=i;

	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			bc[i*n+j].i=i,
			bc[i*n+j].j=j;

	sort (bc, bc+n*n);

	for (int i=0; i<n*n; i++)
		bb[bc[i].i][bc[i].j]=i;

	//for (int i=0; i<n; i++, cout<<endl)
	//	for (int j=0; j<n; j++)
	//		cout<<aa[i][j]<<' ';

	//for (int i=0; i<n; i++, cout<<endl)
	//	for (int j=0; j<n; j++)
	//		cout<<bb[i][j]<<' ';
}

row ra[maxN];
row rb[maxN];
int tempa[maxN], tempb[maxN];;

bool place()
{
	make_aa_bb();

	for (int i=0; i<n; i++)
	{
		int minimum=aa[i][0];
		for (int j=0; j<n; j++)
			if (a[i][j]<minimum)
				minimum=aa[i][j];

		ra[i].i=i;
		ra[i].min=minimum;
	}	

	sort (ra, ra+n);

	for (int i=0; i<n; i++)
	{
		int minimum=bb[i][0];
		for (int j=0; j<n; j++)
			if (bb[i][j]<minimum)
				minimum=bb[i][j];

		rb[i].i=i;
		rb[i].min=minimum;
	}	

	sort (rb, rb+n);

	for (int i=0; i<n; i++)
	{
		int p=0;
		for (; p<n; p++)
			if (aa[ra[i].i][0]==bb[rb[i].i][p])
				break;

		if (p==n)
			return 0;

		for (int j=0; j<n; j++)
			if (aa[ra[i].i][j]!=bb[rb[i].i][(j+p)%n])
				return 0;

		for (int j=0; j<n; j++)
			tempa[j]=a[ra[i].i][j],
			tempb[j]=aa[ra[i].i][j];

		for (int j=0; j<n; j++)
			a[ra[i].i][(j+p)%n]=tempa[j],
			aa[ra[i].i][(j+p)%n]=tempb[j];
	}

	/*cout<<"Are You Sure?"<<endl;
	for (int i=0; i<n; i++, cout<<endl)
		for (int j=0; j<n; j++)
			cout<<a[ra[i].i][j]<<' ';

	for (int i=0; i<n; i++, cout<<endl)
		for (int j=0; j<n; j++)
			cout<<b[rb[i].i][j]<<' ';*/

	return 1;
}

bool fixed_zojiat()
{
	int sum=0;
	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			sum+=(a[ra[i].i][j]%2!=b[rb[i].i][j]%2);

	//cout<<sum<<endl;
	return (sum==0 || sum==n*n);
}

//bfs vars
//pair <int, int> saf [maxQ];
//int q=0;

//vector <int> graph [maxS];

bool make_reach(int i, int j)
{
	//q=0;
	//saf[q].first=i;
	//saf[q].second=j;
	//q++;

	int ar=a[ra[0].i][0];
	int br=b[rb[0].i][0];
	int dif1=ar-br;
	if (dif1<0)
		swap(ar,br),
		dif1*=-1;
	int cr=a[ra[i].i][j];
	int dr=b[rb[i].i][j];
	int dif2=cr-dr;
	if (dif2<0)
		swap(cr,dr),
		dif2*=-1;

	if (dif1==dif2)
		return 1;

	//cout<<dif1<<' '<<dif2<<endl;
	//if (max(dif1,dif2)%4==2)
	//	return 0;

	

	return 1;
}

bool apply()
{
	return 1;
}

bool tabdil()
{
	int dif1=a[ra[0].i][0]-b[rb[0].i][0];
	int i, j;
	for (i=0; i<n; i++)
	{
		for (j=0; j<n; j++)
		{
			if (a[ra[i].i][j]-b[rb[i].i][j]!=dif1)
				goto middle;
		}
	}

	return 1;

	middle:
	
	int dif2=a[ra[i].i][j]-b[rb[i].i][j];
	
	if (!make_reach(i, j))
		return 0;

	return apply();
}

bool solve()
{
	if (!zojiat())
		return 0;

	//cerr<<"Zojiat Passed"<<endl;

	if (!place())
		return 0;
	
	//cerr<<"Placing Passed"<<endl;

	if (!fixed_zojiat())
		return 0;

	//cerr<<"Fixed Zojiat Passed"<<endl;

	return tabdil();
}

int main()
{
	int t;
	scanf ("%d", &t);
	for (int i=0; i<t; i++)
	{
		scanf ("%d", &n);
		for (int j=0; j<n; j++)
			for (int k=0; k<n; k++)
				scanf ("%d", &a[j][k]);
		for (int j=0; j<n; j++)
			for (int k=0; k<n; k++)
				scanf ("%d", &b[j][k]);

		if (solve())
			printf ("Yes\n");
		else
			printf ("No\n");
	}

	return 0;
}
