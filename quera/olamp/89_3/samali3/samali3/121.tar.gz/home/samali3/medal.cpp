//name: Hamed Saleh

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#define  maxN (100*1000+100)
#define  maxM (100*1000+100)

using namespace std;

struct baze
{
	int s, e;
};

bool operator < (baze a, baze b)
{
	if (a.e!=b.e)
		return a.e<b.e;
	return (a.e-a.s)<(b.e-b.s);
};

int n, m;
int s [maxN];
int flag[maxN];
baze g [maxM];
vector <int> a [maxN];				//graph
vector <baze> b [maxN];				//intervals
int stack [maxN], ss=0;

bool baba (int i, int j)
{
	return (g[j].s<=g[i].s && g[i].e<=g[j].e);
}

void make_baze()
{
	//make_graph();
	ss=0;
	for (int i=m-1; i>=0; i--)
	{
		while (ss>0 && !baba(i, stack[ss-1]))
			ss--;

		if (ss)
			a[stack[ss-1]].push_back(i);

		stack[ss]=i;
		ss++;
	}

	//for (int i=0; i<m; i++, cout<<endl)
	//	for (int j=0; j<a[i].size(); j++)
	//		cerr<<g[a[i][j]].s<<','<<g[a[i][j]].e<<' ';

	//make_baze from_graph();
	for (int i=0; i<m; i++)
	{
		baze first=g[i];
		for (int j=0; j<a[i].size(); j++)
		{
			baze add=first;
			add.s=g[a[i][j]].e+1;
			if (add.e-add.s>=0)
				b[i].push_back(add);
			first.e=g[a[i][j]].s-1;
			//cout<<first.s<<','<<first.e<<'X';
		}
		//cout<<endl;
		if (first.e-first.s>=0)
			b[i].push_back(first);
	}

	//for (int i=0; i<m; i++,cout<<endl)
	//	for (int j=0; j<b[i].size(); j++)
	//		cerr<<b[i][j].s<<','<<b[i][j].e<<' ';
}

int main()
{
	int t;
	scanf ("%d", &t);
	for (int i=0; i<t; i++)
	{
		for (int i=0; i<maxN; i++)
			a[i].resize(0),
			b[i].resize(0),
			flag[i]=0;

		scanf ("%d", &n);
		for (int i=0; i<n; i++)
		{
			int ss;
			scanf ("%d", &ss);
			s[i]=ss%2;
		}

		scanf ("%d", &m);
		for (int i=0; i<m; i++)
		{
			scanf ("%d %d", &g[i].s, &g[i].e);
		}

		sort (g, g+m);
		make_baze();

		int sum=0;
		for (int i=0; i<m; i++)
		{
			int zeros=0, ones=0;
			for (int j=0; j<b[i].size(); j++)
			{
				//cerr<<b[i][j].s<<','<<b[i][j].e<<endl;
				for (int k=b[i][j].s-1; k<=b[i][j].e-1; k++)
				{
					flag[k]=1;
					//cerr<<"s[k] "<<k<<' '<<s[k]<<endl;
					if (s[k])
						ones++;
					else
						zeros++;
				}
			}

			//cerr<<ones<<' '<<zeros<<endl;

			sum+=max(ones, zeros);
		}

		for (int i=0; i<n; i++)
			if (s[i] && !flag[i])
				sum++;

		printf ("%d\n", sum);
	}

	return 0;
}
