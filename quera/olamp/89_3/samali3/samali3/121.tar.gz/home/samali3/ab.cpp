//name: Hamed Saleh

#include <iostream>
#include <cstdio>
#define maxN (1000*1000+1000)

using namespace std;

int n;
int h[maxN];

int r[maxN], l[maxN];

int main()
{
	scanf ("%d", &n);
	for (int i=0; i<n; i++)
		scanf ("%d", &h[i]);

	int max=h[0];
	for (int i=0; i<n; i++)
	{
		if (max<h[i])
			max=h[i];
		r[i]=max;
		//cout<<r[i]<<' ';
	}
	//cout<<endl;

	max=h[n-1];
	for (int i=n-1; i>=0; i--)
	{
		if (max<h[i])
			max=h[i];
		l[i]=max;
		//cout<<l[i]<<' ';
	}
	//cout<<endl;

	int sum=0;

	for (int i=0; i<n; i++)
	{
		int min=r[i];
		if (l[i]<min)
			min=l[i];

		if (min>h[i])
			sum+=min-h[i];
	}

	printf ("%d\n", sum);

	return 0;
}
