//name: saeed ilchi ghazaan

#include <iostream>
#include <cstdio>

using namespace std;

const int MAXN= 1000+ 10;

int n, t;
int a[MAXN][MAXN], b[MAXN][MAXN]; 
int A[MAXN* MAXN], B[MAXN* MAXN];

inline int compare (){
	for (int i= n;i >= 1;i --){
		if (X[i]!=Y[i]){
			if (X[i] < Y[i])
				return true;
			return false;
		}
	}
	return true;
}
/*****************************************************/
inline bool backtrack (){
	int cnt= 0;
	while (true){
		A[i]+= cnt;
		bool f= compare (A, B);
		if (flag)
			return true;
		if (f){
			for (int i= 1;i<= A[i];i ++)
				A[i]*= A[i];
			bool o= compare ();
			if (flag)
				return true;
			if (o){
				bool res= max (res, backtrack());
			}

			return false;
		}


	}
	
	
	
	
	
	
}
/*****************************************************/
int main (){
	scanf("%d%d", &t);
	while (t){
		scanf("%d", &n);
		int len= 1;
		for (int i= 1;i<= n;i ++)
			for (int j= 1;j<= n;j ++){
				scanf("%d", &a[i][j]);
				A[len ++]= a[i][j];
			}
		len= 0;
		for (int i= 1;i<= n;i ++)
			for (int j= 1;j<= n;j ++){
				scanf("%d", &b[i][j]);
				B[len ++]= b[i][j];
			}
		sort (A+1, A+len);
		sort (B+1, B+len);
		if (!compare ()){
			for (int i= 1;i<= n;i ++)
				for (int j= 1;j<= n;j ++)
					swap (a[i][j], b[i][j]);
			for (int i= 1;i<= len;i ++)
				swap (A[i], B[i]);
		}
		res.push_back (backtrack());
		t --;
	}
	return 0;
}
