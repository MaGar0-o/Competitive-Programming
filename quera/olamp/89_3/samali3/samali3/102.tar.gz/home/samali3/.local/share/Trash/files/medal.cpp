//name: saeed ilchi ghazaan

#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

const int MAXN= 1000 * 100 + 10;

bool mark[MAXN];
int t, n, m;
int sold[MAXN];
vector <int> res; 

struct range{
	int s, e;

	inline bool operator < (const range &second) const{
		if (e!= second.e)
			return e < second.e;
		return s < second.s;
	}

}gen[MAXN];
/***************************************************/
int main (){
	scanf("%d", &t);
	while (t){
		scanf("%d", &n);
		for (int i= 1;i<= n;i ++){
			scanf("%d", &sold[i]);
			mark[i]= sold[i] & 1;
		}
		scanf("%d", &m);
		for (int i= 1;i<= m;i ++)
			scanf("%d%d", &gen[i].s, &gen[i].e);
		sort (gen+1, gen+m+1);
		int end= gen[m].e, r= 0;
		for (int i= m;i > 0;i --){ 
			if (gen[i].s > end)
				continue;
			int odd= 0;
			for (int j= gen[i].s;j<= end;j ++)
				if (mark[j])
					odd ++;
			r+= max (odd, ((end-gen[i].s+1)-odd));
			end= gen[i].s- 1;
		}
		res.push_back (r);
		t --;
	}
	for (unsigned int i= 0;i< res.size();i ++)
		printf("%d\n", res[i]);
	return 0;
}
