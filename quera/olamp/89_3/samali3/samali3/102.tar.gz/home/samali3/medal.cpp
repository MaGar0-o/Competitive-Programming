//name: saeed ilchi ghazaan

#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

const int MAXN= 1000 * 100 + 10;

bool mark[MAXN];
int t, n, m;
vector <int> res;

struct range{
	int s, e, len;
}a[MAXN];
/**********************************************************/
inline int update (){
	int start= a[m].s, end= a[m].e;
	int tool = end- start+ 1; 
	for (int i= 1;i< m;i ++){
		if (a[i].s > end)
			a[i].s-= tool, a[i].e-= tool;
		else if (a[i].e >= end){
			int tmp= a[i].len- tool;
			a[i].e-= tool;
			a[i].s = a[i].e-tmp+1;
		}
		a[i].len= a[i].e- a[i].s+ 1;
	}
	int odd= 0;
	for (int i= start;i<= end;i ++)
		if (mark[i])
			odd ++;
	odd= max (odd, (tool- odd));
	for (int i= end+1, j= start;i<= n;i ++, j ++)
		mark[j]= mark[i]; 
	n-= tool;
	return odd;
}
/**********************************************************/
int main (){
	scanf("%d", &t);
	while (t){
		int r= 0;
		scanf("%d", &n);
		for (int i= 1;i<= n;i ++){
			int tmp;
			scanf("%d", &tmp);
			mark[i]= tmp & 1;
		}
		scanf("%d", &m);
		for (int i= 1;i<= m;i ++){
			scanf("%d%d", &a[i].s, &a[i].e);
			a[i].len= a[i].e- a[i].s+ 1;
		}
		while (m){
			int mini= 1;
			for (int i= 2;i<= m;i ++)
				if (a[i].len < a[mini].len)
					mini= i;
			swap (a[mini], a[m]);
			if (a[m].len > 0)
				r+= update();
			m --;
		}
		res.push_back (r);
		t --;
	}
	for (unsigned int i= 0;i< res.size();i ++)
		printf ("%d\n", res[i]);
	return 0;
}
