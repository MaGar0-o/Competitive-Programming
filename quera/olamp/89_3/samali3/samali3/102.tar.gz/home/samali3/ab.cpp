//name: saeed ilchi ghazaan

#include <iostream>
#include <cstdio>

using namespace std;

const int MAXN= 1000 * 1000 + 10;

int n;
int build[MAXN];

int main (){
	scanf("%d", &n);
	for (int i= 1;i<= n;i ++)
		scanf("%d", &build[i]);

	build[n+1]= MAXN;
	int maxi= 1;
	for (int i= 2;i<= n;i ++)
		if (build[maxi] <= build[i])
			maxi= i;
	long long res= 0;
	int start= 1;
	while (true){
		if (start== maxi)
			break;
		int end= start+1;
		while (build[start] > build[end])
			end ++;
		for (int i= start+1;i< end;i ++)
			res+= (build[start]- build[i]);
		start= end;
	}
	start= n;
	while (true){
		if (start== maxi)
			break;
		int end= start-1;
		while (build[start] > build[end])
			end --;
		for (int i= start-1;i > end;i --)
			res+= (build[start]- build[i]);
		start= end;
	}
	cout << res << endl;
	return 0;
}
