//name: Hamed Raoufian Moghaddam

#include <iostream>
#include <algorithm>
#include <cstdio>

using namespace std;

const int MaxN = 1000 * 1000 + 1000;

int n,List[MaxN], DynLeft[MaxN], DynRight[MaxN], Sum;

void Input(){
	scanf("%d", &n);
	for(int i = 0; i < n; i++){
		scanf("%d", &List[i]);
	}
	cerr << "Input Complete..." << endl;
}

void LeftDynamic(){
	int M = 0;
	for (int i = 0; i < n; i++){
		DynLeft[i] = M;
		if (List[i] > M){
			M = List[i];
		}
	}
	cerr << "LeftDynamic Complete..." << endl;
}

void RightDynamic(){
	int M = 0;
	for (int i = n-1; i >= 0; i--){
		DynRight[i] = M;
		if (List[i] > M){
			M = List[i];
		}
	}
	cerr << "RightDynamuc Complete..." << endl;
}

void MainDynamic(){
	int Up, Minimum;
	for (int i = 0; i < n; i++){
		Minimum = min(DynLeft[i], DynRight[i]);
		Up = Minimum - List[i];
		if (Up > 0){
			Sum += Up;
		}
	}
	cerr << "MainDynamicComplete..." << endl;
}

void Output(){
	printf("%d\n", Sum);
	cerr << "Output Complete..." << endl;
}

int main(){
	Input();
	LeftDynamic();
	RightDynamic();
	MainDynamic();
	Output();
	return 0;
}
