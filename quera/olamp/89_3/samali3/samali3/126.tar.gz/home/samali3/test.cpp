#include <fstream>
#include <iostream>
using namespace std;
int main(){
	ofstream out("input");
	cout << 1000000 << " " << 1000 << endl;
	for (int i = 1; i < 999999; i++){
		cout << 0 << " ";
	}
	cout << 1000 << endl;
	return 0;
}
