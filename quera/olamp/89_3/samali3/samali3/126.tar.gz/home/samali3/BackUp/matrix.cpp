//name: Hamed Raoufian Moghaddam

#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

const int INF = ~0u/2;

int n;
int Ar[1000000 + 1000];
int Left[1000000 + 1000], Right[1000000 + 1000];

int Merge(int a, int b, int c){
	for (int i = a; i < b; i++){
		Left[i-a] = Ar[i];
	}
	Left[b-a] = INF;
	for (int i = b; i < c; i++){
		Right[i-b] = Ar[i];
	}
	Right[c-b] = INF;
	int flag = a, af = 0,bf = 0, t = 0;
	while(flag != c){
		if (Left[af] == INF || Right[bf] == INF)
			break;
		if (Left[af] <= Right[bf]){
			Ar[flag] = Left[af];
			flag++;
			af++;
		}else{
			Ar[flag] = Right[bf];
			flag++;
			bf++;
			t+=(b-a)-af;
		}
	}
	for (int i = af; Left[i] != INF;i++){
		Ar[flag] = Left[i];
		flag++;
	}
	for (int i = bf; Right[i] != INF; i++){
		Ar[flag] = Right[i];
		flag++;
	}
	return t;
}

int MergeSort(int a, int b){
	if (a+1 == b)
		return 0;
	int c = (a+b)/2;
	int t = 0;
	t += MergeSort(a,c);
	t += MergeSort(c,b);
	t += Merge(a,c,b);
	return t;
}

int HInversion(){
	return MergeSort(0, n*n);
}

int Inversion(){
	int t = 0;
	for (int i = 0; i < n*n; i++){
		for(int j = i+1; j < n*n; j++){
			if (Ar[j] < Ar[i])
				t++;
		}
	}
	return t;
}

int main(){
	int t;
	int a, b;
	cin >> t;
	for(int i = 0; i < t; i++){
		cin >> n;
		for(int i = 0; i < n*n; i++){
			scanf("%d", &Ar[i]);
		}	
		a = HInversion();
		for(int i = 0; i < n*n; i++){
			scanf("%d", &Ar[i]);
		}
		b = HInversion();
		if (a%2 == b%2)
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
	return 0;
}

