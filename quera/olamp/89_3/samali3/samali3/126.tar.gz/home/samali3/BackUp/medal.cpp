//name: Hamed Raoufian Moghaddam

#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
struct Num{
	int N;
	vector<bool> Num;
};
struct Medal{
	int a, b;
};
int n, m;
Num My;
vector<Medal> Jan;
void PopVec(int i){
	swap(Jan[i], Jan[Jan.size()-1]);
	Jan.pop_back();
}
int NumXor(Medal In){
	int t = 0;
	for (int i = 0; i < In.a; i++){
		if (My.Num[i] == true)
			t++;
	}
	for (int i = In.a ; i <= In.b; i++){
		if (My.Num[i] == false)
			t++;
	}
	for (int i = In.b + 1; i < n; i++){
		if (My.Num[i] == true)
				t++;
	}	
	return t;
}
void Xor(int i){
	int t = My.N;
	Medal In = Jan[i];
	for (int i = In.a; i <= In.b; i++){
		if (My.Num[i] == 0){
			My.Num[i] = 1;
			t++;	
		}else{
			My.Num[i] = 0;
			t--;
		}
	}
	My.N = t;
}
int Run(){
	int Max, Maxi;
	while(true){
		Max = My.N;
		Maxi = -1;
		for (int i = 0; i < Jan.size(); i++){
			if (NumXor(Jan[i]) > Max){
				Max = NumXor(Jan[i]);
				Maxi = i;
			}
		}
		if (Maxi == -1)
				break;
		Xor(Maxi);
		PopVec(Maxi);
	}
	return My.N;
}
int main(){
	int t;
	int p;
	Medal Med;
	cin >>t;
	for (int i = 0; i < t; i++){
		cin >> n;
		My.N = 0;
		My.Num.clear();
		Jan.clear();
		for (int i = 0; i < n;i++){
			scanf("%d", &p);
			if (p% 2 == 0)
				My.Num.push_back(0);
			else{
				My.Num.push_back(1);
				My.N++;
			}
		}	
		cin >> m;
		for (int i = 0;i < m; i++){
			scanf("%d%d", &Med.a, &Med.b);				
			Med.a--;
			Med.b--;
			if (Med.a > Med.b)
				swap(Med.a, Med.b);
			Jan.push_back(Med);
		}
		cout << Run() << endl;
	}
	return 0;
}
