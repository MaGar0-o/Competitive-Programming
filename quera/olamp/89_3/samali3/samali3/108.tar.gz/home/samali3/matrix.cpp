//name: MohammadReza Maleki

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

const int MAXn = 1000 + 10;

int t;
int n;
int a[MAXn][MAXn], aa[MAXn][MAXn];
int b[MAXn][MAXn], bb[MAXn][MAXn];
int arr1[MAXn], arr2[MAXn], tmp[MAXn], tmp2[MAXn][MAXn];

bool cmpa (const int &x, const int &y) { return a[x][0] < a[y][0]; }
bool cmpb (const int &x, const int &y) { return b[x][0] < b[y][0]; }

void correct (int mat[MAXn][MAXn])
{
	for (int i = 0; i < n; i++)
	{
		int *p = mat[i], mn = 0;
		for (int j = 0; j < n; j++)
		{
			tmp[j] = p[j];
			if (p[j] < p[mn])
				mn = j;
		}
		for (int j = 0; j < n; j++)
			p[j] = tmp[(j + mn) % n];
	}
}

int main()
{
	for (scanf ("%d", &t); t-- > 0; )
	{
		scanf ("%d", &n);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				scanf ("%d", &a[i][j]);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				scanf ("%d", &b[i][j]);
		if (n == 1)
		{
			puts ("Yes");
			continue;
		}
		correct (a);
			for (int i = 0; i < n; i++, cerr << endl)
			for (int j = 0; j < n; j++)
				cerr << a[i][j] << ' ';
		correct (b);
		for (int i = 0; i < n; i++)
			arr1[i] = arr2[i] = i;
		sort (arr1, arr1 + n, cmpa);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				tmp2[i][j] = a[i][j];
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < n; j++)
				aa[i][j] = a[i][j] = tmp2[arr1[i]][j];
			sort (aa[i], aa[i] + n);
		}
		sort (arr2, arr2 + n, cmpb);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				tmp2[i][j] = b[i][j];
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < n; j++)
				bb[i][j] = b[i][j] = tmp2[arr2[i]][j];
			sort (bb[i], bb[i] + n);
		}
		for (int i = 0; i < n; i++, cerr << endl)
			for (int j = 0; j < n; j++)
				cerr << a[i][j] << ' ';
		bool yes = true;
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				if (lower_bound (aa[i], aa[i] + n, a[i][j]) - aa[i] != lower_bound (bb[i], bb[i] + n, b[i][j]) - bb[i])
					yes = false;
		puts (yes ? "Yes" : "No");
	}
}

