//name: MohammadReza Maleki

#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

const int MAXn = 100 * 1000 + 10;
const int MAXm = 100 * 1000 + 10;

struct Range
{
	int a, b;
	Range () {}
	Range (int a, int b): a(a), b(b) {}
	bool operator < (const Range &tr) const
	{
		return (a != tr.a) ? a < tr.a : b > tr.b;
	}
};

int t;
int n, m;
int d[MAXn], s[MAXn];
Range r[MAXm];
int w[MAXm], e[MAXm];
int st[MAXm], top;

int main()
{
	for (scanf ("%d", &t); t-- > 0; )
	{
		scanf ("%d", &n);
		for (int i = 0; i < n; i++)
			scanf ("%d", d + i), d[i] %= 2;
		scanf ("%d", &m);
		for (int i = 0; i < m; i++)
			scanf ("%d%d", &r[i].a, &r[i].b), r[i].a--;
		s[0] = 0;
		for (int i = 1; i <= n; i++)
			s[i] = s[i-1] + d[i-1];
		sort (r, r + m);
		r[m] = Range (0, n);
		w[m] = e[m] = s[r[m].b] - s[r[m].a];
		top = 0;
		st[top++] = m;
		for (int i = 0; i < m; i++)
		{
			w[i] = e[i] = s[r[i].b] - s[r[i].a];
			while (r[i].a >= r[st[top-1]].b)
			{
				int p = st[top-1], q = st[top-2];
				w[p] = max (w[p], (r[p].b - r[p].a) - e[p]);
				w[q] += w[p] - (s[r[p].b] - s[r[p].a]);
				e[q] += ((r[p].b - r[p].a) - w[p]) - (s[r[p].b] - s[r[p].a]);
				top--;
			}
			st[top++] = i;
		}
		while (top >= 2)
		{
			int p = st[top-1], q = st[top-2];
			w[p] = max (w[p], (r[p].b - r[p].a) - e[p]);
			w[q] += w[p] - (s[r[p].b] - s[r[p].a]);
			e[q] += ((r[p].b - r[p].a) - w[p]) - (s[r[p].b] - s[r[p].a]);
			top--;
		}
		w[m] = max (w[m], (r[m].b - r[m].a) - e[m]);
//		for (int i = 0; i < n; i++) cerr << " && " << d[i] << ' ' << s[i+1] << endl;
//		for (int i = 0; i <= m; i++) cerr << " ** " << r[i].a+1 << ' ' << r[i].b << ' ' << w[i] << ' ' << e[i] << endl;
		printf ("%d\n", w[m]);
	}
}

