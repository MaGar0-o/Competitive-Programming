//name: Mohammad Reza Kasnavi Yazdy

#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
#include<cstring>
using namespace std;

#define PB push_back
#define MP make_pair

const int maxn=100*1000+1000;
int n, m, po, to, s[maxn], e[maxn], sum;
pair<int, int> ary[maxn];

///////////////////////////////
inline bool check(const pair<int, int> &a, const pair<int, int> &b){
	if(a.first != b.first)
		return a.first<b.first;
	return a.second > b.second;
}
/*****************************/
inline void read(){
	scanf("%d", &n);
	for(int i=0;i<n;i++)
		scanf("%d", &s[i]);
	for(int i=0;i<n;i++)
		s[i]%=2;
	scanf("%d", &m);
	for(int i=0;i<m;i++){
		int x, y;
		scanf("%d %d", &x, &y);
		x--;y--;
		ary[i]=MP(x, y);
	}
	sort(&ary[0], &ary[m], check);
}
/******************************/
inline pair<int, int>  go(const pair<int, int> &q){
	int u=q.first, v=q.second;
	po++;
	int T=0, F=0, t=0, f=0;
	while(to<=v){
		if(po<m && to==ary[po].first){

			pair<int, int> p=go(MP(ary[po].first, ary[po].second));
			t+=p.first;
			f+=p.second;
			continue;
		}
		if(s[to++]%2)
			T++;
		else
			F++;
	}
	if(T<F)
		swap(T, F);
	return MP(T+t, F+f);
}
/******************************/
inline void solve(){
	po=0;to=0;sum=0;
	while(to<n){
		if(po<m && to==ary[po].first){
			pair<int, int> p=go(MP(ary[po].first, ary[po].second));
			sum+=p.first;
			continue;
		}
		if(s[to++]%2)
			sum++;
	}
	cout << sum << endl;
}
/******************************/
int main(){
	int t;
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		read();
		solve();
	}
	return 0;
}
