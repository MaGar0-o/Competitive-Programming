//name: Mohammad Reza Kasnavi Yazdy
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;

#define MP make_pair

const int maxn=1000+10, maxN=1000*1000+100, hash=123457689, Hash=13;
int n;
int a[maxn][maxn], b[maxn][maxn], aa[maxn][maxn], bb[maxn][maxn];
int A[maxn], B[maxn];
bool mark[maxn];
pair<int, int> ary[maxN];
vector<int> rec[14], arya, aryb;

////////////////////////////////
inline void get_A(){
	for(int i=0;i<n;i++){
		int sum=0, po=0;
		for(int j=0;j<n;j++)
			if(aa[i][j]<aa[i][po])
				po=j;
		for(int j=0;j<n;j++){
			sum=(aa[i][po]+sum*Hash)%hash;
			po=(po+1)%n;
		}
		A[i]=sum;
	}
}
/******************************/
inline void get_B(){
	for(int i=0;i<n;i++){
		int sum=0, po=0;
		for(int j=0;j<n;j++)
			if(bb[i][j]<bb[i][po])
				po=j;
		for(int j=0;j<n;j++){
			sum=(bb[i][po]+sum*Hash)%hash;
			po=(po+1)%n;
		}
		B[i]=sum;
	}
}
/******************************/
int main(){
	int t;
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				int x;
				scanf("%d", &x);
				a[j][k]=x;
				ary[j*n+k]=MP(x, j*n+k);
			}
		}
		sort(&ary[0], &ary[n*n]);
		arya.clear();
		arya.resize(n*n);
		for(int j=0;j<n*n;j++)
			arya[j]=ary[j].first;
		for(int j=0;j<n*n;j++){
			int u=ary[j].second;
			aa[u/n][u%n]=j;
		}
		get_A();
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				int x;
				scanf("%d", &x);
				b[j][k]=x;
				ary[j*n+k]=MP(x, j*n+k);
			}
		}
		sort(&ary[0], &ary[n*n]);
		for(int j=0;j<n*n;j++){
			int u=ary[j].second;
			bb[u/n][u%n]=j;
		}
		get_B();
		memset(mark, 0, sizeof mark);
		bool ok=false;
		for(int j=0;j<n;j++){
			ok=false;
			for(int k=0;k<n;k++)
				if(!mark[k] && A[j]==B[k]){
					ok=true;
					mark[k]=1;
					break;
				}
			if(!ok)
				break;
		}
		if(!ok)
			printf("No\n");
		else
			printf("Yes\n");
	}
	return 0;
}
