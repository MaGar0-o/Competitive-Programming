//name: Mohammad Reza Kasnavi Yazdy
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;

#define MP make_pair
#define PB push_back
#define fr(i, n) for(int i=0;i<n;i++)

const int maxn=1000*1000+100;
int n;

vector<int> high;
vector<pair<int, int> > ary;
vector<pair<int, int> > righ, lef;

////////////////////////
inline void read(){
	scanf("%d", &n);
	high.resize(n);
	ary.resize(n);
	for(int i=0;i<n;i++){
		int x;
		scanf("%d", &x);
		high[i]=x;
		ary[i]=MP(x, i);
	}
	sort(ary.begin(), ary.end());
}
/************************/
inline int solve(){
	int v=ary[ary.size()-1].second;
	righ.PB(ary[ary.size()-1]);
	lef.PB(ary[ary.size()-1]);
	for(int i=ary.size()-2;i>=0;i--){
		int u=ary[i].second, l=ary[i].first;
		if(u<v){
			if(u<lef[lef.size()-1].second)
				lef.PB(ary[i]);
		}else{
			if(u>righ[righ.size()-1].second)
				righ.PB(ary[i]);
		}
	}
	int sum=0;
	int po=lef.size()-1, l=lef[lef.size()-1].first, u=lef[lef.size()-1].second;
	for(int i=u;i<v;i++){
		if(i==u){
			l=lef[po].first;
			po--;
			u=lef[po].second;
			continue;
		}
		sum+=l-high[i];
	}
	po=righ.size()-1; l=righ[po].first; u=righ[po].second;
	for(int i=u;i>v;i--){
		if(i==u){
			l=righ[po].first;
			po--;
			u=righ[po].second;
			continue;
		}
		sum+=l-high[i];
	}
	return sum;
}
/**********************/
int main(){
	read();
	int ans=solve();
	cout << ans << endl;
	return 0;
}
