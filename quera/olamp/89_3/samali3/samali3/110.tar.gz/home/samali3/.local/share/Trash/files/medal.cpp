//name: Mohammad Reza Kasnavi Yazdy
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;

struct cmd{
	vector<int> ary;
	inline void push(const int &u){
		ary.push_back(u);
		int v=ary.size()-1;
		int r=(v-1)/2;
		while(v && u<ary[r]){
			swap(ary[v], ary[r]);
			v=r;
			r=(v-1)/2;
		}
	}
	inline int check(){
		if(ary.size())
			return ary[0];
		else
			return -1;
	}
	inline void pop(){
		if(ary.size()==1){
			ary.clear();
			return;
		}
		swap(ary[0], ary[ary.size()-1]);
		ary.resize(ary.size()-1);
		int u=ary[0], v=0;
		int r=v*2+1, t=v*2+2;
		while((r<ary.size() && ary[r]<u) || (t<ary.size() && ary[t]<u)){
			if(ary.size()==t){
				swap(ary[v], ary[r]);
				break;
			}
			int x=ary[r], y=ary[t];
			if(x<y){
				swap(ary[r], ary[v]);
				v=r;
				r=v*2+1;t=v*2+2;
			}else{
				swap(ary[v], ary[t]);
				v=t;
				r=v*2+1;t=v*2+2;
			}
		}
	}
} h;

const int maxn=100*1000+1000;
int n, m, s[maxn];
pair<int, int> ary[maxn], Ary[maxn];
/////////////////////////////////
inline void read(){
	scanf("%d", &n);
	for(int i=0;i<n;i++)
		scanf("%d", &s[i]);
	scanf("%d", &m);
	for(int i=0;i<m;i++){
		int x, y;
		scanf("%d %d", &x, &y);
		ary[i]=make_pair(x-1, y-1);
	}
	sort(&ary[0], &ary[m]);
}
/*******************************/
inline void solve(){
	int po=0, open=0, t=0, f=0, sum=0;
	for(int i=0;i<n;i++){
		cout << "# " << i << "  " << po << " " << open << "  " << t << " " << f << "  " << sum << endl;
		while(po<m && ary[po].first==i){
			open++;
			h.push(ary[po].second);
			po++;
		}
		if(!open){
			if(t!=0 || f!=0){
				if(t>f)
					sum+=t;
				else
					sum+=f;
				t=f=0;
			}
			sum+=s[i]%2;
			continue;
		}
		if((s[i]+open)%2)
			t++;
		else
			f++;
		while(h.check()==i){
			h.pop();
			open--;
		}
	}
	if(t>f)
		sum+=t;
	else
		sum+=f;
	printf("%d\n", sum);
}
/*******************************/
int main(){
	int t;
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		cout << "HI" << endl;
		read();
		for(int i=0;i<n;i++)
			cout << s[i] << " ";
		cout << endl;
		for(int i=0;i<m;i++)
			cout << ary[i].first << " " << ary[i].second << "   ";
		cout << endl;
		solve();
	}
	return 0;
}
