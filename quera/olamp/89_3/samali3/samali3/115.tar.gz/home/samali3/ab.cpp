//name: Nojan Pashanasangi
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cstring>

using namespace std;

const int N=(int) 1e6+10;

int a[N];
int s[N];

int n;
int ind=0;
long long ans=0;


int main()
{
	scanf("%d", &n);
	if((n==1) || (n==2))
	{
		cout << 0 << endl;
		return 0;
	}
	for(int i=0; i < n; i++)
		scanf(" %d", &a[i]);
	s[0]=0;
	s[1]=1;
	ind=2;
	for(int i=2; i < n; i++)
	{
		int x;
		int index=-1;
		for(int j=ind-1; j > 0; j--)
		{
			if(a[s[j]] > a[i])
			{
				index=j;
				break;
			}
		}
		if(index==-1)
			x=min(a[i], a[0]);
		else
			x=min(a[i], a[s[index]]);
		if(index==-1)
			index=0;
		for(int j=index; j < ind-1; j++)
			ans+=(x-min(a[s[j]], a[s[j+1]]))*(s[j+1]-s[j]);
		ind=index+1;
		s[ind]=i;
		ind++;
	}
	cout << ans << endl;
	return 0;
}




