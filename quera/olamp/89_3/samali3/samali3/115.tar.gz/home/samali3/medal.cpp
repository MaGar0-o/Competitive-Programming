//name: Nojan Pashanasangi
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <vector>

using namespace std;

struct node
{
	int x, ind, sf, y;
	node(int a, int b, int c, int d)
	{
		x=a;
		ind=b;
		sf=c;
		y=d;
	}
	node()
	{}
};

typedef pair <int, int> p;

const int N=100*1000+10;

int s[N];
vector <p> last;
vector <int> in[N]; // toosh shoroo o ind ro negah midarim.
int tmp[N];
node baze[2*N];
int mo[N], me[N];
p jen[N];
p baze2[N];
bool mark[N];


int t, n, m;
int ind=0;
int pok=0;

bool cmp(const node &, const node &);
int b_search(int, int, int);
void tartib();
void dfs(int);

int main()
{
	scanf("%d", &t);
	for(int z=0; z < t; z++)
	{
		memset(mark, 0, sizeof mark);
		ind=0;
		pok=0;
		last.clear();
		for(int i=0; i < m; i++)
			in[i].clear();
		scanf(" %d", &n);
		for(int i=0; i < n; i++)
			scanf(" %d", &s[i]);
		scanf(" %d", &m);
		for(int i=0; i < m; i++)
		{
			int x, y;
			scanf(" %d %d", &x, &y);
			x--;
			y--;
			baze2[i]=p (x, y);
			baze[2*i]=node (x, i, 0, y);
			baze[2*i+1]=node (y, i, 1, x);
		}
		sort(baze, baze+2*m, cmp);
		for(int i=0; i < 2*m; i++)
		{
			if(baze[i].sf==1)
			{
				int q=-1;
				if(ind > 0)
				{
					q=b_search(-1, ind-1, baze2[baze[i].ind].first);
					if(q!=-1)
					{
						for(int j=q; j < ind; j++)
						{
							in[baze[i].ind].push_back(tmp[j]);
						}
						ind=q;
					}
				}
				tmp[ind]=baze[i].ind;
				ind++;
			}
		//	cerr << "** " << i  << " " << ind << endl;
		}

		/*
		for(int i=0; i < m; i++)
		{
			cerr << "@ " << i << endl;
			for(int j=0; j < in[i].size(); j++)
				cerr << in[i][j] << " ";
			cerr << endl << endl;
		}
		return 0;
		*/

		for(int i=0; i < m; i++)
			jen[i]=p (in[i].size(), i);
		//
		tartib();
		//
		for(int i=0; i < m; i++)
		{
			int l=jen[i].second;
			mo[l]=me[l]=0;
			if(jen[i].first==0)
			{
				int u=0;
				for(int j=baze2[l].first; j <= baze2[l].second; j++)
					u+=s[j]%2;
				int v=baze2[l].second-baze2[l].first+1;
				mo[l]=max(u, v-u);
				me[l]=max(u, v-u);
				continue;
			}
			// khodesh  o bezarim.
			int numf=0, numz=0;
//			cerr << l << " " <<  baze2[l].first << " " << baze2[in[l][0]].first << endl;
			for(int j=baze2[l].first; j < baze2[in[l][0]].first; j++)
			{
				numf+=(s[j]%2==0);
				numz+=s[j]%2;
			}
//		cerr << "SDF" << endl;
			for(int j=0; j < (int) in[l].size(); j++)
			{
				numf+=me[in[l][j]];
				numz+=mo[in[l][j]];
				if(j < (int) in[l].size()-1)
					for(int k=baze2[in[l][j]].second+1; k <= baze2[in[l][j+1]].first; k++)
					{
						numf+=(s[k]%2==0);
						numz+=s[k]%2;
					}
			}
//		cerr << "SDFsf" << endl;
			for(int j=baze2[in[l][in[l].size()-1]].second+1; j <= baze2[l].second; j++)
			{
				numf+=(s[j]%2==0);
				numz+=s[j]%2;
			}
			mo[i]=max(mo[i], numf);
			me[i]=max(me[i], numz);

			// nazarim o joz
			numf=0;
			numz=0;

			for(int j=baze2[l].first; j < baze2[in[l][0]].first; j++)
			{
				numz+=(s[j]%2==0);
				numf+=s[j]%2;
			}
			for(int j=0; j < (int) in[l].size(); j++)
			{
				numz+=me[in[l][j]];
				numf+=mo[in[l][j]];
				if(j < (int) in[l].size()-1)
					for(int k=baze2[in[l][j]].second+1; k <= baze2[in[l][j+1]].first; k++)
					{
						numz+=(s[k]%2==0);
						numf+=s[k]%2;
					}
			}
			for(int j=baze2[in[l][in[l].size()-1]].second+1; j <= baze2[l].second; j++)
			{
				numz+=(s[j]%2==0);
				numf+=s[j]%2;
			}
			mo[l]=max(mo[l], numf);
			me[l]=max(me[l], numz);
		}
		for(int i=0; i < ind; i++)
			last.push_back(p (baze2[tmp[i]].first, tmp[i]));
		sort(last.begin(), last.end());
		int num=0;
		for(int i=0; i < last[0].first; i++)
			num+=s[i]%2;
		for(int i=0; i < (int) last.size(); i++)
		{
			num+=mo[last[i].second];
			if(i < (int)last.size()-1)
				for(int j=baze2[last[i].second].second+1; j < baze2[last[i+1].second].first; j++)
					num+=s[j]%2;
		}
		for(int i=baze2[last[last.size()-1].second].second+1; i < n; i++)
			num+=s[i]%2;
		printf("%d\n", num);
	}
	return 0;
}

bool cmp(const node &a, const node &b)
{
	if(a.x!=b.x)
		return a.x < b.x;
	if(a.sf!=b.sf)
		return a.sf < b.sf;
	if(a.sf==0)
	{
		if(a.y!=b.y)
			return a.y > b.y;
		return a.ind < b.ind;
	}
	if(a.y!=b.y)
		return a.y > b.y;
	return a.ind > b.ind;
}

int b_search(int l, int r, int x)
{
	if(r-l==1)
	{
		if(baze2[tmp[r]].first >= x)
			return r;
		else
			return -1;
	}
	int mid=(l+r)/2;
	if(baze2[tmp[mid]].first >= x)
		return b_search(l, mid, x);
	return b_search(mid, r, x);
}

void tartib()
{
	for(int i=0; i < m; i++)
		if(!mark[i])
			dfs(i);
}

void dfs(int u)
{
	mark[u]=1;
	for(int i=0; i < (int) in[u].size(); i++)
		if(!mark[in[u][i]])
			dfs(in[u][i]);
	jen[pok]=p (in[u].size(), u);
	pok++;
}



