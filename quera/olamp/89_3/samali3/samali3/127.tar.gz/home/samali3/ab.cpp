//name: Mohammadamin Shabani
/*						IN THE NAME OF GOD
 */
#include <iostream>
#include <cstdio>
using namespace std;
const int Maxn=1000 * 1000 + 10;

struct node{
	int a;
	int b;
};

int n;
int h[Maxn];
int res;
node d[Maxn];
/************************/
inline void input(){
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		scanf("%d",&h[i]);
}
/************************/
inline void SetDpa(){
	int mh=0;
	for(int i=0;i<n;i++){
		if(h[i]<mh){
			d[i].a=mh;
		}
		else{
			mh=h[i];
			d[i].a=mh;
		}
	}
}
/************************/
inline void SetDpb(){
	int mh=0;
	for(int i=n-1;i>=0;i--){
		if(h[i]<mh){
			d[i].b=mh;
		}
		else{
			mh=h[i];
			d[i].b=mh;
		}
	}
}
/************************/
inline void solve(){
	for(int i=0;i<n;i++){
		if(h[i]<d[i].a && h[i]<d[i].b){
			res+=min(d[i].a,d[i].b)-h[i];
		}
	}
}
/************************/
int main(){
//	cerr<<(sizeof d+sizeof h)/1024<<endl;
	input();
	SetDpa();
	SetDpb();
	solve();
	cout<<res<<endl;
	return 0;
}
