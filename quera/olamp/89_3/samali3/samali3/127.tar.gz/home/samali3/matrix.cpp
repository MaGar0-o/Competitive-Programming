//name: Mohammadamin Shabani
/*						IN THE NAME OF GOD
 */
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cmath>
using namespace std;
const int Maxn=1000 + 10;
const int Maxint=(1u<<31)-1;

int r=1;
int n,t;
int a[Maxn][Maxn],b[Maxn][Maxn];
int c[3][Maxn],d[3][Maxn];
int o[Maxn*Maxn],l[Maxn*Maxn];
/**************************/
inline bool Majzoor(int k){
	bool tmp2=false;
	if(k==1)
		for(int j=0;j<r;j++)
			for(int i=0;i<n;i++){
				int tmp=sqrt(c[i][j]);
				if(tmp!=c[i][j])	tmp2=true;
				//cerr<<tmp<<' '<<c[i][j]<<endl;
				if(tmp * tmp != c[i][j])	return false;
			}
	else
		for(int j=0;j<r;j++)
			for(int i=0;i<n;i++){
				int tmp=sqrt(d[i][j]);
				if(tmp!=d[i][j]) tmp2=true;
				if(tmp * tmp !=d[i][j])	return false;
			}
	if(tmp2==true)
		return true;
	else return false;
}
/**************************/
inline void input(){
	scanf("%d",&n);
	for(int k=0;k<2;k++){
		int Min=Maxint,Mini,Minj;
		int Max=0,Maxi,Maxj;
		for(int j=0;j<n;j++)
			for(int i=0;i<n;i++){
				scanf("%d",&a[i][j]);
				if(k==0)	b[i][j]=a[i][j];
				if(Max<a[i][j]){
					Max=a[i][j];
					Maxi=i;
					Maxj=j;
				}
				if(Min>a[i][j]){
					Min=a[i][j];
					Mini=i;
					Minj=j;
				}
			}
		for(int i=0;i<n;i++){
			if(k==0)
				c[i][0]=a[(Mini+i)%n][Minj];
			else
				d[i][0]=a[(Mini+i)%n][Minj];
		}
		if(Maxj!=Minj){
			r=2;
			for(int i=0;i<n;i++){
				if(k==0)
					c[i][1]=a[(Maxi+i)%n][Maxj];
				else
					d[i][1]=a[(Maxi+i)%n][Maxj];
			}
		}
	}
}
/**************************/
inline void solve(){
	bool tmp2=true;
	while(tmp2){
		if(Majzoor(1)){
//			cerr<<"c1"<<' ';
			for(int j=0;j<r;j++)
				for(int i=0;i<n;i++)
					c[i][j]=sqrt(c[i][j]);
			
			for(int i=0;i<n;i++)
				for(int j=0;j<n;j++)
					b[i][j]=sqrt(b[i][j]);
		}
		while(!Majzoor(1)){
			if(c[0][0]==0){
				tmp2=false;
				break;
			}
//			cerr<<"c2 "<<endl;
			for(int j=0;j<r;j++)
				for(int i=0;i<n;i++)
					c[i][j]--;

			for(int i=0;i<n;i++)
				for(int j=0;j<n;j++)
					b[i][j]--;
		}
	}
//	cerr<<endl;
	tmp2=true;
	while(tmp2){
		if(Majzoor(2)){
//			cerr<<"d1 ";
			for(int j=0;j<r;j++)
				for(int i=0;i<n;i++)
					d[i][j]=sqrt(d[i][j]);
			for(int j=0;j<n;j++){
				for(int i=0;i<n;i++){
					a[i][j]=sqrt(a[i][j]);
				}
			}
		}
		while(!Majzoor(2)){
			if(d[0][0]==0){
				tmp2=false;
				break;
			}
//			cerr<<"d2 "<<' ';
			for(int j=0;j<r;j++)
				for(int i=0;i<n;i++)
					d[i][j]--;

			for(int j=0;j<n;j++)
				for(int i=0;i<n;i++)
					a[i][j]--;
		}
	}
//	cerr<<endl;
}
/**************************/
inline void output(){
	for(int j=0;j<n;j++){
		for(int i=0;i<n;i++){
//			cerr<<d[i][j]<<endl;
			o[j*n+i]=a[i][j];
			l[j*n+i]=b[i][j];
//			if(a[i][j]!=b[i][j]){
//				cout<<"No"<<endl;
//				return;
//			}
		}
	}
	sort(&o[0],&o[n*n]);
	sort(&l[0],&l[n*n]);
	for(int i=0;i<n*n;i++){
//		cerr<<o[i]<<' '<<l[i]<<endl;
		if(o[i]!=l[i]){
			cout<<"No"<<endl;
			return;
		}
	}
	cout<<"Yes"<<endl;
}
/**************************/
int main(){
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		r=1;
		input();
		solve();
		output();
	}
	return 0;
}
