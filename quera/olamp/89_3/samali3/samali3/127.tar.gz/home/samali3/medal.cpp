//name: Mohammadamin Shabani
/*						IN THE NAME OF GOD
 */
#include <iostream>
#include <algorithm>
#include <cstring>
#include <vector>
#include <cstdio>
#define pb push_back
using namespace std;
const int Maxn=1000 * 100 + 10;		// !!!!!!

struct node{
	int a;
	int b;
//	vector <int> c;
	bool operator <(const node &second)const{
		if(b-a!=second.b-second.a)	return b-a<second.b-second.a;
		if(a!=second.a)	return a<second.a;
		return b<second.b;
	}
};

int n,m,t,res;
int d[Maxn];
int matris[Maxn];
node p[Maxn];

int col[Maxn];
int next[Maxn];
int prev[Maxn];
/************************/
inline void input(){
	res=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&d[i]);
		if((d[i])%2!=0)	res++;
	}
	scanf("%d",&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&p[i].a,&p[i].b);
//		p[i].a--;p[i].b--;
	}
}
/************************/
inline void init(){
	memset(matris,0,sizeof matris);
	memset(col,0,sizeof col);
	sort(&p[1],&p[m+1]);
	for(int i=0;i<=n+5;i++){
		next[i]=i+1;
		prev[i]=i-1;
	}
}
/************************/
inline void solve(){
	for(int i=1;i<=m;i++){
		int tmp=0;
		for(int j= matris[p[i].a]>0 ? next[0] : p[i].a ;j<=p[i].b;j=next[j]){
//			cerr<<j<<' '<<next[j]<<endl;
			if(j>=p[i].a){
				next[prev[j]]=next[j];
				prev[next[j]]=prev[j];
				prev[j]=tmp;
				tmp=j;
				matris[j]=i;
			}
		}
	}
	for(int i=1;i<=n;i++){
		if(matris[i]!=0)
			col[matris[i]]=i;
	}
	for(int i=1;i<=m;i++){
		int here=col[i],RES=0;
		while(here!=0){
			if((d[here]+1) % 2!=0)
				RES++;
			else RES--;
//			cerr<<i<<' '<<RES<<' '<<here<<' '<<d[here]<<endl;
			here=prev[here];
		}
		if(RES>0) res+=RES;
	}
}
/************************/
inline void output(){
	cout<<res<<endl;
}
/************************/
int main(){
//	cerr<<(sizeof val+sizeof next+sizeof prev+sizeof d+sizeof matris+sizeof p)/1024<<endl;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		input();
//		cerr<<"input was complete"<<endl;
		init();
//		cerr<<"init was complete"<<endl;
		solve();
//		cerr<<"solve was complete"<<endl;
		output();
	}
	return 0;
}
