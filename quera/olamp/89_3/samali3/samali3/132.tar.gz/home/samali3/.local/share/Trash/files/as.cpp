
#include <cstdio>
#include <algorithm>
#include <iostream>

using namespace std;

struct node {
	int first, second;
};

const int MAXN = 10000;
bool a[MAXN + 1];
node b[MAXN+ 1];
bool isMarked[MAXN + 1];
int dyn[2][MAXN + 1];

bool operator < (node n1, node n2) {
	if ((n1.second - n1.first) == (n2.second - n2.first))
		return n1.first < n2.first;
	return (n1.second - n1.first) < (n2.second - n2.first);
}

int main() {
	int t=20;
	for (int i = 0; i < t; i++) {
		int n=1000;
		for (int j = 1; j <= n; j++) {
			int d=j;
			a[j] = (d % 2);
		}
		int m=1000;
		for (int j = 0; j < m; j++){
			b[j].first=j;
			b[i].second=j+1;
		}
		sort(b, b + m);
		int s = 0;
		for (int j = b[0].first; j <= b[0].second; j++)
			s += a[j];
		dyn[0][0] = min(b[0].second - b[0].first - s + 1, s);
		dyn[1][0] = max(b[0].second - b[0].first - s + 1, s);
		for (int j = 1; j < m; j++) {
			int mi = 0,ma = 0;
			for (int q = b[j].first; q <= b[j].second; q++)
				isMarked[q] = false;
			for (int q=(j - 1); q>=0;q--) {
				if ((b[q].first >= b[j].first) && (b[q].second <= b[j].second))
					if (!isMarked[b[q].first] && !isMarked[b[q].second]) {
						mi += dyn[0][q];
						ma += dyn[1][q];
						for (int w = b[q].first; w <= b[q].second; w++)
							isMarked[w] = true;
					}
			}
			int s1 = 0, s2 = 0;
			for (int q = b[j].first; q <= b[j].second; q++)
				if (!isMarked[q]) {
					if (a[q])
						s2++;
				}
			mi += s2;
			ma += s2;
			dyn[0][j] = min(min(mi, ma), min(b[j].second-b[j].first + 1 - mi, b[j].second - b[j].first+ 1 - ma));
			dyn[1][j] = max(max(mi, ma), max(b[j].second-b[j].first + 1 - mi, b[j].second - b[j].first+ 1 - ma));
		}
		int sss = 0;
		for (int j = 1;j <=n;j++)
			isMarked[j] = false;
		for (int j = (m - 1); j >= 0; j--) {
			if(!isMarked[b[j].first]&& !isMarked[b[j].second]) {
				sss+= dyn[1][j];
				for (int ww = b[j].first;ww<=b[j].second;ww++)
					isMarked[ww]=true;
			}
		}
		for (int j = 1; j<=n; j++)
			if(!isMarked[j] && a[j])
				sss++;
		printf("%d\n", sss);
	}
	return 0;
}

