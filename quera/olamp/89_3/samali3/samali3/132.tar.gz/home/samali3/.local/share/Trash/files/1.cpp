#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;

struct no {
	int first, second;
};
bool operator <(no n, no m) {
	if(n.second - n.first==m.second-m.first)
		return n.first<m.first;
	return (n.second-n.first) < (m.second-m.first);
}
no b[3];

int main(){
	scanf("%d%d%d%d%d%d", &b[0].first, &b[0].second,&b[1].first,&b[1].second,&b[2].first,&b[2].second);
sort(b, b + 3);
cerr << b[0].first;
}
