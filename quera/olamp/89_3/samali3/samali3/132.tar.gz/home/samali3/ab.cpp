//name: Mojtaba Ansari

#include <cstdio>
#include <algorithm>

using namespace std;

const int MAXN = 1000000;
int a[MAXN + 1];
int dyn[MAXN + 1];
int dyn2[MAXN + 1];

int main() {
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d", &a[i]);
	dyn[0] = -1;
	for (int i = 1; i < n; i++) {
		if (dyn[i - 1] > -1) {
			if (dyn[i - 1] > a[i])
				dyn[i] = dyn[i - 1];
			else
				dyn[i] = -1;
		}
		else {
			if (a[i] > a[i - 1])
				dyn[i] = -1;
			else
				dyn[i] = a[i - 1];
		}	
	}
	dyn2[n - 1] = -1;
	for (int i = (n - 2); i >= 0; i--) {
		if (dyn2[i + 1] > -1) {
			if (dyn2[i + 1] > a[i])
				dyn2[i] = dyn2[i + 1];
			else
				dyn2[i] = -1;
		}
		else {
			if (a[i] > a[i + 1])
				dyn2[i] = -1;
			else
				dyn2[i] = a[i + 1];
		}
	}
	int sum = 0;
	for (int i = 0; i < n; i++)
		if ((dyn[i] > -1) && (dyn2[i] > -1))
			sum += (min(dyn[i], dyn2[i]) - a[i]);
	printf("%d\n", sum);
	return 0;
}

