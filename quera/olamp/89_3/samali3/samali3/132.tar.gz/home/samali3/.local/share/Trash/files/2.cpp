#include <cstdio>
#include <vector>
#include <list>

using namespace std;

struct node {
	int mi, ma;
};

struct no {
	int num, mi, ma;
};

int ss = 0;
int bb = 0, ll = 0;
bool operator < (node n1, node n2) {
	if (n1.mi == n2.mi)
		return n1.ma < n2.ma;
	return n1.mi < m2.mi;
}

list <no> kk;
vector <no> ans;
const int MAXN = 100000;
bool a[MAXN + 1];
node b[MAXN + 1];
vector <int> matrix[MAXN + 1][2];
int ww[MAXN + 1];

int main() {
	int t;
	scanf("%d", &t);
	for (int count = 0; count < t; count++) {
		for (int i = 0; i <= n; i++) {
			matrix[i][0].resize(0);
			matrix[i][1].resize(0);
			ww[i] = 0;
		}
		int n;
		scanf("%d", &n);
		for (int i = 0; i < n; i++) {
			int d;
			scanf("%d", &d);
			a[i] = (d % 2);
		}
		int m;
		scanf("%d", &m);
		for (int i = 0; i < m; i++)
			scanf("%d%d", &b[i].mi, &b[i].ma);
		sort(b, b + m);
		for (int i = 0; i < m; i++) {
			no ss = {i, b[i].mi, b[i].ma};
			kk.push_back(b[i]);
		}
		for (int i = 1; i <= n; i++) {
			if ((*(kk.begin())).ma == i) {
				while ((*(kk.begin()).ma) == i) {
					ans.push_back(*(kk.begin()));
					kk.pop_front();
				}
			}
			if (ans[ans.size() - 1] == i) {
				vector <no> :: iterator ii = kk.end();
				ii--;
				int len = matrix[(*ii).num].size();
				int mm1 = 0, mm2 = 0;
				for (int j = 0; j < len; j++) {
					mm1 += matrix[(*ii).num][0][j];
					mm2 += matrix[(*ii).num][1][j];
				}
				mm1 += ww[(*ii).num];
				mm2 += ww[(*ii).num];
				int h = min(mm1, b[(*ii).ma] - b[(*ii).mi] + 1 - mm2);
				int y = max(mm2, b[(*ii).ma] - b[(*ii).mi] + 1 - mm2);
				ii--;
				matrix[(*ii).num][0].push_back(h);
				matrix[(*ii).num][1].push_back(y);
				ans.pop_back();
				if (!ans.size()) {
					ll += h;
					bb += y;
				}
			}
			else {
				if (ans.size())
					ww[ans[ans.size() - 1]]++;
				else
					ss++;
			}
		}
		bb += ss;
		ll += ss;
		printf("%d\n", max(bb, n - ll));
	}
	return 0;
}

