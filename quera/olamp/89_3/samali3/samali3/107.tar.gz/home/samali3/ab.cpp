//name: Hamid Doosthosseini

#include <iostream>

using namespace std;

const int MAXn=1000*1000+100;
int cit[3][MAXn];

int main()
{
	int n, maxr=0, maxl=0, ans=0;
	cin >> n;
	for (int i=0; i<n; i++)
	{
		cin >> cit[0][i];
		if (cit[0][i]>maxr)
			maxr=cit[0][i];
		cit[1][i]=maxr;
//		cout << cit[1][i] << " ";
	}
//	cout << endl;
	for (int i=n-1; i>=0; i--)
	{
		if (cit[0][i]>maxl)
			maxl=cit[0][i];
		cit[2][i]=maxl;
//		cout << cit[2][i] << " ";
		ans+=min(cit[1][i],cit[2][i])-cit[0][i];
	}
	cout << ans;
	return 0;
}
