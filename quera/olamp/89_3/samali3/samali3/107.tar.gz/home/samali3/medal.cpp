//name: Hamid Doosthosseini

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdio>

using namespace std;

const int MAXn=1000;
vector <int> ra;
int ans=0;
bool mark[MAXn];

struct ba
{
	int beg, end, len, pere, o, e, addo, adde, res;
};

vector <ba> gen;

bool operator < (ba a, ba b)
{
	if (a.len<b.len)
		return 1;
	return 0;
}

int med()
{
	ans=0;
	int m, n;
	scanf ("%d", &n);
	for (int i=0; i<n; i++)
	{
		int x;
		scanf ("%d", &x);
		ra.push_back(x);
	}
	scanf ("%d", &m);
	for (int i=0; i<m; i++)
	{
		ba x;
		scanf("%d", &x.beg);
		scanf("%d", &x.end);
		x.len=x.end-x.beg+1;
		x.pere=0; x.o=0; x.e=0; x.addo=0; x.adde=0; x.res=0;
		for (int j=x.beg; j<=x.end; j++)
		{
			mark[j-1]=true;
			if (ra[j-1]%2==1)
				x.o++;
			else
				x.e++;
		}
		gen.push_back(x);
	}
	sort(gen.begin(), gen.end());
	for (int i=0; i<gen.size(); i++)
		for (int j=i+1; j<gen.size(); j++)
			if (gen[j].beg <= gen[i].beg  &&  gen[j].end >= gen[i].end)
			{
				gen[i].pere=j;
				break;
			}
	for (int i=0; i<gen.size(); i++)
	{
		gen[i].res=max(gen[i].o+gen[i].addo,gen[i].e+gen[i].adde);
		gen[gen[i].pere].addo+=gen[i].res-gen[i].o;
		gen[gen[i].pere].adde+=gen[i].res-gen[i].e;
		if (gen[i].pere==0)
			ans+=gen[i].res;
	}
//	for (int i=0; i<gen.size(); i++)
//		cout << gen[i].beg << " " << gen[i].end << " o: " << gen[i].o << " e: " << gen[i].e << " the res: " << gen[i].res << " the father: " << gen[i].pere << endl;
	for (int i=0; i<n; i++)
	{
//		cout << mark[i] << " ";
		if (mark[i]==false && ra[i]%2==1)
			ans++;
		if (mark[i]==true)
			mark[i]=false;
	}
	gen.clear();
	ra.clear();
	return ans;
}

int main()
{
	int t;
	scanf("%d", &t);
	for (int i=0; i<t; i++)
		cout << med() << endl;
	return 0;
}
