//name: Hossein Shayesteh
#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;

#define MaxN 100005
#define MaxM 200010

int t, n, m, h, h2, fc[MaxN], zc[MaxN], b[MaxN], w[MaxN], fall, zall;
bool a[MaxN];
pair <int, int> q[MaxN];
pair <pair <int, int>, pair<int, int> > gen[MaxM];

/*bool cmp (const pair <pair <int, int>, pair<int, int> > g1, pair <pair <int, int>, pair<int, int> > g2){
	if (g1.first.first == g2.first.first && g1.first.second == g2.first.second && g1.second.first == g2.second.first)
		return g1.second.second < g2.second.second;
	if (g1.first.first == g2.first.first && g1.first.second == g2.first.second)
		return g1.second.first < g2.second.first;
	if (g1.first.first == g2.first.first)
		return g1.first.second < g2.first.second;
	return g1.first.first < g2.first.first;
}*/

void solve(){
	int bst=0, wst=0, p, g, l, z, f;
	for (int i=0; i<m*2; i++){
		p = gen[i].first.first;
		g = gen[i].second.second;
		l = q[g].second - q[g].first + 1;
		z = zc[q[g].second] - zc[q[g].first-1];
		f = fc[q[g].second] - fc[q[g].first-1];
		if (!gen[i].first.second){
			b[g] = bst;
			w[g] = wst;
		}
		else {
			int bst2 = b[g], wst2 = w[g];
			h = bst - b[g];
			h2 = wst - w[g];
			bst2 = max(bst2, bst);
			bst2 = max(bst2, b[g] + (z + h2 - f));
			wst2 = max(wst2, wst);
			wst2 = max(wst2, w[g] + ((f + h) - z));
			bst = bst2;
			wst = wst2;
			//cout <<"##" <<b[g] <<endl;
			//cout <<"$$" <<bst <<" " <<wst <<endl;
		}
	}
	cout <<bst+fall <<endl;
}

int main(){
	scanf ("%d", &t);
	for (int j=1; j<=t; j++){
		scanf ("%d", &n);
		fall = zall = 0;
		for (int i=1; i<=n; i++){
			scanf ("%d", &h);
			fc [i] = fc[i-1];
			zc [i] = zc[i-1];
			if (!(h % 2)){
				zc [i]++;
				a[i] = 1;
				zall++;
			}
			else{
				fall++;
				fc[i]++;
			}
		}
		scanf ("%d", &m);
		for (int i=0; i<m; i++){
			scanf ("%d %d", &h, &h2);
			q[i] = make_pair(h, h2);
			gen[i*2] = make_pair(make_pair(h, 0), make_pair(-1*h2, i));
			gen[i*2+1] = make_pair (make_pair (h2, 1), make_pair (-1*h, i));
		}
		sort (gen, gen + m*2);
		solve(); 
	}	
	return 0;
}
