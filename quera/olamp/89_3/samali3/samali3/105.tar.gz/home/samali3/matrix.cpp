//name: Hossein Shayesteh
#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;

#define MaxN (1005)

int t, n, a[MaxN][2*MaxN], b[MaxN][2*MaxN], a2[MaxN][MaxN], b2[MaxN][MaxN], mp1[MaxN], mp2[MaxN];
pair <int, int> rs1[MaxN], rs2[MaxN], bil1[MaxN], bil2[MaxN];

void solve1(){
	for (int i=0; i<n; i++){
		int r1 = rs1[i].second, r2 = rs2[i].second;
		for (int j=0; j<=mp1[r1]; j++)
			a[r1][j+n] = a[r1][j];
		for (int j=0; j<n; j++)
			a2[i][j] = a[r1][j+mp1[r1]+1];
		for (int j=0; j<=mp2[r2]; j++)
			b[r2][j+n] = b[r2][j];
		for (int j=0; j<n; j++)
			b2[i][j] = b[r2][j+mp2[r2]+1];
	}
}

void solve2(){
	int h;
	if (a2[0][0] % 2 == b2[0][0] % 2)
		h = 1;
	else
		h = 2;
	for (int i=0; i<n; i++){
		for (int j=0; j<n; j++){
			int h2;
			if (a2[i][j] % 2 == b2[i][j] % 2)
				h2 = 1;
			else
				h2 = 2;
			if (h2 != h){
				cout <<"No" <<endl;
				return ;
			}
			rs1[j] = make_pair(a2[i][j], j);
			rs2[j] = make_pair(b2[i][j], j);
		}
		sort (rs1, rs1 + n);
		sort (rs2, rs2 + n);
		for (int j=0; j<n; j++){
			if (j > 0){
				bil1[j-1] = make_pair (rs1[j].first - rs1[j-1].first, rs1[j].second);
				bil2[j-1] = make_pair (rs2[j].first - rs2[j-1].first, rs2[j].second);
			}
			if (rs1[j].second != rs2[j].second){
				cout <<"No" <<endl;
				return;
			}
		}
		sort (bil1, bil1 + n - 1);
		sort (bil2, bil2 + n - 1);
		for (int j=0; j<n-1; j++){
			if (bil1[j].second != bil2[j].second){
				cout <<"No" <<endl;
				return ;
			}
		}
	}
	cout <<"Yes" <<endl;
}

int main(){
	scanf ("%d", &t);
	for (int c=0; c<t; c++){
		scanf ("%d", &n);
		for (int i=0; i<n; i++){
			int mx = 0;
			for (int j=0; j<n; j++){
				scanf ("%d", &a[i][j]);
				if (mx < a[i][j]){
					mx = a[i][j];
					mp1 [i] = j;
				}
			}
			rs1[i] = make_pair(mx, i);
		}
		for (int i=0; i<n; i++){
			int mx = 0;
			for (int j=0; j<n; j++){
				scanf ("%d", &b[i][j]);
				if (mx < b[i][j]){
					mx = b[i][j];
					mp2 [i] = j;
				}
			}
			rs2[i] = make_pair(mx, i);
		}
		sort (rs1, rs1 + n);
		sort (rs2, rs2 + n);
		solve1();
		solve2();
	}
	return 0;
}
