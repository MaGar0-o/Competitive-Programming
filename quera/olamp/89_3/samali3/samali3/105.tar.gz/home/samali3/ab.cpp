//name: Hossein Shayesteh
#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;

#define MaxN 1000005

int n, a[MaxN], lmax[MaxN], rmax[MaxN];

int main(){
	scanf ("%d", &n);
	for (int i=1; i<=n; i++){
		scanf ("%d", a+i);
	}
	long long s=0;
	for (int i=1; i<=n; i++){
		lmax [i] = max(lmax[i-1], a[i]);
	}
	for (int i=n; i>0; i--){
		rmax [i] = max(rmax[i+1], a[i]);
		s += max(0, min(lmax[i], rmax[i]) - a[i]);
	}
	cout <<s <<endl;
	return 0;
}
