#! /bin/bash

echo 1 > test2.in
n=1000
echo $n >> test2.in
for((i=0;i<$n;i++)); do
	echo $[$RANDOM % 9] >> test2.in;
done
echo $n >> test2.in
for((i=1;i<=$n;i++)); do
	echo 1 $i >> test2.in;
done
