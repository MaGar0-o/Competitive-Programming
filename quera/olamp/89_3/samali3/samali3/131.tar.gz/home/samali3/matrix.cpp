//name: Navid Salehnamadi

#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>

using namespace std;


struct linkedList
{
	bool e;
	linkedList *next;
	linkedList()
	{
		next = NULL;
	}
};
const int maxN = 1000 + 5;
linkedList* forFun[2][maxN];
int matrix[2][maxN][maxN];
int n;

void initialize()
{
	cin >> n;
	for(int i =0; i<n; i++)
		for(int j =0; j<n; j++)
			cin >> matrix[0][i][j];
	for(int i =0; i<n; i++)
		for(int j =0; j<n; j++)
			cin >> matrix[1][i][j];
	for(int i =0; i<n; i++)
	{
		forFun[0][i] = new linkedList();
		linkedList *it = forFun[0][i];
		for(int j =n-1; j>0; j--)
		{
			bool b = matrix[0][i][j] < matrix[0][i][j-1];
			it->e = b;
			it->next = new linkedList();
			it = it->next;
		}
		it->e = matrix[0][i][0] < matrix[0][i][n-1];
		forFun[1][i] = new linkedList();
		it = forFun[1][i];
		for(int j =n-1; j>0; j--)
		{
			bool b = matrix[1][i][j] < matrix[1][i][j-1];
			it->e = b;
			it->next = new linkedList();
			it = it->next;
		}
		it->e = matrix[1][i][0] < matrix[1][i][n-1];
	}
}

void print( linkedList *l)
{
	cout << l->e;
	if( l->next == NULL)
	{
		cout << endl;
		return;
	}
	print( l->next);
}

int howManyOne(linkedList *l)
{
	if( l->next == NULL)
		return l->e;
	return howManyOne(l->next) + l->e;
}

bool compare(linkedList *l1, linkedList *l2)
{
	if(l1->e != l2->e)
		return false;
	if( l1->next == NULL)
		return true;
	return compare( l1->next, l2->next);
}

linkedList* getLast(linkedList *l)
{
	if( l->next == NULL)
		return l;
	return getLast(l->next);
}

linkedList* rotate( linkedList *first, linkedList *last)
{
	last->next = first;
	linkedList *l = first->next;
	first->next = NULL;
	return l;
}

int cap[maxN*2][maxN*2];
void makeCap()
{
	for(int i =0; i<n; i++)
	{
		linkedList *it1 = forFun[0][i];
		int size1 = howManyOne(it1);
		for(int j =0; j<n; j++)
		{
			cap[i][j+n] = 0;
			linkedList *it2 = forFun[1][j];
			int size2 = howManyOne(it2);
			if( size1 != size2)
				continue;
			for(int k =0; k<n; k++)
			{
				if(compare(it1,it2) == true)
				{
					cap[i][j+n] = 1;
					break;
				}
				it2 = rotate(it2, getLast(it2));
			}
		}
	}
	for(int i =0; i<2*n; i++)
	{
		cap[i][n+n] = 0;
		cap[n+n][i] = 0;
		cap[i][n+n+1] = 0;
		cap[n+n+1][i] = 0;
	}
	for(int i =0; i<n; i++)
	{
		cap[n*2][i] = 1;
		cap[n+i][n*2+1] = 1;
	}

}


queue<int> q;
int par[maxN*2];

int floyd_inc(int s, int e)
{
	for(int i =0; i<2*n+2; i++)
		par[i] = -1;
	par[s] = s;
	q.push(s);
	while(q.size() > 0)
	{
		int v = q.front();
		q.pop();
		for(int i =0; i<2*n+2; i++)
		{
			if( cap[v][i] > 0 && par[i] == -1)
			{
				par[i] = v;
				q.push(i);
			}
		}
	}
	if( par[e] == -1)
		return 0;
	int floyd = -1u/2;
	for(int hr = e; hr !=s; hr = par[hr])
		floyd = min( floyd, cap[par[hr]][hr]);
	for(int hr = e; hr!= s; hr = par[hr])
	{
		cap[hr][par[hr]] += floyd;
		cap[par[hr]][hr] -= floyd;
	}
	return floyd;
}


int main()
{
	ios::sync_with_stdio(false);
	int t;
	cin >> t;
	for(int i =0; i<t; i++)
	{
		initialize();
		makeCap();
		int res = 0;
		int k = floyd_inc(n+n,n+n+1);
		while( k != 0)
		{
			res +=k;
			k = floyd_inc(n+n,n+n+1);
		}
		if( res==n)
			cout << "YES" << endl;
		else
			cout << "NO" << endl;
	}

	return 0;
}
