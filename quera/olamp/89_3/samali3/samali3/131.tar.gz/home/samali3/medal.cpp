//name: Navid Salehnamadi

#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

struct general
{
	int a,b;
	int es;// sarbaz haie ke jozve bache hash nistand va zoj medal darand
	int os;// sarbaz haie ke jozve bache hash nistand va fard medal darand
	int maxES;//bishtarin sarbazi ke fard ta medal migirand
	int par;
	bool mark;
	vector<int> edges;// bache hash
};


const int maxN = 1000*100 + 10;
int t,n,m;
general gg[maxN];
bool solMed[maxN];
pair<int,int> baze[maxN];
bool mark[maxN];


void updateES()
{
	for(int i =0; i<m; i++)
	{
		if( gg[i].edges.size() == 0)
		{
			for(int k = gg[i].a; k<=gg[i].b; k++)
			{
				if(solMed[k] == true)
					gg[i].es++;
				else
					gg[i].os++;
				mark[k] = true;
			}
		}
		else
		{
			int lp = gg[i].edges[ gg[i].edges.size() -1];
			for(int j = gg[i].edges.size()-1; j>=0; j--)
				if( gg[ gg[i].edges[j]].par == i)
				{
					lp = j;
					break;
				}
			for(int k=gg[i].a; k< gg[gg[i].edges[0]].a; k++)
			{
				if( solMed[k] == true)
					gg[i].es++;
				else
					gg[i].os++;
				mark[k] = true;
			}
			int bf = 0;
			for(int j =1; j<=lp; j++)
			{
				if( gg[ gg[i].edges[j]].par != i)
					continue;
				for(int k =gg[gg[i].edges[bf]].b+1; k < gg[gg[i].edges[j]].a; k++)
				{
					if( solMed[k] == true)
						gg[i].es++;
					else
						gg[i].os++;
					mark[k] = true;
				}
				bf = j;
			}
			for(int k=gg[gg[i].edges[ lp]].b +1; k<= gg[i].b; k++)
			{
				if( solMed[k] == true)
					gg[i].es++;
				else
					gg[i].os++;
				mark[k] = true;
			}
		}
	}
}

void updateEdge()
{
	for(int i =0; i<m; i++)
	{
		baze[i].second *=-1;
		gg[i].a = baze[i].first;
		gg[i].b = baze[i].second;
		pair<int,int> p = make_pair( baze[i].second, 0 );
		int k = lower_bound(baze+i, baze+m,p) - baze;
		for(int j = i+1; j<k; j++)
		{
			gg[i].edges.push_back(j);
			gg[j].par = i;
		}
	}
/*	for(int i =0; i<m; i++)
	{
		for(int j =0; j<(int) gg[i].edges.size(); j++)
		{
			if( gg[gg[i].edges[j]].par != i)
			{
				gg[i].edges.erase(gg[i].edges.begin() +j, gg[i].edges.begin()+j+1);
				j--;
			}
		}
	}*/

}


void initialize()
{
	ios::sync_with_stdio(false);
	cin >> n;
	for(int i =0; i<n; i++)
	{
		int k;
		cin >> k;
		solMed[i] = k%2;
		mark[i] = false;
	}
	cin >> m;
	for(int i =0; i<m; i++)
	{
		int a,b;
		cin >> a >>b;
		a--;
		b--;
		baze[i]=make_pair(a,-b);
		gg[i].par = i;
		gg[i].mark = false;
		gg[i].es =0;
		gg[i].os = 0;
		gg[i].maxES = 0;
		gg[i].edges.clear();
	}
	sort(baze, baze +m);
	m = unique(baze, baze +m) - baze;
	updateEdge();
	updateES();
}

void dfs(int v)
{
	gg[v].mark = true;
	if( gg[v].edges.size() == 0)
	{
		gg[v].maxES = max( gg[v].es, gg[v].os);
		return;
	}	
	int ee = 0;
	int oo = 0;
	for(int i =0; i<(int) gg[v].edges.size(); i++)
	{
		if( gg[gg[v].edges[i]].par != v)
		{
			continue;
		}
		dfs(gg[v].edges[i]);
		ee += gg[ gg[v].edges[i]].maxES;
		oo += gg[ gg[v].edges[i]].maxES;
	}
	ee += gg[v].es;
	oo += gg[v].os;
	gg[v].maxES = max(ee,oo);
}

int main()
{
	ios::sync_with_stdio(false);
	cin >> t;
	for(int i =0; i<t; i++)
	{
		initialize();
		int e = 0;
		for(int i =0; i<m;i++)
		{
			if( gg[i].mark == false)
			{
				dfs(i);
				e += gg[i].maxES;
			}
		}
		for(int i =0; i<n; i++)
			if( mark[i] == false && solMed[i] == true)
				e++;
		cout << e << endl;
	}
	return 0;
}
