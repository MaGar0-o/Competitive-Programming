#! /bin/bash

n=1000000
echo $n > test1.in
for((i=0;i<$n;i++)); do
	echo $[$RANDOM % 1001] >> test1.in;
done
