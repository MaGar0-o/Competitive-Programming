//name: Navid Salehnamadi

#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>

using namespace std;


struct linkedList
{
	bool e;
	linkedList *next;
	linkedList()
	{
		next = NULL;
	}
};
const int maxN = 1000 + 5;
linkedList* forFun[2][maxN];
int matrix[2][maxN][maxN];
int n;

void initialize()
{
	cin >> n;
	for(int i =0; i<n; i++)
		for(int j =0; j<n; j++)
			cin >> matrix[0][i][j];
	for(int i =0; i<n; i++)
		for(int j =0; j<n; j++)
			cin >> matrix[1][i][j];
	for(int i =0; i<n; i++)
	{
		forFun[0][i] = new linkedList();
		linkedList *it = forFun[0][i];
		for(int j =n-1; j>0; j--)
		{
			bool b = matrix[0][i][j] < matrix[0][i][j-1];
			it->e = b;
			it->next = new linkedList();
			it = it->next;
		}
		it->e = matrix[0][i][0] < matrix[0][i][n-1];
		forFun[1][i] = new linkedList();
		it = forFun[1][i];
		for(int j =n-1; j>0; j--)
		{
			bool b = matrix[1][i][j] < matrix[1][i][j-1];
			it->e = b;
			it->next = new linkedList();
			it = it->next;
		}
		it->e = matrix[1][i][0] < matrix[1][i][n-1];
	}
}

void print( linkedList *l)
{
	cout << l->e;
	if( l->next == NULL)
	{
		cout << endl;
		return;
	}
	print( l->next);
}

int howManyOne(linkedList *l)
{
	if( l->next == NULL)
		return l->e;
	return howManyOne(l->next) + l->e;
}

bool compare(linkedList *l1, linkedList *l2)
{
	if(l1->e != l2->e)
		return false;
	if( l1->next == NULL)
		return true;
	return compare( l1->next, l2->next);
}

linkedList* getLast(linkedList *l)
{
	if( l->next == NULL)
		return l;
	return getLast(l->next);
}

linkedList* rotate( linkedList *first, linkedList *last)
{
	last->next = first;
	linkedList *l = first->next;
	first->next = NULL;
	return l;
}

bool check()
{
	for(int i =0; i<n; i++)
	{
		linkedList *it1 = forFun[0][i];
		int size1 = howManyOne(it1);
		bool flag = false;
		for(int j =0; j<n; j++)
		{
			linkedList *it2 = forFun[1][j];
			int size2 = howManyOne(it2);
			if( size1 != size2)
				continue;
			for(int k =0; k<n; k++)
			{
				if(compare(it1,it2) == true)
				{
					flag = true;
					break;
				}
				it2 = rotate(it2, getLast(it2));
			}
			if( flag == true)
				break;
		}
		if( flag == false)
			return false;
	}
	return true;

}

int main()
{
	ios::sync_with_stdio(false);
	int t;
	cin >> t;
	for(int i =0; i<t; i++)
	{
		initialize();
		if( check() == true)
			cout << "YES" << endl;
		else
			cout << "NO" << endl;
	}

	return 0;
}
