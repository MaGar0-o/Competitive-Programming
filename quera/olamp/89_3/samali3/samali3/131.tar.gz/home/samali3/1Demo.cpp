//name: Navid Salehnamadi

#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

const int maxN = 1000*1000 + 5;
int n;
int height[maxN];
vector<int> leftToRight;
vector<int> rightToLeft;

void initialize()
{
	ios::sync_with_stdio(false);
	cin >> n;
	for(int i =0; i<n; i++)
		cin >> height[i];
	int k = height[0];
	for(int i =0; i<n; i++)
	{
		if( height[i] >=k)
		{
			k = height[i];
			leftToRight.push_back(i);
		}
	}
	k = height[n-1];
	for(int i = n-1; i>=0; i--)
	{
		if( height[i] >=k)
		{
			k = height[i];
			rightToLeft.push_back(i);
		}
	}
}

int ltr()
{
	int res = 0;
	for(int i = 0; i< (int) leftToRight.size() -1; i++)
	{
		int k = height[ leftToRight[i]];
		if( k == height[ leftToRight[i+1]])
			continue;
		for(int j = leftToRight[i]; j<leftToRight[i+1]; j++)
			res += k - height[j];
	}
	return res;
}

int rtl()
{
	int res = 0;
	for(int i = 0; i< (int) rightToLeft.size() -1; i++)
	{
		int k = height[ rightToLeft[i]];
		for(int j = rightToLeft[i]; j>rightToLeft[i+1]; j--)
			res +=  k - height[j];
	}
	return res;
}

int main()
{
	initialize();
	cout << ltr() + rtl() << endl;
	return 0;
}
