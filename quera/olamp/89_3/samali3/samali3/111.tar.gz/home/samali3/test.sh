g++ -O2 -Wall $1.cpp && ./a.out <$1.in >$1.out && cat $1.out
