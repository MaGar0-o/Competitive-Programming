//name: Mohammad Hossein Sekhavat

#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <utility>
#define UI unsigned int
#define LL long long
using namespace std;
//typedef unsinged int UI;
//typedef long long LL;
const int MAXn=1000+10;
int sq[MAXn*MAXn];
LL tavan[MAXn];

int n,n2,testcases;
struct node{
  UI val;
  int row,col;
  node(int r=0, int c=0, int v=0){
    row=r;
    col=c;
    val=v;
  }
  bool operator <(const node &a) const{
    return (val<a.val);
  }
};
vector<node> s,t;

int row[MAXn], col[MAXn];

void Inputs(){
  scanf("%d", &n);
  n2=n*n;
  s=t=vector<node>(n2,node());
  int last=0;
  UI tmp;
  for (int i=0; i<n; i++)
    for (int j=0; j<n; j++){
      scanf("%d", &tmp);
      s[last++]=node(i,j,tmp);
    }
  last=0;
  for (int i=0; i<n; i++)
    for (int j=0; j<n; j++){
      scanf("%d", &tmp);
      t[last++]=node(i,j,tmp);
    }
}

bool mosavi;
bool UpdateRowCol(){
  if (s[1].val==t[1].val){
    for (int i=0; i<n2; i++)
      if (s[i].val!=t[i].val){
	cout<<"No"<<endl;
	return true;
      }
    cout<<"Yes"<<endl;
    return true;
  }
  if (s[1].val>t[1].val)
    s.swap(t);
  for (int i=0; i<n2; i++)
    row[i]=col[i]=-1;
  for (int j=0; j<n2; j++){
    int r=t[j].row;
    if (row[s[j].row]==-1)
      row[s[j].row]=r;
    else
      if (row[s[j].row]!=r){
	cout<<"No"<<endl;
	return true;
      }
    int c=(t[j].col-s[j].col+n)%n;
    if (col[r]==-1)
      col[r]=c;
    else
      if (col[r]!=c){
	cout<<"No"<<endl;
	return true;
      }
  }
  return false;
}

bool Solve(){
  bool jazr=true;
  for (int i=0; i<n2; i++)
    if (sq[t[i].val]==-1){
      jazr=false;
      break;
    }
  if (jazr){
    for (int i=0; i<n2; i++)
      t[i].val=sq[t[i].val];
    if (Solve())
      return true;
    for (int i=0; i<n2; i++)
      t[i].val=tavan[t[i].val];
  }
}

int main(){
  scanf("%d", &testcases);
  for (LL i=0; i<MAXn; i++){
    tavan[i]=i*i;
    sq[tavan[i]]=i;
  }
  for (LL i=0; i<MAXn*MAXn; i++)
    sq[i]=-1;
  for (int i=0; i<testcases; i++){
    Inputs();
    if (n==1){
      cout<<"Yes"<<endl;
      continue;
    }
    sort(s.begin(),s.end());
    sort(t.begin(),t.end());
    /**
    for (int j=0; j<n*n; j++)
      cerr<<s[j].val<<' ';
    cerr<<endl;
    for (int j=0; j<n*n; j++)
      cerr<<t[j].val<<' ';
    cerr<<endl;
    /**/
    if (UpdateRowCol())
      continue;
    if (Solve()) continue;
    cout<<"Yes"<<endl;
  }
}

