//name: Mohammad Hossein Sekhavat

#include <iostream>
#include <cstdio>
#include <vector>
#include <utility>
#include <algorithm>
#include <map>
#include <set>
using namespace std;
typedef pair<int,int> PII;
const int MAXn=100*1000+10;
const int MAXm=MAXn;
int baz[MAXn];
int baste[MAXn];
int n,m,t;
int d[MAXn];
int ans;

set<int> parantes;
void Inputs(){
  parantes.clear();
  scanf("%d", &n);
  unsigned int tmp;
  for (int i=1; i<=n; i++){
    scanf("%d", &tmp);
    d[i]=d[i-1]+tmp%2;
  }
  scanf("%d", &m);
  int tmp1,tmp2;
  for (int i=0; i<m; i++){
    scanf("%d%d", &tmp1, &tmp2);
    baz[tmp1]++;
    baste[tmp2]++;
    parantes.insert(tmp1);
    parantes.insert(tmp2);
  }
}

vector<int> endpoint;
vector<bool> canChange;
void Solve(){
  endpoint.clear();
  canChange.clear();
  int opening=0;
  endpoint.push_back(0);
  for (set<int>::iterator i=parantes.begin(); i!=parantes.end(); i++){
    int x=*i;
    if (baz[x] && endpoint[endpoint.size()-1]!=x){
      //endpoint.push_back(x-1);
      canChange.push_back((opening>0));
      endpoint.push_back(x);
    }
    opening+=baz[x];
    if (baste[x] && endpoint[endpoint.size()-1]!=x+1){
      //endpoint.push_back(x);
      canChange.push_back(true);
      endpoint.push_back(x+1);
    }
    opening-=baste[x];
  }
  endpoint.push_back(n+1);
  canChange.push_back(false);
  //for (int i=0; i<endpoint.size(); i++)
  //  cerr<<endpoint[i]<<' '<<canChange[i]<<endl;
}

void Dynamic(){
  ans=d[endpoint[1]-1];
  for (int i=1; i<endpoint.size()-1; i++){
    int diff=d[endpoint[i+1]-1]-d[endpoint[i]-1];
    if (canChange[i])
      diff=max(diff, endpoint[i+1]-endpoint[i]-diff);
    ans+=diff;
  }
}

int main(){
  scanf("%d", &t);
  for (int i=0; i<t; i++){
    Inputs();
    //for (set<int>::iterator i=parantes.begin(); i!=parantes.end(); i++)
    //  cout<<(*i)<<' '<<baz[(*i)]<<' '<<baste[(*i)]<<endl;
    Solve();
    Dynamic();
    cout<<ans<<endl;
    //cerr<<"HI"<<endl;
  }
  return 0;
}
