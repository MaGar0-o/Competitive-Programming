//name: Mohammad Hossein Sekhavat

#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>
#include <cstdio>
using namespace std;
const int MAXn=1000*1000+10;
int n, a[MAXn],lef[MAXn],righ[MAXn];

void Inputs(){
  scanf("%d", &n);
  for (int i=1; i<=n; i++)
    scanf("%d", &a[i]);
}

int main(){
  Inputs();
  for (int i=1; i<=n; i++)
    lef[i]=max(lef[i-1], a[i]);
  for (int i=n; i>=1; i--)
    righ[i]=max(righ[i+1], a[i]);
  unsigned int ans=0;
  for (int i=1; i<=n; i++){
    int delta=min(lef[i], righ[i])-a[i];
    if (delta>0)
      ans+=delta;
  }
  cout<<ans<<endl;
  return 0;
}
