//name: Khashayar Etemadi
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#define maxn (1000 + 10)
using namespace std;

struct rows{
	int row[maxn];
}colt1[maxn], col1[maxn], colt2[maxn], col2[maxn];

int gon = 1000000000, n, m[maxn], t;

void make(){
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			col1[i].row[j] -= gon;
		}
	}
}

inline bool check(int x){
	long long tmp = col2[0].row[0] - (static_cast<long long>(col1[0].row[0] + x) * (col1[0].row[0] + x));
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			if(col2[i].row[j] - (static_cast<long long>(col1[i].row[j] + x) * (col1[i].row[j] + x)) != tmp){
				return 0;
			}
		}
	}
	return 1;
}

bool cmp(const rows &x, const rows &y){
	for(int i = 0; i < n; i++){
		if(x.row[i] != y.row[i]) return x.row[i] < y.row[i];
	}
	return 1;
}

int main(){
	scanf("%d", &t);
	while(t--){	
		scanf("%d", &n);
		for(int i = 0; i < n; i++){
			int best = 0;
			for(int j = 0; j < n; j++){
				scanf("%d", &colt1[i].row[j]); gon = min(gon, colt1[i].row[j]);
				if(best >= colt1[i].row[j]){
					best = colt1[i].row[j]; m[i] = j;
				}
			}
		}
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++){
				col1[i].row[(j + n - m[i]) % n] = colt1[i].row[j];
			}
		}
		for(int i = 0; i < n; i++){
			int best = 0;
			for(int j = 0; j < n; j++){
				scanf("%d", &colt2[i].row[j]);
				if(best >= colt2[i].row[j]){
					best = colt2[i].row[j]; m[i] = j;
				}
			}
		}
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++){
				col2[i].row[(j + n - m[i]) % n] = colt2[i].row[j];
			}
		}
		sort(col1, col1 + n, cmp); sort(col2, col2 + n, cmp);
		make();
		bool f = 0;
		for(int i = 0; i < 6; i++){
			if(check(i)){
				f = 1; cout << "Yes" << endl; break;
			}
		}
		if(!f){
			cout << "No" << endl;
		}
	}
	return 0;
}
