//name: Khashayar Etemadi
#include <iostream>
#include <cstdio>
#include <set>
#include <algorithm>
#include <vector>
#include <cstring>
#define maxn (200000 + 10)
using namespace std;

int n, m, t, par[maxn], best[maxn], tmp0[maxn], tmp1[maxn], ans, arr[maxn];
vector<int>v[maxn];
pair<pair<int, int>, int>p[maxn];
set<pair<pair<int, int>, int> >ms;
set<pair<pair<int, int>, int> >::iterator it;
bool mark[maxn];

inline void make(){
    for(int i = 0; i <= n + m; i++) p[i].second = i;
	for(int i = 1; i <= n + m; i++){
		it = ms.lower_bound(make_pair(make_pair(p[i].first.first, p[i].first.first), 0));
		for(; 1;){
			if(it == ms.end() || it->first.first > p[i].first.second) break;;
			v[i].push_back(it->second); par[it->second] = i;
			ms.erase(it);
			it = ms.lower_bound(make_pair(make_pair(p[i].first.first, p[i].first.first),0));
		}
		ms.insert(p[i]);
	}
}

inline bool cmp(const pair<pair<int, int>, int> &x, const pair<pair<int, int>, int> &y){
	if(x.second <= n && y.second > n) return 1;
	if(x.second > n && y.second <= n) return 0;
	return (x.first.second - x.first.first) == (y.first.second - y.first.first) ? x.first < y.first
	: (x.first.second - x.first.first) < (y.first.second - y.first.first);
}

int dfs(int x){
	mark[x] = 1;
	for(int i = 0; i < v[x].size(); i++){
		if(!mark[v[x][i]]){
			if(p[v[x][i]].second <= n){
				if(arr[p[v[x][i]].first.first] % 2 == 0) tmp0[x]++;
				else tmp1[x]++;
				mark[v[x][i]] = 1;
			}
			else{
				best[x] += dfs(v[x][i]);
			}

		}
	}
	return best[x] + max(tmp0[x], tmp1[x]);
}

void dfs_all(){
	for(int i = n + m; i >= 1; i--){
		if(!mark[i]){
			ans += dfs(i);
		}
	}
}

int cal(){
	for(int i = 1; i <= n; i++){
		if(!par[i]) ans += arr[i] % 2;
	}
	return ans;
}

int main(){
	ios::sync_with_stdio(false);
	cin >> t;
	while(t--){
		cin >> n;
		for(int i = 1; i <= n; i++){
			cin >> arr[i]; p[i] = make_pair(make_pair(i, i), i);
		}
		cin >> m;
		for(int i = n + 1; i <= n + m; i++){
			cin >> p[i].first.first >> p[i].first.second; p[i].second = i;
		}
		sort(p + 1, p + n + m + 1, cmp);
		make();
		dfs_all();
		cout << cal() << '\n';
		memset(mark, 0, sizeof mark); memset(tmp0, 0, sizeof tmp0); memset(tmp1, 0, sizeof tmp1); memset(par, 0, sizeof par);
		memset(best, 0, sizeof best); for(int i = 0; i <= n + m; i++) v[i].clear(); ms.clear(); ans = 0;
	}
	return 0;
}
