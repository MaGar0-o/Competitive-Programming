//name: Khashayar Etemadi
#include <iostream>
#include <cstdio>
#define maxn (1000000 + 10)
using namespace std;

int n, ans, arr[maxn], dl[maxn], dr[maxn];

int main(){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i]);
	}
	for(int i = 1; i <= n; i++){
		dl[i] = max(dl[i - 1], arr[i]);
	}
	for(int i = n; i >= 1; i--){
		dr[i] = max(dr[i + 1], arr[i]);
	}
	for(int i = 1; i <= n; i++){
		int t = min(dr[i], dl[i]);
		if(t > arr[i]) ans += t - arr[i];
	}
	cout << ans << endl;
	return 0;
}
