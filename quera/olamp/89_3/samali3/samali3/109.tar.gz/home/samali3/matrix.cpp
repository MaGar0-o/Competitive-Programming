//name: Eqbal Sarjami
#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int t;

const int INF = 1000 * 1000 * 1000 + 1;
const int MAXN = 1000;
int n;

int mat1[MAXN][MAXN], mat2[MAXN][MAXN];
int temp[MAXN];

int p2s[1000 * 100];
int np2s;

void p2Init()
{
	for(int i = 0; i * i <= INF; i++)
	{
		p2s[np2s++] = i * i;
	}
}

bool is2Power(int a)
{
	/*
	bool isGood = false;
	for(int l = 0; l * l <= a; l++)
	{
		if(l * l == a)
		{
			isGood = true;
		}
	}
	*/
	//cerr << p2s[lower_bound(p2s, p2s + np2s, a) - p2s] << ' ' << a << endl;
	if(p2s[lower_bound(p2s, p2s + np2s, a) - p2s] == a)
		return true;
	return false;
}

int radic(int a)
{
	int r;
	for(r = 0; r * r <= a; r++);
	r--;
	return r;
}

void correctPower(int mat[MAXN][MAXN])
{
	int minE = INF;
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			if(mat[i][j] < minE)
			{
				minE = mat[i][j];
			}
		}
	}
	for(int i = 0; i * i <= minE; i++)
	{
		int dif = minE - i * i;
		bool isPowered = true;
		for(int j = 0; j < n; j++)
		{
			for(int k = 0; k < n; k++)
			{
				if(!is2Power(mat[j][k] - dif))
				{
					isPowered = false;
					//cerr << mat[j][k] - dif << endl;
					break;
				}
			}
			if(!isPowered)
			{
				break;
			}
		}
		//cerr << i << ' ' << isPowered << ' ' << dif << endl;
		if(isPowered)
		{
			for(int j = 0; j < n; j++)
			{
				for(int k = 0; k < n; k++)
				{
					mat[j][k] = radic(mat[j][k] - dif);
				}
			}
			correctPower(mat);
			break;
		}
	}
}

void correctSum(int mat[MAXN][MAXN])
{
	int minE = INF;
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			if(mat[i][j] < minE)
			{
				minE = mat[i][j];
			}
		}
	}
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			mat[i][j] -= minE;
		}
	}
}

void correctArrengement(int mat[MAXN][MAXN])
{
	for(int i = 0; i < n; i++)
	{
		int minE = INF, minEy = 0;
		for(int j = 0; j < n; j++)
		{
			if(mat[i][j] < minE)
			{
				minE = mat[i][j];
				minEy = j;
			}
		}
		for(int j = 0; j < minEy; j++)
		{
			temp[j] = mat[i][j];
		}
		for(int j = 0; j < n - minEy; j++)
		{
			mat[i][j] = mat[i][j + minEy];
		}
		for(int j = 0; j < minEy; j++)
		{
			mat[i][n - minEy + j] = temp[j];
		}
	}
}

struct Row
{
	int i;
	int s;
} rows[MAXN];

bool operator <(Row r1, Row r2)
{
	return r1.s < r2.s;
}

void correctRows(int mat[MAXN][MAXN])
{
	for(int i = 0; i < n; i++)
	{
		rows[i].i = i;
		rows[i].s = mat[i][0];
	}
	sort(rows, rows + n);
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			temp[j] = mat[rows[j].i][i];
		}
		for(int j = 0; j < n; j++)
		{
			mat[j][i] = temp[j];
		}
	}
}

bool isEqual(int m1[MAXN][MAXN], int m2[MAXN][MAXN])
{
	bool isGood = true;
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			if(m1[i][j] != m2[i][j])
			{
				isGood = false;
				break;
			}
		}
		if(!isGood)
		{
			break;
		}
	}
	return isGood;
}

/*
void showMat(int mat[MAXN][MAXN])
{
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			cerr << mat[i][j] << ' ';
		}
		cerr << endl;
	}
	cerr << endl;
}
*/

int main()
{
	p2Init();
	cin >> t;
	for(int i = 0; i < t; i++)
	{
		cin >> n;
		for(int j = 0; j < n; j++)
		{
			for(int k = 0; k < n; k++)
			{
				scanf("%d", &mat1[j][k]);
			}
		}
		for(int j = 0; j < n; j++)
		{
			for(int k = 0; k < n; k++)
			{
				scanf("%d", &mat2[j][k]);
			}
		}
		correctPower(mat1);
		correctPower(mat2);
		correctSum(mat1);
		correctSum(mat2);
		correctArrengement(mat1);
		correctArrengement(mat2);
		correctRows(mat1);
		correctRows(mat2);
		//showMat(mat1);
		//showMat(mat2);
		if(isEqual(mat1, mat2))
		{
			cout << "Yes" << endl;
		}
		else
		{
			cout << "No" << endl;
		}
	}
	return 0;
}
