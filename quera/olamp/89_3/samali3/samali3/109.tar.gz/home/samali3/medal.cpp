//name: Eqbal Sarjami
#include <iostream>
#include <cstdio>
using namespace std;

int t;

const int MAXN = 100 * 1000;
const int MAXM = 100 * 1000;
int n, m;

bool sol[MAXN];
int genf[MAXM], gens[MAXM];

int main()
{
	cin >> t;
	for(int i = 0; i < t; i++)
	{
		cin >> n;
		for(int j = 0; j < n; j++)
		{
			int tmp;
			scanf("%d", tmp);
			sol[j] = tmp % 2;
		}
		cin >> m;
		for(int j = 0; j < n; j++)
		{
			scanf("%d%d", &genf[j], &gens[j]);
		}
	}
	return 0;
}
