//name: Eqbal Sarjami
#include <iostream>
#include <cstdio>
using namespace std;

const int MAXN = 1000 * 1000;
int n;

int heights[MAXN];

int main()
{
	cin >> n;
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &heights[i]);
	}
	int maxH = -1, maxHP = 0;
	for(int i = 0; i < n; i++)
	{
		if(heights[i] > maxH)
		{
			maxH = heights[i];
			maxHP = i;
		}
	}
	long long water = 0;
	maxH = -1;
	for(int i = 0; i < maxHP; i++)
	{
		if(heights[i] > maxH)
		{
			maxH = heights[i];
		}
		else
		{
			water += maxH - heights[i];
		}
	}
	maxH = -1;
	for(int i = n - 1; i > maxHP; i--)
	{
		if(heights[i] > maxH)
		{
			maxH = heights[i];
		}
		else
		{
			water += maxH - heights[i];
		}
	}
	cout << water << endl;
	return 0;
}
