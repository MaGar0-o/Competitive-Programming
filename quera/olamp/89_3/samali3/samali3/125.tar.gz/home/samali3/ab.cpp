//name: Reza Aleyasin

//#include<ALLAH>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>

using namespace std;

const int MAX_N=1000*1000 +10;

int n;
int a[MAX_N];
int d0[MAX_N], d1[MAX_N];

int main(){
    scanf("%d", &n);
    for(int i=1; i<=n; i++)
        scanf("%d", &a[i]);

    int ans=0;
    for(int i=1; i<=n; i++)
        d0[i]=max(d0[i-1], a[i-1]);
    for(int i=n; i>=1; i--)
        d1[i]=max(d1[i+1], a[i+1]);
    for(int i=1; i<=n; i++)
        ans+=max(0,min(d0[i],d1[i])-a[i]);
    printf("%d\n", ans);

    return 0;
}

/*
7
4 1 3 5 2 3 4

6
1 3 4 7 5 1000

6
100 0 0 0 0 1000
*/
