//name: Reza Aleyasin

//#include<ALLAH>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>

using namespace std;

int main(){

    return 0;
}
