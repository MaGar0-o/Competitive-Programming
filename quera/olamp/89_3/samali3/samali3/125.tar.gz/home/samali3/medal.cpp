//name: Reza Aleyasin

//#include<ALLAH>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<bitset>
#include<vector>

using namespace std;

#define F first
#define S second

typedef pair<int,int> PII;

const int MAX_N=100*1000 +10;
const int MAX_M=100*1000 +10;

int t, n, m;
//bitset<MAX_N> b;
int d[MAX_N];

bitset<MAX_M> mark;
PII a[MAX_M];
int c[MAX_N];
vector<int> adj[MAX_M];
int par[MAX_N];


inline bool a_cmp(const PII &p1, const PII &p2){
    if(p1.F==p2.F)
        return p1.S>p2.S;
    return p1.F<p2.F;
}

void dfs(int v){
//    cerr<<"V>> "<<v<<endl;
    mark[v]=1;
    int t1=0, t0=0;
    if(!adj[v].empty()){
        if(a[adj[v][0]].F-1>=(a[v].F-1)){
            t1+=d[a[adj[v][0]].F-1]-d[a[v].F-1];
            t0+=(a[adj[v][0]].F-1-(a[v].F-1))-(d[a[adj[v][0]].F-1]-d[a[v].F-1]);
        }
//        cerr<<" T1>> "<<t1<<" && T0>> "<<t0<<endl;
        if(a[v].S>=a[adj[v][adj[v].size()-1]].S){
            t1+=d[a[v].S]-d[a[adj[v][adj[v].size()-1]].S];
             t0+=(a[v].S-a[adj[v][adj[v].size()-1]].S)-(d[a[v].S]-d[a[adj[v][adj[v].size()-1]].S]);
        }
//        cerr<<" T1>> "<<t1<<" && T0>> "<<t0<<endl;
    }else{
        if(a[v].S>=(a[v].F-1)){
        t1+=d[a[v].S]-d[a[v].F-1];
        t0+=(a[v].S-(a[v].F-1))-(d[a[v].S]-d[a[v].F-1]);
        }
//        cerr<<" T1>> "<<t1<<" && T0>> "<<t0<<endl;
    }

    for(int i=0, prev=0; i<adj[v].size(); i++){
        int u=adj[v][i];
        if(!mark[u]){
            if(a[u].F-1>=a[prev].S){
            t1+=d[a[u].F-1]-d[a[prev].S-1];
            t0+=(a[u].F-1-(a[prev].S-1))-(d[a[u].F-1]-d[a[prev].S-1]);
            }
            prev=i;
            dfs(u);
            c[v]+=c[u];
        }
    }
//    cerr<<" T1>> "<<t1<<" && T0>> "<<t0<<endl;
    c[v]+=max(t1,t0);
}

int main(){
    scanf("%d", &t);
    for(int tt=0; tt<t; tt++){
//        cerr<<" TT>> "<<tt<<endl;
//        b.reset();
        mark.reset();
        memset(par, 0, sizeof par);
        memset(d, 0, sizeof d);
        memset(c, 0, sizeof c);
        for(int i=0; i<MAX_N; i++)
            adj[i].clear();

        scanf("%d", &n);
        for(int i=1, val; i<=n; i++){
            scanf("%d", &val);
//            b[i]=(val&1);
            d[i]=d[i-1]+(val&1);
        }
        scanf("%d", &m);
        for(int i=0; i<m; i++)
            scanf("%d%d", &a[i].F, &a[i].S);

        sort(a, a+m, a_cmp);

//        for(int i=1; i<=n; i++)
//            cerr<<d[i]<<" ";
//        cerr<<endl;

//        for(int i=0; i<m; i++){
//            cerr<<a[i].F<<" && "<<a[i].S<<endl;
//        }

        par[0]=-1;
        for(int i=1, pp; i<m; i++){
            pp=i-1;
            while(pp!=-1 && !(a[pp].F<=a[i].F && a[pp].S>=a[i].S) ){
                pp=par[pp];
            }
            par[i]=pp;
            if(pp!=-1)
                adj[pp].push_back(i);
        }

//        for(int i=0; i<m; i++)
//            cerr<<"PAR>> "<<par[i]<<endl;

        int ans=d[a[0].F-1];
        int prev=0;
        for(int i=0; i<m; i++)
            if(!mark[i]){
                if(a[i].F-1>=a[prev].S)
                    ans+=d[a[i].F-1]-d[a[prev].S];
                prev=i;
                dfs(i);
                ans+=c[i];
            }
        ans+=d[n]-d[a[prev].S];
        printf("%d\n", ans);
    }
    return 0;
}
/*
2
3
8 9 0
3
1 3 1 1 1 1
4
7 6 8 2
3
1 4 1 1 4 4


3
4
7 6 8 2
3
1 4 1 1 4 4
3
8 9 0
3
1 3 1 1 1 1
4
7 6 8 2
3
1 4 1 1 4 4

1
3
8 9 0
3
1 3 1 1 1 1
*/
