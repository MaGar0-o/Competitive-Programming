//name: Seyyed Mohammad Hamed Sadat Hoseyni
#include<cstdio>
#include<cstdlib>
using namespace std;
int main(){
  int n;
  scanf("%d", &n);
  while(n--){
    // int k;
    // scanf("%d", &k);
    // minb.clear();
    // mina.clear();
    // minb.resize(k);
    // mina.resize(k);
    // for(int i=0; i<k;i++){
    //   for(int j=0; j<k; j++){
    // 	scanf("%d", &x);
    // 	a[i].push_back(x);
    // 	mina[i]=min(mina[i], x);
    printf("%s\n", rand()%2 ? "Yes" : "No");
  }
}
