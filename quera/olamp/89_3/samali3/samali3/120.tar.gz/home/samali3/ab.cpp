//name: Seyyed Mohammad Hamed Sadat Hoseyni
/* In the Name of ALLAH */
#include<cstdio>
#include<set>
#include<algorithm>
using namespace std;
//**************************************************************************************************
multiset<int> left, right;
int arr[1000*1000+10];
int n, ans=0;
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
inline void Input(){
  scanf("%d", &n);
  for(int i=0; i<n; i++){
    scanf("%d", &arr[i]);
    right.insert(arr[i]);
  }
}
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
inline void Solve(){
  if(n<=2)
    return;
  multiset<int>::iterator pos=right.find(arr[0]);
  right.erase(pos);
  left.insert(arr[0]);
  for(int i=1; i<n-1; i++){
    pos=right.find(arr[i]);
    right.erase(pos);
    int minim=min(*(left.rbegin()), *(right.rbegin()));
    ans += arr[i]<minim ? minim-arr[i] : 0;
    left.insert(arr[i]); 
  }
}
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
int main(){
  Input();
  Solve();
  printf("%d\n", ans);
  return 0;
}
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
