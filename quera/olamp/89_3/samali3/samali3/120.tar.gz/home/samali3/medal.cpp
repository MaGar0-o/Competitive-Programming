//name: Seyyed Mohammad Hamed Sadat Hoseyni
/* In the Name of ALLAH */
#include<cstdio>
#include<algorithm>
#include<vector>
#include<stack>
using namespace std;
//**************************************************************************************************
#define pb push_back
//**************************************************************************************************
struct Jen{
  int s, f;
  int odd, even;
  Jen(int ss, int ff){s=ss; f=ff;}
  int add_odd, add_even;
};
vector<int> sarbaz;
stack<Jen> js;
vector<Jen> jvec;
int ans;
int n, m;
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
inline void Input(){
  scanf("%d", &n);
  sarbaz.reserve(n+1);
  sarbaz.pb(0);
  for(int i=1; i<=n; i++){
    int x ,t=sarbaz.back();;
    scanf("%d", &x);
    if(x%2)
      t++;
    sarbaz.pb(t);
  }
  scanf("%d", &m);
  jvec.reserve(m+1);
  for(int i=0; i<m; i++){
    int x, y;
    scanf("%d%d", &x, &y);
    jvec.pb(Jen(x, y));
  }
  for(int i=0; i<m; i++){
    jvec[i].odd=sarbaz[jvec[i].f]-sarbaz[jvec[i].s-1];
    jvec[i].even=jvec[i].f-jvec[i].s+1-jvec[i].odd;
  }
}
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
inline bool comp(const Jen &a, const Jen &b){
  return a.f != b.f ? a.f < b.f : a.s > b.s;
} 
//**************************************************************************************************
inline void Solve(){
  sort(jvec.begin(), jvec.end(), comp);
  for(vector<Jen>::iterator i=jvec.begin(); i!=jvec.end(); i++){
    if(js.empty() || i->s > js.top().f){
      if(i->odd > i->even){
	i->add_odd=0;
	i->add_even=i->odd - i->even;
      }
      else{
	i->add_even=0;
	i->add_odd = i->even - i->odd;
      }
    }
    else{
      int o=0, e=0;
      while(!js.empty() && i->s <= js.top().f){
	o+=js.top().add_odd;
	e+=js.top().add_even;
	js.pop();
      }
      i->add_odd=max(o, (i->even+e) - i->odd);
      i->add_even=max(e, (i->odd+o) - i->even);
    }
    js.push(*i);
  }
  while(!js.empty()){
    ans+=js.top().add_odd;
    js.pop();
  }
  ans+=sarbaz[n];
}
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
int main(){
  int t;
  scanf("%d", &t);
  while(t--){
    sarbaz.clear();
    jvec.clear();
    ans=0;
    Input();
    Solve();
    printf("%d\n", ans);
  }
  return 0;
}
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
