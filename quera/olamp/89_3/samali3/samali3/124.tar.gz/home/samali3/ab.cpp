//name: Alireza Farhadi
#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
const int MN=1000*1000+100;
int list[MN];
int n;
int mx=-1,con;
int res,now;
int main()
{
	scanf("%d",&n);
	for (int i=0;i<n;i++)
		scanf("%d",&list[i]);
	for (int i=0;i<n;i++)
		if (list[i]>mx)
		{
			mx=list[i];
			con=i;
		}
	if (mx==-1)
	{
		printf("0\n");
		return 0;
	}
	int now=-1;
	for (int i=0;i<con;i++)
	{
		if (list[i]>now)
			now=list[i];
		if (list[i]<now)
			res+=now-list[i];
	}
	now=-1;
	for (int i=n-1;i>con;i--)
	{
		if (list[i]>now)
			now=list[i];
		if (list[i]<now)
			res+=now-list[i];

	}
	printf("%d\n",res);
	return 0;
}
