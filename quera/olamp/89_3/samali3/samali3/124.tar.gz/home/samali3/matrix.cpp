//name: Alireza Farhadi
#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <set>
using namespace std;
const int MN=1000+10,INF=(1u<<31)-1;
int mata[MN][MN],matb[MN][MN],mattemp[MN][MN];
int n;
struct Mat
{
	int mat[MN][MN];
	inline int * operator [](int a)
	{
		return mat[a];
	}
};
Mat Temp,lt;
Mat atemp,btemp;
inline bool operator <(const Mat & a,const Mat & b)
{
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			if (a.mat[i][j]!=b.mat[i][j])
				return a.mat[i][j]<b.mat[i][j];
	return 0;
}
set <Mat> mark;
struct node
{
	int no,v;
};
node sn[MN];
node sn2[MN*MN];
node sn3[MN*MN];
inline bool operator <(const node & a,const node & b)
{
	return a.v<b.v;
}
inline bool issqr(int & a)
{
	int temp=sqrt(a);
	return (temp*temp==a);
}
inline void shift(int * a)
{
	int temp=a[0];
	for (int i=0;i<n-1;i++)
		a[i]=a[i+1];
	a[n-1]=temp;
}
inline int dis(int & a)
{
	int temp=sqrt(a);
	return a-temp*temp;
}
inline bool islast(Mat & m)
{
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			lt[i][j]=sqrt(m[i][j]);
	int mx=-1;
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			mx=max(mx,dis(lt[i][j]));
	mx=min(mx,lt[0][0]);
	return mx==lt[0][0];
}
inline void asolve(Mat & m)
{
	int mx=-1;
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			mx=max(mx,dis(m[i][j]));
	mx=min(mx,m[0][0]);
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			m[i][j]-=mx;
	bool all=true;
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			if (!issqr(m[i][j]))
			{
				all=false;
				goto hell;
			}
hell : ;
		 if (all && m[0][0]!=0 && islast(m))
		 {
			 for (int i=0;i<n;i++)
				 for (int j=0;j<n;j++)
					 atemp[i][j]=m[i][j]-1;
			 asolve(atemp);
		 }
		 if (all)
			 for (int i=0;i<n;i++)
				 for (int j=0;j<n;j++)
					 m[i][j]=sqrt(m[i][j]);
		 if (m[0][0]==0)
			 mark.insert(m);
		 else
			 asolve(m);
}
inline bool bsolve(Mat & m)
{
	int mx=-1;
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			mx=max(mx,dis(m[i][j]));
	mx=min(mx,m[0][0]);
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			m[i][j]-=mx;
	bool all=true;
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			if (!issqr(m[i][j]))
			{
				all=false;
				goto hell;
			}
hell : ;
		 if (all && m[0][0]!=0 && islast(m))
		 {
			 for (int i=0;i<n;i++)
				 for (int j=0;j<n;j++)
					 btemp[i][j]=m[i][j]-1;
			 if (bsolve(btemp))
				 return 1;
		 }
		 if (all)
			 for (int i=0;i<n;i++)
				 for (int j=0;j<n;j++)
					 m[i][j]=sqrt(m[i][j]);
		 if (m[0][0]==0)
		 {
			 if (mark.find(m)!=mark.end())
				 return 1;
			 return 0;
		 }
		 else
			 return bsolve(m);
}
inline bool check()
{
	int p=0;
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
		{
			sn2[p].no=sn3[p].no=p;
			sn2[p].v=mata[i][j];
			sn3[p].v=matb[i][j];
			p++;
		}
	sort(sn2,sn2+p);
	sort(sn3,sn3+p);
	for (int i=0;i<p;i++)
		if (sn2[i].no!=sn3[i].no)
			return 0;
	return 1;
}
inline void init(int a[MN][MN])
{
	for (int i=0;i<n;i++)
	{
		int min=INF,p=-1;
		for (int j=0;j<n;j++)
			if (a[i][j]<min)
			{
				min=a[i][j];
				p=j;
			}
		for (int j=0;j<p;j++)
			shift(a[i]);
	}
	for (int i=0;i<n;i++)
	{
		sn[i].no=i;
		sn[i].v=a[i][0];
	}
	sort(sn,sn+n);
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			mattemp[i][j]=a[i][j];
	for (int i=0;i<n;i++)
	{
		int row=sn[i].no;
		for (int j=0;j<n;j++)
			a[i][j]=mattemp[row][j];
	}
}
int main()
{
	int senario;
	scanf("%d",&senario);
	for (;senario;senario--)
	{
		mark.clear();
		scanf("%d",&n);
		for (int i=0;i<n;i++)
			for (int j=0;j<n;j++)
				scanf("%d",&mata[i][j]);
		for (int i=0;i<n;i++)
			for (int j=0;j<n;j++)
				scanf("%d",&matb[i][j]);
		if (n==1)
		{
			printf("Yes\n");
			continue;
		}
		init(mata);
		init(matb);
		if (!check())
		{
			printf("No\n");
			continue;
		}
		for (int i=0;i<n;i++)
			for (int j=0;j<n;j++)
				Temp[i][j]=mata[i][j];
		asolve(Temp);
		for (int i=0;i<n;i++)
			for (int j=0;j<n;j++)
				Temp[i][j]=matb[i][j];
		if (bsolve(Temp))
			printf("Yes\n");
		else
			printf("No\n");
	}
	return 0;
}
