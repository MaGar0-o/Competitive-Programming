#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

const int maxn = 10000;
int a[maxn], b[maxn], s[maxn];
int n, m, t;

int BT(int d){
/*
	cerr << "BT " << d << " : ";
	for(int j = 0; j < m; j++){
		cerr <<"(" << (1<<j) << ")" ;
		if((d & (1<<j) ))
			cerr  << j << " ";
	}
	cerr << " --> "; 
	*/
	int out = 0;
	for(int i = 0; i < n; i++){
		int x = s[i];
		for(int j = 0; j < m; j++)
			if( a[j] <= i && b[j] >= i && (d & (1<<j) ))
				x++;
		//if(x%2)
		//	cerr << i << " ";
		out += (x%2);
	}
	//cerr << endl;
	return out;
}
	
int main(){
	cin >> t;
	for(int k = 0; k < t; k++){
		cin >> n;
		for(int i = 0; i < n; i++)
			cin >> s[i];
		cin >> m;
		for(int i = 0; i < m; i++){
			cin >> a[i] >> b[i];
			a[i]--;
			b[i]--;
		}
		/*
		for(int i = 0; i < n; i++)
			cerr << s[i] << " " ;
		cerr << endl;
		for(int i = 0; i < m; i++)
			cerr << a[i] << " " << b[i] << endl;
		*/
		int ans = 0;
		int all = 1<<m;
		//cerr << n << " " << m << " " << all << endl;
		for(int i = 0; i < all; i++)
			ans = max(ans, BT(i));
		cout << ans << endl;
	}
	return 0;
}
			 
