//name: kasra edalatnejad
#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<set>
#include<map>
using namespace std;

const int INF = 999999999;
const int maxn = 1010;
int n, a[maxn][maxn], b[maxn][maxn], tmp[maxn];
int oa[maxn], ob[maxn];
set<int> sa, sb;
map<int, int> ma, mb;

void build(int *a){
	int o = INF, on;
	for(int i = 0; i < n; i++)
		if(tmp[i] < o){
			o = tmp[i];
			on = i;
		}
	for(int i = 0; i < n; i++)
		a[i] = tmp[(i+on)%n];
}
bool cmpA(int x, int y){
	return a[x][0] < a[y][0];
}
bool cmpB(int x, int y){
	return b[x][0] < b[y][0];
}

	
int main(){
	int test;
	scanf("%d", &test);
	for(int tt = 0; tt < test; tt++){
		scanf("%d", &n);
		sa.clear();
		sb.clear();
		ma.clear();
		mb.clear();
		
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++){
				scanf("%d", &tmp[j]);
				sa.insert(tmp[j]);
			}
			build(a[i]);
		}
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++){
				scanf("%d", &tmp[j]);
				sb.insert(tmp[j]);
			}
			build(b[i]);
		}
		int num = 0;
		for(set<int>::iterator it = sa.begin(); it != sa.end(); it++)
			ma[*it] = num++;
		num = 0;
		for(set<int>::iterator it = sb.begin(); it != sb.end(); it++)
			mb[*it] = num++;
			
		for(int i = 0; i < n ; i++)
			oa[i] = ob[i] = i;
		sort(oa, oa+n, cmpA);
		sort(ob, ob+n, cmpB);

		for(int i = 0; i < n; i++)
			for(int j = 0; j < n; j++)
				if(ma[a[oa[i]][j]] != mb[b[ob[i]][j]]){
					cout << "No" << endl;
					goto hell;
				}
		cout << "Yes" << endl;
		hell:;
		/*
		cerr << " A : "  << endl;
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++)
				cerr << a[oa[i]][j] << " ";
			cerr << endl;
		}
		cerr << " B : "  << endl;
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++)
				cerr << b[ob[i]][j] << " ";
			cerr << endl;
		}
		*/
	}
	return 0;
}
