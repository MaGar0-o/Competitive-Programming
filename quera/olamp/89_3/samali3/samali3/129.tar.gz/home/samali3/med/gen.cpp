#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;

const int minn = 1000;
const int maxn = 4000;
const int maxm = 500;

int main(){
	srand(time(0));
	int t = rand()%10+1;
	cout << t << endl;
	for(int tt =0; tt < t; tt++){
		int n = rand()%maxn + minn;
		cout << n << endl;
		for(int i = 0; i < n; i++)
			cout << rand()% 13465 << " ";
		cout << endl;
//		pair<int , int> p[100];
		int a[1000], b[1000], oa[100], ob[100], on = 0;
		for(int i = 0; i < maxm; i++){
			 a[i] = rand()%n+1, b[i] = rand()%n+1;
			if(a[i] > b[i])
				swap(a[i], b[i]);
//			p[i] = make_pair(a, b);
		}
		for(int i = maxm-1; i>= 0; i--){
			for(int j = 0; j < i; j++)
				if(a[i] <= b[j] && b[i] > b[j])
					goto hell;
				else if(b[i] >= a[j] && a[i] < a[j])
					goto hell;
			oa[on] = a[i];
			ob[on] = b[i];
			on++;
			hell:;
		}
		on = min(on, 20);
		cout << on << endl;
		for(int i = 0; i <  on ; i++)
			cout << oa[i] << " " << ob[i] << endl;
	}
	return 0;
}
