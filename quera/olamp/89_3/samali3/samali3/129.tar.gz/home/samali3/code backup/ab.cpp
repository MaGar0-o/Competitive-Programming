#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

const int maxn = 1000100;
int a[maxn], af[maxn], bf[maxn], n;
long long ans = 0;

int main(){
	scanf("%d", &n);
	//cerr << n << endl;
	for(int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	//for(int i = 1; i <= n; i++)
	//	cerr <<a[i] << " ";
	//cerr << endl;
	for(int i = 1; i <= n; i++)
		bf[i] = max(bf[i-1], a[i-1]);
	for(int i = n; i >= 0; i--)
		af[i] = max(af[i+1], a[i+1]);
	//cerr << "AF & BF END" << endl;
	for(int i = 1; i <= n; i++)
		ans += max(0, min(af[i], bf[i]) - a[i]);
	cout << ans << endl;
	return 0;
}
