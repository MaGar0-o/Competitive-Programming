if(g++ code.cpp -O2 && g++ gen.cpp -ogen.out && g++ tester.cpp -O2 -otester.out)then
	for((i=0;;i++))do
		./gen.out > IN;
		./a.out < IN > OUT;
		./tester.out < IN > COR;
		if( ! diff OUT COR   )then
			echo "TESTCASE $i: [WRONG]";
			cat IN
			echo "***********"
			cat OUT
			cat COR
			exit;
		fi
		echo "TESTCASE $i: [OK]";
		#	cat OUT
		#	cat COR
	done 
fi			
