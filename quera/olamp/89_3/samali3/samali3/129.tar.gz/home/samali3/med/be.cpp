//name: kasra edalatnejad
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<cstring>
using namespace std;

#define MK make_pair
const int maxn =100100;
int n, m, gn, ans, finish, s[maxn];
pair<int , int> g[maxn];

bool cmp(pair<int, int> a, pair<int, int> b){
	if(a.first != b.first)
		return a.first < b.first;
	return a.second > b.second;
}

void BT(int p, int &o, int &e){
	//cerr << "BT " << p << " " << gn << endl;
	gn++;
	int x = s[g[p].second+1] - s[g[p].first], y = 1+ g[p].second - g[p].first, mo, me;
	//cerr << "!!!" << p << " " << g[p].second << " " << g[p].first << " " << y << endl;
	o = e = 0;
	for(int i = gn; i < m; )
		if(g[i].first <= g[p].second){
			int to, te;
			//cerr << p << " CALL BT " << i << endl;
			BT(i, to, te);
			//gn++;
			o += to;
			e += te;
			i = gn;
		}
		else break;
	mo = o;
	me = e;
	mo = max(mo, (y+e-x) - (x));
	me = max(me, (x+o) - (y-x));
	o = mo;
	e = me;
	//cerr << "BTEND " << p << " " << gn << " --> " << g[p].first << " " << g[p].second << "  ODD:" << x << "  ALL:" << y << "  MO:" <<  mo << " ME:" << me << endl;
}

int main(){
	int testnum;
	scanf("%d" , &testnum);
	for(int tnum = 0; tnum < testnum; tnum++){
		memset(s, 0, sizeof(s));
		ans = 0;
		scanf("%d" , &n);
		for(int i = 1; i <= n; i++){
			int tmp;
			scanf("%d", &tmp);
			s[i+1] = s[i] + (tmp%2);
		}
		s[n+2] = s[n+1];
		scanf("%d", &m);
		for(int i = 0; i < m; i++){
			int a, b;
			scanf("%d%d", &a, &b);
			g[i] = MK(a, b);
		}
		sort(g, g+m, cmp);
		/**
		cerr << n << " " << m << endl;
		for(int i = 0; i <= n+2 ; i++)
			cerr << s[i] << " " ;
		cerr << endl;
		for(int i = 0; i <=  m; i++)
			cerr << g[i].first << " " << g[i].second << endl;
		/**/
		
		for(gn = 0; gn < m; //////gn++
							)
			if(g[gn].first > finish){
				int o, e;
				//cerr << "BODY CALLING " << gn << endl;
				BT(gn, o, e);
				//cerr << " IN BODY BT " << o << endl;
				ans += o;
			}
		//cerr << " END ANS : " << ans << endl;
		ans += s[n+2];
		cout << ans << endl;
		//cerr << "______________ END OF TEST " << tnum+1 << " ___________________" << endl;
	}
	return 0;
}
