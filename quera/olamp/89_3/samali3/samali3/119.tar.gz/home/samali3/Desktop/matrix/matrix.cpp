//name: Sajad Jalali
































//IN THE NAME OF ALLAH
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cmath>
using namespace std;

typedef pair< int, int > pii;

const int MAX_N=1000+10;

int a[ MAX_N ][ MAX_N ], b[ MAX_N ][ MAX_N ], c[ MAX_N ][ MAX_N ], n;
pii p[ MAX_N ];

void ReadInput(){
	scanf("%d",&n);
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			scanf("%d",&a[i][j]);
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			scanf("%d",&b[i][j]);
}

void Sort( int a[][MAX_N] ){
	for( int i=0;i<n;i++ ){
		int andismini=0;
		for( int j=0;j<n;j++ )
			if( a[ i ][ j ]<a[ i ][ andismini ] )
				andismini=j;
		for( int j=0;j<n;j++ )
			c[i][ (j-andismini+n)%n ]=a[ i ][ j ];
		for( int j=0;j<n;j++ )
			a[i][j]=c[i][j];
	}
	for( int i=0;i<n;i++ )
		p[i]=pii( a[i][0], i );
	sort( p, p+n );
	for( int i=0;i<n;i++ ){
		int andis=p[i].second;
		for( int j=0;j<n;j++ )
			c[ i ][ j ]=a[ andis ][ j ];
	}
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			a[i][j]=c[i][j];
}

void MynesMini( int a[][MAX_N] ){
	int mini=a[0][0];
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			mini=min( mini, a[i][j] );
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			a[i][j]-=mini;
}

bool majzor( int k ){
	if( (int)sqrt( k )*(int)sqrt( k )==k )
		return true;
	return false;
}

bool Change( int a[][MAX_N] ){
/*	if( a[0][0]==1 ){
		bool yek=true;
		for( int i=0;i<n;i++ )
			for( int j=0;j<n;j++ ){
				if( a[i][j]==1 )
					continue;
				int tmp=sqrt(a[i][j]);
				if( 1==a[i][j]-( tmp*tmp ) )
					continue;
				else{
					yek=false;
				}
			}
		if( yek==true ){
			for( int i=0;i<n;i++ )
				for( int j=0;j<n;j++ ){
					a[i][j]-=1;
					a[i][j]=sqrt( a[i][j] );
				}
			return true;
		}
		bool sefr=true, gheireyek=false;
		for( int i=0;i<n;i++ )
			for( int j=0;j<n;j++ ){
				int tmp=sqrt(a[i][j]);
				if( a[i][j]>1 )
					gheireyek=true;
				if( 0==a[i][j]-( tmp*tmp ) )
					continue;
				else
					sefr=false;
			}
		if( sefr ){
			for( int i=0;i<n;i++ )
				for( int j=0;j<n;j++ )
					a[i][j]=sqrt( a[i][j] );
			if( gheireyek )
				return true;
		}
		MynesMini(a);
		return false;
	}*/
	int myn=0;
	for( int f=0;f<=a[0][0];f++ )
		if( majzor( f ) ){
			myn=a[0][0]-f;
	bool can=false;
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ ){
			if( a[i][j]!=0 && a[i][j]!=1 )
				can=true;
			if( majzor( a[i][j]-myn ) )
				continue;
			else{
//				cerr<<"a["<<i<<"]["<<j<<"]="<<a[i][j]<<" myn="<<myn<<endl;
				goto Finish ;
			}
		}
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ ){
			a[i][j]-=myn;
			a[i][j]=sqrt( a[i][j] );
		}
	if( can==true )
		return true;
Finish:
//	cerr<<"finish"<<endl;
/**	cerr<<"a="<<endl;
	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			cerr<<a[i][j]<<" ";
		cerr<<endl;
	}/**/

;
//	MynesMini(a);

/*	myn=(int)sqrt(a[0][0])*(int)sqrt(a[0][0]);
	myn=a[0][0]-myn;
	can=false;
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ ){
			int tmp=sqrt(a[i][j]);
			if( a[i][j]!=0 && a[i][j]!=1 )
				can=true;
			if( myn==a[i][j]-( tmp*tmp ) )
				continue;
			else{
//				cerr<<"#####3a[i][j]="<<a[i][j]<<" myn="<<myn<<endl;
				goto End;
			}
		}
	if( can ){
		for( int i=0;i<n;i++ )
			for( int j=0;j<n;j++ )
				a[i][j]=sqrt( a[i][j] );
		return true;
	}
End:*/
		}
	MynesMini(a);
	return false;
}

void Solve(){
	Sort( a );
/**	cerr<<"a="<<endl;
	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			cerr<<a[i][j]<<" ";
		cerr<<endl;
	}/**/
	Sort( b );
/**	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			cerr<<b[i][j]<<" ";
		cerr<<endl;
	}/**/
	while( Change( a ) );
/**	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			cerr<<a[i][j]<<" ";
		cerr<<endl;
	}/**/
	while( Change( b ) );
/**	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			cerr<<b[i][j]<<" ";
		cerr<<endl;
	}/**/
}

bool EQ(){
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			if( a[i][j]!=b[i][j] )
				return false;
	return true;
}

int main(){
	int t;
	scanf("%d",&t);
	for( int g=0;g<t;g++ ){
		ReadInput();
		Solve();
		if( EQ() )
			cout<<"Yes"<<endl;
		else 
			cout<<"No"<<endl;
	}
	return 0;
}

