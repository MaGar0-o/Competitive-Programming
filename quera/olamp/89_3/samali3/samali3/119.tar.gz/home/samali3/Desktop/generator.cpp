//IN THE NAME OF ALLAH
#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

int main(int argv, char * argc[]){
	srand( atoi( argc[1] ) );
	int n=rand()%(1000*1000)+1;
	printf("%d\n",n);
	for( int i=0;i<n;i++ )
		printf("%d ",rand()%(1001));
	return 0;
}
