#IN THE NAME OF ALLAH
g++ generator.cpp -O2 -Wall -o gen;
g++ matrix.cpp -O2 -Wall;
for(( i=0;i<100;i++ )) do
((b=$i*$1));
./gen $b >1.in;
ulimit -S -t 2;
ulimit -S -v 128000;
./a.out <1.in >1.out;
ulimit -S -t unlimited;
ulimit -S -v unlimited;
if diff 1.out test.in ; then
echo Pass Test $i;
else
echo wa test $i;
break;
fi
done

