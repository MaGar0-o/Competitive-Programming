//IN THE NAME OF ALLAH
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <set>
using namespace std;

typedef pair< int, int > pii;

const int MAX_N=1000+10, INF=1000*1000*1000;

int a[ MAX_N ][ MAX_N ], b[ MAX_N ][ MAX_N ], c[ MAX_N ][ MAX_N ];
set< int > s;
int n;
pair< int, int > p[ MAX_N ];

void Swap( int s, int t, int a[][ MAX_N ] ){
	for( int i=0;i<n;i++ )
		swap( a[s][i], a[t][i] );
}

void Shift( int s, int a[][ MAX_N ] ){
	for( int i=n-1;i>0;i-- )
	   swap( a[s][i], a[s][i-1] );	
}

void Pow( int a[][ MAX_N ] ){
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			if( (long long)a[i][j]*a[i][j]>INF )
				return ;
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			a[i][j]*=a[i][j];
}

void Plus( int s, int a[][ MAX_N ] ){
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			if( (long long )a[i][j]+s>INF )
				return ;
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			a[i][j]+=s;
}

void Sort( int a[][MAX_N] ){
	for( int i=0;i<n;i++ ){
		int andismini=0;
		for( int j=0;j<n;j++ )
			if( a[ i ][ j ]<a[ i ][ andismini ] )
				andismini=j;
		for( int j=0;j<n;j++ )
			c[i][ (j-andismini+n)%n ]=a[ i ][ j ];
		for( int j=0;j<n;j++ )
			a[i][j]=c[i][j];
	}
	for( int i=0;i<n;i++ )
		p[i]=pii( a[i][0], i );
	sort( p, p+n );
	for( int i=0;i<n;i++ ){
		int andis=p[i].second;
		for( int j=0;j<n;j++ )
			c[ i ][ j ]=a[ andis ][ j ];
	}
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			a[i][j]=c[i][j];
}
			
int main( int argv, char * argc[] ){
	srand( atoi( argc[1] ) );
	n=rand()%1000+1;
	a[0][0]=0;
	s.insert( 0 );
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ ){
			if(i==j && i==0 )
				continue;
			int tmp=rand()%(100*1000*1000)+1;
			while( s.find( tmp )!=s.end() )
				tmp=rand()%(100*1000*1000)+1;
			s.insert( tmp );
			b[i][j]=a[i][j]=tmp;
		}
	Sort( a );
	Sort( b );
/**	cerr<<"ebteda"<<endl;
	for( int i=0;i<n;i++){
		for( int j=0;j<n;j++ )
			cerr<<a[i][j]<<" ";
		cerr<<endl;
	}/**/
	int num=rand()%500+1;
	for( int i=0;i<num;i++ ){
		if( rand()%2 ){
			int amal=rand()%4;
			if( amal==0 )
				Swap( rand()%n, rand()%n, a );
			if( amal==1 )
				Shift( rand()%n, a );
			if( amal==2 )
				Plus( rand()%10+1, a );
			if( amal==3 )
				Pow( a );
		}
		else{
			int amal=rand()%4;
			if( amal==0 )
				Swap( rand()%n, rand()%n, b );
			if( amal==1 )
				Shift( rand()%n, b );
			if( amal==2 )
				Plus( rand()%10+1, b );
			if( amal==3 )
				Pow( b );
		}
	}
	printf("1 %d\n",n);
	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			printf("%d ",a[i][j]);
		printf("\n");
	}
	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			printf("%d ",b[i][j]);
		printf("\n");
	}
	return 0;
}
