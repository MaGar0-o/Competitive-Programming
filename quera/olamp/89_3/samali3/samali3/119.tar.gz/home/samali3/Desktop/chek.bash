#IN THE NAME OF ALLAH
g++ generator.cpp -O2 -Wall -o gen;
g++ ab.cpp -O2 -Wall;
for(( i=0;i<100;i++ )) do
((b=$i*$1));
./gen $b >1.in;
ulimit -S -t 2;
ulimit -S -v 128000;
./a.out <1.in;
ulimit -S -t unlimited;
ulimit -S -v unlimited;
done

