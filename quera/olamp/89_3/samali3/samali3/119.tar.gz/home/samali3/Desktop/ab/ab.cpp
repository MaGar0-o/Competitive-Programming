//name: Sajad Jalali


























//IN THE NAME OF ALLAH
#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAX_N=1000*1000+10;

int a[ MAX_N ], n, res;

void ReadInput(){
	scanf("%d",&n);
	for( int i=0;i<n;i++ )
		scanf("%d",&a[i]);
}

void Solve(){
	int first=0, tail;
	while( first<n ){
		int tmp=0;
		tail=first;
		while( tail+1<n && a[ tail+1 ]<a[ first ] ){
			tail++;
			tmp+=a[ first ]-a[ tail ];
		}
	//	cerr<<"res="<<res<<" tmp="<<tmp<<" first="<<first<<" tail="<<tail<<endl;
		if( tail!=n-1 ){//yani a[ tail+1 ]>=a[ first ] )
			res+=tmp;
			first=tail+1;
			continue;
		}
		else{//tail==n-1 yani inke bozorgtar nadashte ast
			int end=first;
			first=tail;
			//888888888888888888888888888888
			while( first>end ){
				tail=first;
				while( tail-1>=end && a[ tail-1 ]<a[ first ] ){
					tail--;
					res+=a[ first ]-a[ tail ];
				}
				first=tail-1;
			}
			break;
		}
	}
}

int main(){
	ReadInput();
	Solve();
	cout<<res<<endl;
	return 0;
}

