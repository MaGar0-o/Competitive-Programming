//IN THE NAME OF ALLAH
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <set>
using namespace std;

const int MAX_N=1000+10, INF=1000*1000*1000;

int a[ MAX_N ][ MAX_N ], b[ MAX_N ][ MAX_N ];
set< int > s;
int n;


void Swap( int s, int t, int a[][ MAX_N ] ){
	for( int i=0;i<n;i++ )
		swap( a[s][i], a[t][i] );
}

void Shift( int s, int a[][ MAX_N ] ){
	for( int i=n-1;i>0;i-- )
	   swap( a[s][i], a[s][i-1] );	
}

void Pow( int a[][ MAX_N ] ){
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			if( (long long)a[i][j]*a[i][j]>INF )
				return ;
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			a[i][j]*=a[i][j];
}

void Plus( int s, int a[][ MAX_N ] ){
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			if( (long long )a[i][j]+s>INF )
				return ;
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ )
			a[i][j]+=s;
}
			
int main( int argv, char * argc[] ){
	srand( atoi( argc[1] ) );
	n=rand()%10+1;
	a[0][0]=0;
	n=3;
	s.insert( 0 );
	for( int i=0;i<n;i++ )
		for( int j=0;j<n;j++ ){
			if(i==j && i==0 )
				continue;
			int tmp=rand()%(100)+1;//*1000*1000)+1;
			while( s.find( tmp )!=s.end() )
				tmp=rand()%(100)+1;//*1000*1000)+1;
			s.insert( tmp );
			b[i][j]=a[i][j]=tmp;
		}
/**	cerr<<"ebteda"<<endl;
	for( int i=0;i<n;i++){
		for( int j=0;j<n;j++ )
			cerr<<a[i][j]<<" ";
		cerr<<endl;
	}/**/
	int num=rand()%5+1;
	for( int i=0;i<num;i++ ){
		if( rand()%2 ){
			int amal=rand()%4;
			if( amal==0 )
				Swap( rand()%n, rand()%n, a );
			if( amal==1 )
				Shift( rand()%n, a );
			if( amal==2 )
				Plus( rand()%10+1, a );
			if( amal==3 )
				Pow( a );
		}
		else{
			int amal=rand()%4;
			if( amal==0 )
				Swap( rand()%n, rand()%n, b );
			if( amal==1 )
				Shift( rand()%n, b );
			if( amal==2 )
				Plus( rand()%10+1, b );
			if( amal==3 )
				Pow( b );
		}
	}
	printf("1 %d\n",n);
	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			printf("%d ",a[i][j]);
		printf("\n");
	}
	for( int i=0;i<n;i++ ){
		for( int j=0;j<n;j++ )
			printf("%d ",b[i][j]);
		printf("\n");
	}
	return 0;
}
