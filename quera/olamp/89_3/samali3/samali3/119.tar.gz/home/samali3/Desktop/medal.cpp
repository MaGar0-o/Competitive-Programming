//name: Sajad Jalali



























//IN THE NAME OF ALLAH
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <vector>
#define PB( X ) push_back( X )
#define SZ( X ) (int)X.size()
using namespace std;

typedef pair< int, int > pii;

const int MAX_N=100*1000+10;

//this code is one based be fazle ELAHI

int n, sum[ MAX_N ], res;
bool s[ MAX_N ];
vector< int > st[ MAX_N ], en[ MAX_N ];
vector< pii > jeneral;

void MakeReady(){
	res=0;
	for( int i=0;i<MAX_N;i++ ){
		st[i].resize(0);
		en[i].resize(0);
	}
	jeneral.resize(0);
	memset( s, 0, sizeof( s ) );
	memset( sum, 0, sizeof( sum ) );
}

void ReadInput(){
	MakeReady();
	scanf("%d",&n);
	for( int i=1, u;i<=n;i++ ){
	   scanf("%d",&u);	   
	   s[ i ]=u%2;
	}
	int m;
	scanf("%d",&m);
	for( int i=0;i<m;i++ ){
		int a, b;
		scanf("%d%d",&a,&b);
		if( a<=b )
			jeneral.PB( pii( a, b ) );
	}
}

void FindTekkeSt(){
	for( int i=1;i<=n;i++ ){
		sort( st[i].begin(), st[i].end() );
		for( int j=SZ( st[i] )-1;j>=0;j-- ){
			int b=st[i][j];
			if( j==0 ){
				jeneral.PB( pii( i, b ) );
				continue;
			}
			int prev=st[i][j-1];
			if( prev==b )
				continue;//2 ta bazeye yeksan
			st[ prev+1 ].PB( b );
		}
	}
}

void FindTekkeEn(){
	for( int i=n;i>0;i-- ){
		sort( en[i].begin(), en[i].end() );
		for( int j=0;j<SZ( en[i] );j++ ){	
			int b=en[i][j];
			if( j==SZ( en[i] )-1 ){
				jeneral.PB( pii( b, i ) );
				continue;
			}
			int next=en[i][j+1];
			if( next==b )
				continue;//2 ta bazeye yeksan
			en[ next-1 ].PB( b );
		}
	}
}
		
void Solve(){
	for( int i=1;i<=n;i++ )
		sum[i]=sum[i-1]+s[i];
	res=sum[n];

	for( int i=0;i<SZ( jeneral );i++ ){
		int a=jeneral[i].first, b=jeneral[i].second;
		st[ a ].PB( b );
	}
	jeneral.resize(0);
	FindTekkeSt();
	for( int i=0;i<SZ( jeneral );i++ ){
		int a=jeneral[i].first, b=jeneral[i].second;
		en[ b ].PB( a );
	}
	jeneral.resize(0);
	FindTekkeEn();
	//dige bazeha hich eshteraki nadarnad
	for( int i=0;i<SZ( jeneral );i++ ){
		int a=jeneral[i].first, b=jeneral[i].second;
		if( a>b || a==0 )
			continue;
		int numfard=sum[b]-sum[a-1], ted=b-a+1;
		if( numfard < ted-numfard )
			res+=( ted-numfard -numfard );//nemikhahad taghyir bedi chizi ra chon eshterak nadarand
	}
}

int main(){
	int t;
	scanf("%d",&t);
	for( int g=0;g<t;g++ ){
		ReadInput();
		Solve();
		cout<<res<<endl;
	}
	return 0;
}

